# คู่มือศึกษาโค้ด SPRINT HUB

> เอกสารนี้อธิบายว่าแต่ละไฟล์ทำหน้าที่อะไร ควรอ่านไฟล์ไหนก่อน-หลัง และ data flow เป็นอย่างไร

---

## ลำดับการอ่านโค้ด (แนะนำ)

### 1. Backend (Spring Boot) — อ่านตามลำดับนี้

| ลำดับ | ไฟล์ | ทำไมต้องอ่านก่อน |
|------|------|----------------|
| 1 | `entity/*.java` | รู้จักโครงสร้างข้อมูล/ตาราง DB ก่อน ถึงจะเข้าใจ service/controller |
| 2 | `repository/*.java` | รู้ว่า query ข้อมูลอย่างไรจาก DB |
| 3 | `service/*.java` | รู้ business logic หลัก (ส่วนใหญ่ที่ซับซ้อนอยู่ที่นี่) |
| 4 | `controller/*.java` | รู้ว่า frontend เรียก API อะไรได้บ้าง |
| 5 | `config/*.java` | รู้การตั้งค่า CORS, WebSocket, etc. |

### 2. Frontend (React) — อ่านตามลำดับนี้

| ลำดับ | ไฟล์ | ทำไมต้องอ่านก่อน |
|------|------|----------------|
| 1 | `App.jsx` | รู้ route ทั้งหมด หน้าไหนอยู่ path ไหน |
| 2 | `services/api.js` | รู้ว่า frontend เรียก backend API อะไร |
| 3 | `components/Layout.jsx`, `Sidebar.jsx` | รู้โครงสร้างหน้าและ navigation |
| 4 | `pages/dashboard/SprintDashboard.jsx` | หน้าแรกที่เห็น แดชบอร์ดรวม |
| 5 | `pages/dashboard/VelocityChart.jsx` | คอมโพเนนต์กราฟที่ใช้ในหลายหน้า |
| 6 | `pages/dashboard/SprintResults.jsx` | หน้ารายละเอียด sprint รายบุคคล |
| 7 | `pages/dashboard/MemberVelocityModal.jsx` | ป๊อปอัพ velocity chart รายคน |
| 8 | `pages/dashboard/JiraDetailModal.jsx` | ป๊อปอัพรายละเอียด issue จาก Jira |
| 9 | `pages/capacity/CapacityPlanning.jsx` | หน้าวางแผนความสามารถ sprint |
| 10 | `pages/settings/Configuration.jsx` | หน้าตั้งค่า team members + Jira |

---

## โครงสร้างระบบ (Architecture Overview)

```
┌─────────────────────────────────────────────────────────────┐
│                        Frontend (React)                      │
│  ┌──────────────┐ ┌─────────────┐ ┌─────────────────────┐   │
│  │ CapacityPlanning│ │ SprintDashboard│ │ SprintResults     │   │
│  └──────┬───────┘ └──────┬──────┘ └──────────┬──────────┘   │
│         │                │                    │             │
│  ┌──────┴───────┐ ┌──────┴──────┐ ┌──────────┴──────────┐   │
│  │ VelocityChart │ │ MemberVelocityModal│ │ JiraDetailModal │   │
│  └───────────────┘ └─────────────┘ └─────────────────────┘   │
│         │                │                    │             │
│         └────────────────┴────────────────────┘             │
│                         │                                    │
│              ┌──────────┴──────────┐                          │
│              │   services/api.js  │  ← REST API wrapper      │
│              └──────────┬──────────┘                          │
└─────────────────────────┼──────────────────────────────────┘
                          │ HTTP / localhost:8080/api
┌─────────────────────────┼──────────────────────────────────┐
│                         ▼                                    │
│                    Backend (Spring Boot)                     │
│  ┌─────────────────────────────────────────────────────┐      │
│  │              Controllers (REST)                      │      │
│  │  JiraController | SprintController | SprintResult... │      │
│  └─────────────────────┬───────────────────────────────┘      │
│                        │                                      │
│  ┌─────────────────────▼───────────────────────────────┐      │
│  │              Services (Business Logic)                 │      │
│  │  JiraService | SprintResultService | CapacityPlanning  │      │
│  └─────────────────────┬───────────────────────────────┘      │
│                        │                                      │
│  ┌─────────────────────▼───────────────────────────────┐      │
│  │              Repositories (JPA)                        │      │
│  └─────────────────────┬───────────────────────────────┘      │
│                        │                                      │
│  ┌─────────────────────▼───────────────────────────────┐      │
│  │              PostgreSQL Database                       │      │
│  └─────────────────────────────────────────────────────┘      │
└──────────────────────────────────────────────────────────────┘
                          │
                          ▼
                    Jira Cloud API (REST)
```

---

## ไฟล์ Backend สำคัญ

### `entity/SprintResultEntity.java`
- เก็บผลสรุปของ sprint แต่ละคน
- ฟิลด์สำคัญ: `targetPts`, `donePts`, `remainingPts`, `existingPts`, `newPts` (cards)
- และ `targetPoints`, `donePoints`, `existingPoints`, `newPoints` (story points)
- 1 row = 1 คนใน 1 sprint

### `entity/CapacityPlanningEntity.java`
- เก็บแผนความสามารถ sprint รายคน
- ฟิลด์สำคัญ: `leaveDays`, `reservePercent`, `existingPts`, `availablePts`, `acceptablePts`, `finalManDay`, `dayStatus`

### `entity/SprintEntity.java`
- เก็บข้อมูล sprint: `name`, `startDate`, `endDate`, `status` (active/future/closed)

### `entity/TeamMemberEntity.java`
- เก็บข้อมูลสมาชิกทีม: `name`, `jiraUsername`, `jiraAccountId`

### `service/JiraService.java`
- ไฟล์ที่ใหญ่และซับซ้อนที่สุด
- ทำหน้าที่เชื่อมต่อ Jira Cloud API ทั้งหมด
- ดึง sprint, issues, members, แล้วประมวลผลเป็น sprint results / capacity planning
- มี JQL query สำหรับกรอง issue type/status ที่ไม่ต้องการ
- สำคัญ: `syncSprintResults`, `syncExistingPoints`, `classifySprintIssues`, `getMemberSprintDetails`

### `service/SprintResultService.java`
- CRUD ผลสรุป sprint รายคน
- ใช้โดย `JiraService` บันทึกผลลัพธ์จาก Jira ลง DB

### `service/CapacityPlanningService.java`
- คำนวณ capacity planning: วันลา, reserve, existing points, available points
- ใช้โดย `CapacityPlanningController` และ `JiraService`

### `service/SprintService.java`
- CRUD sprint ทั้งหมด
- ใช้เก็บ sprint ที่ sync มาจาก Jira

### `service/TeamMemberService.java`
- CRUD สมาชิกทีม
- ใช้ map ระหว่าง Jira accountId กับ memberId ในระบบ

### `controller/JiraController.java`
- REST endpoints สำหรับ Jira: `/api/jira/status`, `/api/jira/sync/...`, `/api/jira/classify/{sprintId}`, `/api/jira/sprint-details/...`
- เป็นช่องทางเดียวที่ frontend ใช้คุยกับ JiraService

### `controller/SprintResultController.java`
- REST endpoints สำหรับอ่าน sprint results: `/api/sprint-results`, `/api/sprint-results/sprint/{sprintId}`
- Frontend เรียกเพื่อแสดงกราฟและตาราง

### `controller/CapacityPlanningController.java`
- REST endpoints สำหรับ capacity planning: `/api/capacity/sprint/{sprintId}`, `/api/capacity/batch-calculate`

### `controller/SprintController.java`
- REST endpoints สำหรับ sprint: `/api/sprints`

### `controller/TeamMemberController.java`
- REST endpoints สำหรับ team members: `/api/team-members`, `/api/team-members/active`

### `controller/ConfigurationController.java`
- REST endpoints สำหรับตั้งค่า: `/api/configuration/key/{key}`
- เก็บค่า `points_per_day`, `jira_domain`, `jira_email`, etc.

---

## ไฟล์ Frontend สำคัญ

### `App.jsx`
- กำหนด routes ทั้งหมด
- `/` → redirect ไป `/capacity-planning`
- `/sprint-dashboard` → SprintDashboard
- `/sprint-dashboard/:sprintId` → SprintResults
- `/capacity-planning` → CapacityPlanning
- `/configuration` → Configuration
- `/scrum-poker` → ScrumPoker

### `services/api.js`
- รวม REST API calls ทั้งหมด
- ใช้ `fetch` เรียก `http://localhost:8080/api`
- มี `sprintApi`, `teamMemberApi`, `capacityApi`, `sprintResultApi`, `configApi`, `jiraApi`
- ไฟล์นี้เป็นตัวกลางระหว่าง UI กับ backend

### `components/Layout.jsx`
- ห่อทุกหน้าไว้ในซ้อนเดียวกัน
- มี Sidebar และพื้นที่แสดงเนื้อหา

### `components/Sidebar.jsx`
- เมนูนำทางด้านซ้าย
- ระบุ path ของแต่ละหน้า

### `pages/dashboard/SprintDashboard.jsx`
- หน้าแรกของ sprint dashboard
- แสดง VelocityChart โดยรวมของทุก sprint
- โหลด sprint list + sprint results ทั้งหมด
- รีเฟรชหน้าจะ sync active/future sprints จาก Jira ก่อน แล้วค่อยแสดง

### `pages/dashboard/VelocityChart.jsx`
- คอมโพเนนต์กราฟ SVG แสดง velocity
- เปรียบเทียบ target (goal) vs done ของแต่ละ sprint
- รองรับ 2 โหมด: Cards และ Points
- แสดงทั้ง bar chart, trend line, และตารางสรุป

### `pages/dashboard/SprintResults.jsx`
- หน้ารายละเอียด sprint ที่เลือก
- แสดง KPI (velocity %, done, remaining) รายบุคคล
- มี Segmented Control สลับ Cards/Points
- กดรีเฟรชจะ sync จาก Jira ถ้า sprint เป็น active/future
- คลิกชื่อคน → เปิด JiraDetailModal
- คลิก velocity → เปิด MemberVelocityModal

### `pages/dashboard/MemberVelocityModal.jsx`
- ป๊อปอัพแสดง velocity chart ของสมาชิกคนเดียว
- ดึง sprint results ของคนนั้นทุก sprint
- แบ่งเป็น existing points (งานเก่าที่ยกมา) และ new points (งานใหม่)

### `pages/dashboard/JiraDetailModal.jsx`
- ป๊อปอัพแสดงรายการ issue ของคนนั้นใน sprint ที่เลือก
- แบ่งเป็น completed tasks และ remaining tasks
- ดึงข้อมูลจาก Jira API โดยตรง (real-time)

### `pages/capacity/CapacityPlanning.jsx`
- หน้าวางแผนความสามารถ sprint
- แสดงตารางคำนวณ manday, available points, acceptable points รายคน
- คำนวณจาก leave days, reserve percent, existing points
- รีเฟรชหน้าจะ sync existing points / sprint results จาก Jira
- มีการตั้งค่า multiplier (points per day)

### `pages/settings/Configuration.jsx`
- หน้าตั้งค่า
- จัดการ team members (CRUD)
- ตั้งค่า Jira (domain, email, token, board id, project key)
- ตั้งค่า multiplier (points per day)

---

## Data Flow สำคัญ

### 1. รีเฟรชหน้า SprintResults
```
Browser refresh
  → sessionStorage ถูกล้าง
  → loadSprintData() เรียก jiraApi.syncSprintResults(sprintId)
  → Backend ดึง issues จาก Jira ตาม JQL ที่กรองไว้
  → Backend บันทึกผลลง sprint_results
  → Frontend ดึง sprintResultApi.getBySprint(sprintId)
  → Render ตาราง + KPI
```

### 2. เปิดหน้า SprintDashboard
```
Browser refresh
  → loadData() เรียก sync ทุก active/future sprint
  → Backend ดึง + บันทึก sprint results
  → Frontend ดึง sprintResultApi.getAll()
  → VelocityChart แสดงข้อมูล
```

### 3. เปิด CapacityPlanning
```
Browser refresh
  → loadCapacityData() ตรวจสอบ capacity data ใน DB
  → ถ้ายังไม่มี: syncExistingPoints(sprintId) จาก Jira
  → ถ้ามีแล้ว: syncSprintResults(sprintId) เพื่ออัปเดต
  → ดึง capacityApi.getBySprint(sprintId)
  → Render ตาราง capacity
```

### 4. เปิด JiraDetailModal
```
คลิกชื่อคนใน SprintResults
  → JiraController.getMemberSprintDetails(sprintId, memberId)
  → JiraService ดึง issues ของคนนั้นใน sprint จาก Jira
  → แบ่ง done/remaining แล้วส่งกลับ
  → Render รายการ issue
```

---

## JQL ที่ใช้กรอง Issues (สำคัญ)

ใช้ในหลาย method ของ `JiraService.java`:

```
project=<projectKey> AND sprint="<sprintName>"
AND status not in (Cancelled, Canceled, "Technical analysis", Blocked, Backlog)
AND issueType not in subTaskIssueTypes() AND issueType != Epic
```

หมายความ:
- ไม่เอางานที่ cancel/canceled
- ไม่เอางานที่ status "Technical analysis"
- ไม่เอางานที่ status "Blocked" หรือ "Backlog"
- ไม่เอา sub-task
- ไม่เอา Epic

---

## สิ่งที่ควรระวัง

- `JiraService.java` มี 750+ บรรทัด เป็น core ที่สุด
- `customfield_10117` และ `customfield_10513` คือ story points fields ใน Jira
- `sessionStorage` ใช้ควบคุมว่า sync จาก Jira แค่ตอนรีเฟรชหน้า ไม่ใช่ทุกการ render
- `BigDecimal` ใช้ทุกที่ที่เกี่ยวกับคะแนน เพื่อความแม่นยำทางการเงิน
