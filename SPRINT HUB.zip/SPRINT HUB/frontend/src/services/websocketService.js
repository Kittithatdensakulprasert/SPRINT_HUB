import { Client } from '@stomp/stompjs';

const API_HOST = `${window.location.protocol}//${window.location.hostname}:8080`;
const WS_URL = `ws://${window.location.hostname}:8080/ws`;

class WebSocketService {
  constructor() {
    this.stompClient = null;
    this.connected = false;
    this.pending = [];
    this.currentRoomId = null;
    this.messageHandler = null;
  }

  connect(roomId, onMessageReceived) {
    this.disconnect();
    this.currentRoomId = roomId;
    this.messageHandler = onMessageReceived;
    this.stompClient = new Client({
      brokerURL: WS_URL,
      connectHeaders: {},
      debug: () => {},
      reconnectDelay: 5000,
      heartbeatIncoming: 4000,
      heartbeatOutgoing: 4000,
    });

    this.stompClient.onConnect = () => {
      this.connected = true;

      this.stompClient.subscribe(`/topic/room/${roomId}`, (message) => {
        const roomData = JSON.parse(message.body);
        this.messageHandler?.(roomData);
      });

      this.flushPending();
    };

    this.stompClient.onStompError = (frame) => {
      this.connected = false;
      console.error('STOMP error', frame);
    };

    this.stompClient.onWebSocketClose = () => {
      this.connected = false;
    };

    this.stompClient.onWebSocketError = (event) => {
      this.connected = false;
      console.error('WebSocket error', event);
    };

    this.stompClient.activate();
  }

  disconnect() {
    if (this.stompClient) {
      this.stompClient.deactivate();
    }
    this.connected = false;
    this.pending = [];
  }

  isConnected() {
    return this.connected;
  }

  flushPending() {
    while (this.connected && this.pending.length > 0) {
      const { destination, body } = this.pending.shift();
      this.stompClient.publish({ destination, body });
    }
  }

  send(destination, body) {
    if (this.connected && this.stompClient) {
      this.stompClient.publish({ destination, body });
    } else {
      this.pending.push({ destination, body });
    }
  }

  vote(roomId, userId, vote) {
    this.send('/app/vote', JSON.stringify({ roomId, userId, vote }));
  }

  revealCards(roomId) {
    this.send('/app/reveal', JSON.stringify({ roomId }));
  }

  resetVotes(roomId) {
    this.send('/app/reset', JSON.stringify({ roomId }));
  }

  async leaveRoom(roomId, userId) {
    try {
      await fetch(`${API_HOST}/api/rooms/leave`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ roomId, userId })
      });
    } catch (error) {
      // ignore leave error
    }
  }
}

export default new WebSocketService();
