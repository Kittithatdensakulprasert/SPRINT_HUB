import { Client } from '@stomp/stompjs';

class WebSocketService {
  constructor() {
    this.stompClient = null;
    this.connected = false;
  }

  connect(roomId, onMessageReceived) {
    this.stompClient = new Client({
      brokerURL: 'ws://localhost:8080/ws',
      connectHeaders: {},
      debug: () => {},
      reconnectDelay: 5000,
      heartbeatIncoming: 4000,
      heartbeatOutgoing: 4000,
    });

    this.stompClient.onConnect = () => {
      this.connected = true;

      this.stompClient.subscribe(`/topic/room/${roomId}`, (message) => {
        const roomData = JSON.parse(message.body);
        onMessageReceived(roomData);
      });
    };

    this.stompClient.onStompError = () => {
      this.connected = false;
    };

    this.stompClient.onWebSocketClose = () => {
      this.connected = false;
    };

    this.stompClient.activate();
  }

  disconnect() {
    if (this.stompClient && this.connected) {
      this.stompClient.deactivate();
      this.connected = false;
    }
  }

  vote(roomId, userId, vote) {
    if (this.stompClient && this.connected) {
      this.stompClient.publish({
        destination: '/app/vote',
        body: JSON.stringify({ roomId, userId, vote })
      });
    }
  }

  revealCards(roomId) {
    if (this.stompClient && this.connected) {
      this.stompClient.publish({
        destination: '/app/reveal',
        body: JSON.stringify({ roomId })
      });
    }
  }

  resetVotes(roomId) {
    if (this.stompClient && this.connected) {
      this.stompClient.publish({
        destination: '/app/reset',
        body: JSON.stringify({ roomId })
      });
    }
  }

  async leaveRoom(roomId, userId) {
    try {
      await fetch('http://localhost:8080/api/rooms/leave', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ roomId, userId })
      });
    } catch (error) {
      // ignore leave error
    }
  }
}

export default new WebSocketService();
