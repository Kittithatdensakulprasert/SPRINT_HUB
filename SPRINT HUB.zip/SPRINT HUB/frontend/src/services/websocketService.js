import { Client } from '@stomp/stompjs';

class WebSocketService {
  constructor() {
    this.stompClient = null;
    this.connected = false;
  }

  connect(roomId, onMessageReceived) {
    console.log('Connecting to WebSocket for room:', roomId);
    this.stompClient = new Client({
      brokerURL: 'ws://localhost:8080/ws',
      connectHeaders: {},
      debug: (str) => console.log('WebSocket debug:', str),
      reconnectDelay: 5000,
      heartbeatIncoming: 4000,
      heartbeatOutgoing: 4000,
    });

    this.stompClient.onConnect = () => {
      this.connected = true;
      console.log('WebSocket connected successfully');

      this.stompClient.subscribe(`/topic/room/${roomId}`, (message) => {
        console.log('Received WebSocket message:', message.body);
        const roomData = JSON.parse(message.body);
        onMessageReceived(roomData);
      });
    };

    this.stompClient.onStompError = (frame) => {
      console.error('WebSocket error:', frame);
      this.connected = false;
    };

    this.stompClient.onWebSocketClose = () => {
      console.log('WebSocket connection closed');
      this.connected = false;
    };

    this.stompClient.activate();
  }

  disconnect() {
    if (this.stompClient && this.connected) {
      this.stompClient.deactivate();
      this.connected = false;
      console.log('WebSocket disconnected');
    }
  }

  vote(roomId, userId, vote) {
    console.log('Sending vote:', { roomId, userId, vote });
    if (this.stompClient && this.connected) {
      this.stompClient.publish({
        destination: '/app/vote',
        body: JSON.stringify({ roomId, userId, vote })
      });
    } else {
      console.error('WebSocket not connected');
    }
  }

  revealCards(roomId) {
    if (this.stompClient && this.connected) {
      this.stompClient.publish({
        destination: '/app/reveal',
        body: JSON.stringify({ roomId })
      });
    }
  }

  resetVotes(roomId) {
    if (this.stompClient && this.connected) {
      this.stompClient.publish({
        destination: '/app/reset',
        body: JSON.stringify({ roomId })
      });
    }
  }

  async leaveRoom(roomId, userId) {
    try {
      await fetch('http://localhost:8080/api/rooms/leave', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ roomId, userId })
      });
      console.log('User left room:', userId);
    } catch (error) {
      console.error('Error leaving room:', error);
    }
  }
}

export default new WebSocketService();
