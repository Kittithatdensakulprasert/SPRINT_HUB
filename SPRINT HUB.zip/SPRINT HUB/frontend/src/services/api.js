const BASE_URL = '/api';

const request = async (path, options = {}) => {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    cache: 'no-store',
    ...options,
  });
  if (!res.ok) throw new Error(`API error ${res.status}: ${path}`);
  if (res.status === 204) return null;
  return res.json();
};

export const sprintApi = {
  getAll: () => request('/sprints'),
  getById: (id) => request(`/sprints/${id}`),
  create: (body) => request('/sprints', { method: 'POST', body: JSON.stringify(body) }),
  update: (id, body) => request(`/sprints/${id}`, { method: 'PUT', body: JSON.stringify(body) }),
  delete: (id) => request(`/sprints/${id}`, { method: 'DELETE' }),
};

export const teamMemberApi = {
  getAll: () => request('/team-members'),
  getActive: () => request('/team-members/active'),
  create: (body) => request('/team-members', { method: 'POST', body: JSON.stringify(body) }),
  update: (id, body) => request(`/team-members/${id}`, { method: 'PUT', body: JSON.stringify(body) }),
  delete: (id) => request(`/team-members/${id}`, { method: 'DELETE' }),
};

export const capacityApi = {
  getBySprint: (sprintId) => request(`/capacity/sprint/${sprintId}`),
  batchCalculate: (body) => request('/capacity/batch-calculate', { method: 'POST', body: JSON.stringify(body) }),
};

export const sprintResultApi = {
  getAll: () => request('/sprint-results'),
  getBySprint: (sprintId) => request(`/sprint-results/sprint/${sprintId}`),
  batch: (body) => request('/sprint-results/batch', { method: 'POST', body: JSON.stringify(body) }),
};

export const configApi = {
  getAll: () => request('/configuration'),
  getByKey: (key) => request(`/configuration/key/${key}`),
  updateByKey: (key, value) => request(`/configuration/key/${key}`, { method: 'PUT', body: JSON.stringify({ value: String(value) }) }),
};

export const jiraApi = {
  getStatus: () => request('/jira/status'),
  saveConfig: (body) => request('/jira/config', { method: 'POST', body: JSON.stringify(body) }),
  syncSprints: () => request('/jira/sync/sprints', { method: 'POST' }),
  syncExistingPoints: (sprintId) => request(`/jira/sync/existing-points/${sprintId}`, { method: 'POST' }),
  syncSprintResults: (sprintId) => request(`/jira/sync/sprint-results/${sprintId}`, { method: 'POST' }),
  syncAllSprintResults: () => request('/jira/sync/sprint-results/all', { method: 'POST' }),
  getMemberSprintDetails: (sprintId, memberId) => request(`/jira/sprint-details/${sprintId}/member/${memberId}`),
  getMembers: () => request('/jira/members'),
  importMembers: () => request('/jira/import/members', { method: 'POST' }),
};
