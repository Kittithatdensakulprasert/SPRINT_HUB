import React, { useEffect, useState } from 'react';
import { jiraApi } from '../../services/api';

const JiraDetailModal = ({ member, sprintId, onClose }) => {
  const [details, setDetails] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchDetails = async () => {
      if (!sprintId || !member?.id) return;
      setLoading(true);
      try {
        const data = await jiraApi.getMemberSprintDetails(sprintId, member.id);
        setDetails(data);
      } catch (e) {
        setError('โหลดข้อมูลไม่สำเร็จ');
      } finally {
        setLoading(false);
      }
    };
    fetchDetails();
  }, [sprintId, member?.id]);

  const completedTasks = details?.completedTasks || [];
  const remainingTasks = details?.remainingTasks || [];
  const initials = member.name.split(' ').map(w => w[0]).slice(0, 2).join('');

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden border border-gray-100">

        {/* Header */}
        <div className="px-6 py-4 flex justify-between items-center border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-slate-700 text-white flex items-center justify-center text-sm font-bold shrink-0">
              {initials}
            </div>
            <div>
              <p className="font-bold text-gray-900 text-sm">{member.name}</p>
              <p className="text-xs text-gray-400">{member.jiraUsername} · {details?.sprintName || 'Sprint'}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 p-1.5 rounded-lg hover:bg-gray-100 transition cursor-pointer border-0 bg-transparent"
          >
            <span className="material-icons text-xl">close</span>
          </button>
        </div>

        {/* Summary stats */}
        <div className="grid grid-cols-3 divide-x divide-gray-100 border-b border-gray-100 bg-gray-50">
          <div className="px-5 py-3 text-center">
            <p className="text-lg font-bold text-gray-800">{completedTasks.length + remainingTasks.length}</p>
            <p className="text-xs text-gray-400 mt-0.5">งานทั้งหมด</p>
          </div>
          <div className="px-5 py-3 text-center">
            <p className="text-lg font-bold text-emerald-600">{completedTasks.length}</p>
            <p className="text-xs text-gray-400 mt-0.5">เสร็จแล้ว</p>
          </div>
          <div className="px-5 py-3 text-center">
            <p className="text-lg font-bold text-amber-500">{remainingTasks.length}</p>
            <p className="text-xs text-gray-400 mt-0.5">ค้างอยู่</p>
          </div>
        </div>

        {/* Task lists */}
        <div className="p-5 space-y-5 max-h-[360px] overflow-y-auto">
          {loading ? (
            <p className="text-center text-sm text-gray-400 py-8">กำลังโหลดข้อมูล Jira...</p>
          ) : error ? (
            <p className="text-center text-sm text-red-500 py-8">{error}</p>
          ) : (
            <>
              {/* Completed */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0"></span>
                  <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">เสร็จสมบูรณ์ ({completedTasks.length} cards)</span>
                </div>
                {completedTasks.length === 0 ? (
                  <p className="text-sm text-gray-400 italic pl-4">ไม่มีงานที่เสร็จสมบูรณ์</p>
                ) : (
                  <div className="space-y-2">
                    {completedTasks.map((task) => (
                      <div key={task.id} className="flex items-start justify-between gap-3 p-3 bg-white rounded-xl border border-gray-100 hover:border-emerald-200 hover:bg-emerald-50/30 transition">
                        <div className="flex items-start gap-2.5 min-w-0">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 shrink-0"></span>
                          <div className="min-w-0">
                            <span className="text-[10px] font-bold text-gray-400 uppercase">{task.id}</span>
                            <p className="text-sm text-gray-800 font-medium leading-snug mt-0.5">{task.title}</p>
                          </div>
                        </div>
                        <span className="text-xs font-bold bg-emerald-100 text-emerald-700 px-2 py-1 rounded-lg shrink-0">{task.points} pts</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Remaining */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <span className="w-2 h-2 rounded-full bg-amber-400 shrink-0"></span>
                  <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">ค้างอยู่ ({remainingTasks.length} cards)</span>
                </div>
                {remainingTasks.length === 0 ? (
                  <p className="text-sm text-gray-400 italic pl-4">ไม่มีงานค้าง</p>
                ) : (
                  <div className="space-y-2">
                    {remainingTasks.map((task) => (
                      <div key={task.id} className="flex items-start justify-between gap-3 p-3 bg-white rounded-xl border border-gray-100 hover:border-amber-200 hover:bg-amber-50/30 transition">
                        <div className="flex items-start gap-2.5 min-w-0">
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-2 shrink-0"></span>
                          <div className="min-w-0">
                            <span className="text-[10px] font-bold text-gray-400 uppercase">{task.id}</span>
                            <p className="text-sm text-gray-800 font-medium leading-snug mt-0.5">{task.title}</p>
                          </div>
                        </div>
                        <span className="text-xs font-bold bg-amber-100 text-amber-700 px-2 py-1 rounded-lg shrink-0">{task.points} pts</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </>
          )}
        </div>

      </div>
    </div>
  );
};

export default JiraDetailModal;
