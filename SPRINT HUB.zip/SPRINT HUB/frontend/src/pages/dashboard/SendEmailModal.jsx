import React, { useState, useEffect } from 'react';
import { teamMemberApi } from '../../services/api';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

const isValidEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

export default function SendEmailModal({ isOpen, onClose, onConfirm, sprintName, isGenerating, contentRef }) {
  const [members, setMembers] = useState([]);
  const [checkedIds, setCheckedIds] = useState([]);
  const [manualInput, setManualInput] = useState('');
  const [manualError, setManualError] = useState('');
  const [manualList, setManualList] = useState([]);
  const [step, setStep] = useState('select');
  const [subject, setSubject] = useState('');
  const [bodyText, setBodyText] = useState('');
  const [pdfDataUrl, setPdfDataUrl] = useState(null);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [showSendConfirm, setShowSendConfirm] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    setStep('select');
    setShowSendConfirm(false);
    setCheckedIds([]);
    setManualInput('');
    setManualError('');
    setManualList([]);
    setSubject(`สรุปผล ${sprintName || 'Sprint'}`);
    setBodyText(`${sprintName || 'Sprint'}\n\nสรุปผลการทำงานของ ${sprintName || 'Sprint'} \nรายละเอียดอยู่ในไฟล์แนบ PDF`);
    teamMemberApi.getActive()
      .then(data => setMembers(data.filter(m => m.email && m.email.includes('@'))))
      .catch(() => setMembers([]));
  }, [isOpen, sprintName]);

  if (!isOpen) return null;

  const memberEmails = members.filter(m => checkedIds.includes(m.id)).map(m => m.email);
  const allRecipients = [...new Set([...memberEmails, ...manualList])];

  const toggleMember = (id) => setCheckedIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);

  const addManual = () => {
    const email = manualInput.trim().toLowerCase();
    if (!isValidEmail(email)) { setManualError('รูปแบบอีเมลไม่ถูกต้อง'); return; }
    if (allRecipients.includes(email)) { setManualError('อีเมลนี้เพิ่มแล้ว'); return; }
    setManualList(prev => [...prev, email]);
    setManualInput('');
    setManualError('');
  };

  const removeManual = (email) => setManualList(prev => prev.filter(e => e !== email));

  const goToConfirm = async () => {
    setStep('confirm');
    if (!pdfDataUrl && contentRef?.current) {
      setIsGeneratingPdf(true);
      try {
        const el = contentRef.current;

        // ซ่อน no-print elements ก่อน capture
        const noPrintEls = el.querySelectorAll('.no-print');
        noPrintEls.forEach(e => { e._prevDisplay = e.style.display; e.style.display = 'none'; });

        const canvas = await html2canvas(el, {
          scale: 2.5,
          useCORS: true,
          backgroundColor: '#f8fafc',
          logging: false,
          windowWidth: el.scrollWidth,
          windowHeight: el.scrollHeight,
        });

        // คืนค่า visibility
        noPrintEls.forEach(e => { e.style.display = e._prevDisplay || ''; });

        const pdf = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
        const pageW = 297;
        const pageH = 210;
        const margin = 10;
        const contentW = pageW - margin * 2;

        const imgHeightTotal = (canvas.height * contentW) / canvas.width;
        let yOffset = 0;
        let pageNum = 0;

        while (yOffset < imgHeightTotal) {
          if (pageNum > 0) pdf.addPage();

          pdf.setFillColor(255, 255, 255);
          pdf.rect(0, 0, pageW, pageH, 'F');

          const sliceH = Math.min(pageH - margin * 2, imgHeightTotal - yOffset);
          const srcY = (yOffset / imgHeightTotal) * canvas.height;
          const srcH = (sliceH / imgHeightTotal) * canvas.height;

          const sliceCanvas = document.createElement('canvas');
          sliceCanvas.width = canvas.width;
          sliceCanvas.height = srcH;
          const ctx = sliceCanvas.getContext('2d');
          ctx.drawImage(canvas, 0, srcY, canvas.width, srcH, 0, 0, canvas.width, srcH);

          pdf.addImage(sliceCanvas.toDataURL('image/png'), 'PNG', margin, margin, contentW, sliceH, undefined, 'FAST');

          yOffset += sliceH;
          pageNum++;
        }

        setPdfDataUrl(pdf.output('datauristring'));
      } catch (e) {
        console.error('PDF preview error', e);
      } finally {
        setIsGeneratingPdf(false);
      }
    }
  };

  const openPdfPreview = () => {
    if (!pdfDataUrl) return;
    const win = window.open();
    win.document.write(`<iframe src="${pdfDataUrl}" style="width:100%;height:100%;border:none"></iframe>`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4" onClick={onClose}>
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden" onClick={e => e.stopPropagation()}>

        {/* Header — same pattern as MemberVelocityModal */}
        <div className="flex items-center justify-between px-6 pt-6 pb-4 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-slate-700 text-white flex items-center justify-center text-sm font-bold shrink-0">
              <span className="material-icons text-lg">forward_to_inbox</span>
            </div>
            <div>
              <h2 className="text-lg font-bold text-gray-900">ส่งรายงาน Sprint</h2>
              <p className="text-xs text-gray-400">{sprintName}</p>
            </div>
          </div>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition">
            <span className="material-icons text-lg">close</span>
          </button>
        </div>

        <div className="px-6 py-5 space-y-5 max-h-[55vh] overflow-y-auto">
          {step === 'select' ? (
            <>
              {/* รายชื่อทีม */}
              <div>
                <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">สมาชิกในทีม</p>
                {members.length > 0 ? (
                  <div className="space-y-0.5">
                    {members.map((m) => (
                      <label key={m.id} className={`flex items-center gap-3 px-3 py-2.5 rounded-xl cursor-pointer transition-colors hover:bg-gray-50 ${checkedIds.includes(m.id) ? 'bg-amber-50/60' : ''}`}>
                        <div className="w-9 h-9 rounded-full bg-slate-700 text-white flex items-center justify-center text-sm font-bold shrink-0">
                          {m.name.split(' ').map(w => w[0]).slice(0, 2).join('')}
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-semibold text-gray-800 truncate">{m.name}</p>
                          <p className="text-xs text-gray-400 truncate">{m.email}</p>
                        </div>
                        <input
                          type="checkbox"
                          checked={checkedIds.includes(m.id)}
                          onChange={() => toggleMember(m.id)}
                          className="w-4 h-4 accent-amber-500 shrink-0"
                        />
                      </label>
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-2 py-6 text-gray-400">
                    <span className="material-icons text-3xl">people_outline</span>
                    <p className="text-sm">ไม่พบรายชื่อทีมที่มีอีเมล</p>
                    <p className="text-xs">กด Import Members ใน Jira Settings ก่อน</p>
                  </div>
                )}
              </div>

              {/* พิมพ์ email เพิ่มเติม */}
              <div>
                <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">หรือพิมพ์อีเมลเพิ่มเติม</p>
                <div className="flex gap-2">
                  <input
                    type="email"
                    value={manualInput}
                    onChange={e => { setManualInput(e.target.value); setManualError(''); }}
                    onKeyDown={e => e.key === 'Enter' && addManual()}
                    placeholder="example@company.com"
                    className="flex-1 text-sm px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-amber-300 focus:border-amber-400 transition bg-white"
                  />
                  <button onClick={addManual} className="px-4 py-2.5 bg-gray-800 text-white rounded-xl text-sm font-semibold hover:bg-gray-700 transition shrink-0">
                    เพิ่ม
                  </button>
                </div>
                {manualError && <p className="text-xs text-red-500 mt-1.5 ml-1">{manualError}</p>}
                {manualList.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-3">
                    {manualList.map(email => (
                      <span key={email} className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-gray-100 text-gray-700 rounded-full text-xs font-medium">
                        {email}
                        <button onClick={() => removeManual(email)} className="text-gray-400 hover:text-gray-700 transition ml-0.5">
                          <span className="material-icons" style={{fontSize:'12px'}}>close</span>
                        </button>
                      </span>
                    ))}
                  </div>
                )}
              </div>

            </>
          ) : (
            <>
              <div>
                <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">ส่งถึง {allRecipients.length} คน</p>
                <div className="space-y-0.5">
                  {allRecipients.map((email) => (
                    <div key={email} className="flex items-center gap-3 px-3 py-2.5 rounded-xl bg-gray-50">
                      <span className="w-7 h-7 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center shrink-0">
                        <span className="material-icons text-sm">check</span>
                      </span>
                      <span className="text-sm text-gray-700">{email}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">หัวข้ออีเมล</label>
                <input
                  type="text"
                  value={subject}
                  onChange={e => setSubject(e.target.value)}
                  className="w-full text-sm px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-amber-300 focus:border-amber-400 transition"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">ข้อความ</label>
                <textarea
                  value={bodyText}
                  onChange={e => setBodyText(e.target.value)}
                  rows={4}
                  className="w-full text-sm px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-amber-300 focus:border-amber-400 transition resize-none"
                />
              </div>

              {/* ไฟล์แนบ */}
              <div>
                <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">ไฟล์แนบ</p>
                <div className="flex items-center gap-3 px-4 py-3 rounded-xl border border-gray-200 bg-gray-50">
                  <div className="w-9 h-9 rounded-lg bg-red-100 text-red-500 flex items-center justify-center shrink-0">
                    <span className="material-icons text-base">picture_as_pdf</span>
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold text-gray-800 truncate">sprint-report.pdf</p>
                    <p className="text-xs text-gray-400">{isGeneratingPdf ? 'กำลังสร้าง PDF...' : 'PDF Document'}</p>
                  </div>
                  <button
                    onClick={openPdfPreview}
                    disabled={!pdfDataUrl || isGeneratingPdf}
                    className="inline-flex items-center gap-1 text-xs font-semibold text-gray-600 hover:text-gray-900 hover:bg-gray-200 px-3 py-1.5 rounded-lg transition disabled:opacity-40 disabled:cursor-not-allowed"
                  >
                    <span className="material-icons text-sm">open_in_new</span>
                    เปิดดู
                  </button>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-gray-100 flex justify-between items-center">
          {step === 'select' ? (
            <>
              <button onClick={onClose} className="text-sm text-gray-500 hover:text-gray-700 font-semibold px-3 py-1.5 rounded-lg hover:bg-gray-100 transition">
                ยกเลิก
              </button>
              <button
                onClick={goToConfirm}
                disabled={allRecipients.length === 0}
                className="inline-flex items-center gap-2 px-5 py-2 rounded-xl bg-gray-800 text-white text-sm font-bold hover:bg-gray-700 disabled:opacity-40 disabled:cursor-not-allowed transition"
              >
                {allRecipients.length > 0 && (
                  <span className="bg-white/20 text-white text-xs font-bold px-1.5 py-0.5 rounded-md">{allRecipients.length}</span>
                )}
                ถัดไป <span className="material-icons text-sm">arrow_forward</span>
              </button>
            </>
          ) : (
            <>
              <button
                onClick={() => setStep('select')}
                className="inline-flex items-center gap-1 text-xs font-semibold text-slate-500 hover:text-amber-700 hover:bg-amber-50 px-2.5 py-1.5 rounded-lg border border-gray-200 hover:border-amber-300 transition"
              >
                <span className="material-icons text-sm">arrow_back</span>
                ย้อนกลับ
              </button>
              <button
                onClick={() => setShowSendConfirm(true)}
                disabled={isGenerating || isGeneratingPdf}
                className="inline-flex items-center gap-2 px-5 py-2 rounded-xl bg-gray-800 text-white text-sm font-bold hover:bg-gray-700 disabled:opacity-60 disabled:cursor-not-allowed transition"
              >
                {isGenerating
                  ? <><span className="material-icons text-sm animate-spin">sync</span>กำลังส่ง...</>
                  : <><span className="material-icons text-sm">send</span>ส่งอีเมล</>
                }
              </button>
            </>
          )}
        </div>
      </div>

      {/* Confirm dialog */}
      {showSendConfirm && (
        <div className="absolute inset-0 bg-black/40 backdrop-blur-sm rounded-2xl flex items-center justify-center z-10" onClick={e => e.stopPropagation()}>
          <div className="bg-white rounded-2xl shadow-xl p-6 mx-6 w-full max-w-sm">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center shrink-0">
                <span className="material-icons text-amber-500">send</span>
              </div>
              <div>
                <p className="text-sm font-bold text-gray-900">ยืนยันการส่งอีเมล</p>
                <p className="text-xs text-gray-400 mt-0.5">จะส่งถึง {allRecipients.length} ที่อยู่</p>
              </div>
            </div>
            <div className="bg-gray-50 rounded-xl px-4 py-3 mb-4 space-y-0.5 max-h-32 overflow-y-auto">
              {allRecipients.map(r => (
                <p key={r} className="text-xs text-gray-600 truncate">{r}</p>
              ))}
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setShowSendConfirm(false)}
                className="flex-1 py-2 rounded-xl border border-gray-200 text-sm font-semibold text-gray-600 hover:bg-gray-50 transition"
              >
                ยกเลิก
              </button>
              <button
                onClick={() => { setShowSendConfirm(false); onConfirm({ recipients: allRecipients, subject, bodyText, pdfDataUrl }); }}
                className="flex-1 py-2 rounded-xl bg-gray-800 text-white text-sm font-bold hover:bg-gray-700 transition"
              >
                ยืนยัน
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
