/**
 * WorkDistributionChart.jsx
 * แสดง Trend ของ Issue Type ย้อนหลังทุก sprint (stacked bar)
 * กดชื่อ sprint → navigate ไปหน้า /sprint-dashboard/distribution/:sprintId
 *
 * Props:
 * - sprints: array ของ sprint ทั้งหมด
 * - jiraConfigured: boolean
 */

import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { jiraApi } from '../../services/api';

const TYPE_COLORS = {
  Functional: '#10b981',
  Defect:     '#ef4444',
  Default:    '#8b5cf6',
};

const SYSTEM_COLORS = [
  '#f59e0b','#06b6d4','#ec4899','#84cc16','#6366f1','#14b8a6','#f97316','#a855f7',
];

const normalizeType  = (type) => {
  if (type === 'Task' || type === 'Story') return 'Functional';
  if (type === 'Bug') return 'Defect';
  return type;
};
const getTypeColor   = (type) => TYPE_COLORS[normalizeType(type)] || TYPE_COLORS.Default;
const getSystemColor = (idx)  => SYSTEM_COLORS[idx % SYSTEM_COLORS.length];

const WorkDistributionChart = ({ sprints, jiraConfigured }) => {
  const navigate = useNavigate();
  const [trendData, setTrendData] = useState([]);
  const [showAll, setShowAll] = useState(false);
  const [tooltip, setTooltip] = useState(null);

  useEffect(() => {
    if (sprints.length > 0) loadTrend();
  }, [sprints, showAll]);

  // ฟัง jira-sync-done จาก SprintDashboard เพื่อ reload หลัง sync เสร็จ
  useEffect(() => {
    const handleSyncDone = () => loadTrend(true);
    window.addEventListener('jira-sync-done', handleSyncDone);
    return () => window.removeEventListener('jira-sync-done', handleSyncDone);
  }, [sprints, showAll]);

  const loadTrend = useCallback(async (skipAutoSync = false) => {
    if (sprints.length === 0) return;
    const sorted = [...sprints].sort((a, b) => a.id - b.id);
    const display = showAll ? sorted : sorted.slice(-10);
    try {
      const data = await jiraApi.getDistributionTrend(display.map(s => s.id));
      // ถ้าไม่มีข้อมูลเลยและ Jira พร้อม → auto sync ทุก sprint
      const hasData = data && data.length > 0 && data.some(d => d.totalCount > 0);
      if (!hasData && !skipAutoSync && jiraConfigured) {
        window.dispatchEvent(new CustomEvent('jira-dist-syncing'));
        await jiraApi.syncAllDistribution().catch(() => null);
        const fresh = await jiraApi.getDistributionTrend(display.map(s => s.id));
        setTrendData(fresh || []);
        window.dispatchEvent(new CustomEvent('jira-sync-done', { detail: { success: true } }));
      } else {
        setTrendData(data || []);
      }
    } catch {
      setTrendData([]);
    }
  }, [sprints, showAll, jiraConfigured]);

  const sorted = [...sprints].sort((a, b) => a.id - b.id);
  const trendSprints = showAll ? sorted : sorted.slice(-10);
  const TYPE_ORDER = ['Functional', 'Defect'];
  const rawTypes = [...new Set(trendData.map(d => normalizeType(d.issueType)))];
  const allTypes = [
    ...TYPE_ORDER.filter(t => rawTypes.includes(t)),
    ...rawTypes.filter(t => !TYPE_ORDER.includes(t)).sort(),
  ];

  const trendBySprint = trendSprints.map(sprint => {
    const rows = trendData.filter(d => d.sprintId === sprint.id);
    const total = rows.reduce((s, d) => s + d.totalCount, 0);
    const typeCounts = allTypes.reduce((acc, t) => {
      acc[t] = rows.filter(d => normalizeType(d.issueType) === t).reduce((s, d) => s + d.totalCount, 0);
      return acc;
    }, {});
    return { sprint, total, typeCounts };
  });

  const hasAnyData = trendBySprint.some(d => d.total > 0);
  const rawMax  = Math.max(...trendBySprint.map(d => d.total), 1);
  const maxVal  = Math.ceil(rawMax / 10) * 10;
  const yTicks  = [0, maxVal * 0.25, maxVal * 0.5, maxVal * 0.75, maxVal].map(v => Math.round(v));

  const chartH   = 220;
  const groupW   = 70;
  const barW     = 32;
  const leftPad  = 50;
  const rightPad = 20;
  const chartW   = Math.max(400, trendBySprint.length * groupW + leftPad + rightPad);

  const toY = (val) => chartH - (val / maxVal) * chartH * 0.85;

  if (!hasAnyData) {
    return (
      <div className="h-64 bg-slate-50 border-2 border-dashed border-gray-200 rounded-xl flex flex-col items-center justify-center gap-2">
        <span className="material-icons text-4xl text-gray-200">bar_chart</span>
        <p className="text-sm font-medium text-gray-400">Work Distribution</p>
        <p className="text-xs text-gray-300">กด Sync เพื่อดึงข้อมูลจาก Jira</p>
      </div>
    );
  }

  const displayName = (name) => {
    const m = name.match(/(\d{2,4})$/);
    return m ? m[1] : name.slice(0, 8);
  };

  return (
    <div className="space-y-4">
      {/* Controls row — เหมือน VelocityChart */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5">
          {allTypes.map(type => (
            <div key={type} className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: getTypeColor(type) }} />
              <span className="text-xs text-gray-500">{type}</span>
            </div>
          ))}
        </div>
        <div className="flex items-center gap-3">
          {sprints.length > 10 && (
            <button
              onClick={() => setShowAll(!showAll)}
              className="text-xs font-semibold text-slate-500 hover:text-blue-700 bg-white border border-gray-200 hover:border-blue-300 rounded-lg px-3 py-1.5 transition cursor-pointer"
            >
              {showAll ? 'แสดง 10 ล่าสุด' : `แสดงทั้งหมด (${sprints.length})`}
            </button>
          )}
        </div>
      </div>

      {/* SVG stacked bar chart */}
      <div className="w-full overflow-x-auto pb-2">
        <div style={{ minWidth: `${chartW}px` }}>
          <svg viewBox={`0 0 ${chartW} ${chartH + 55}`} className="w-full" style={{ minHeight: '260px' }}>
            {/* Y axis grid + labels */}
            {yTicks.map((tick, i) => {
              const y = toY(tick) + 10;
              return (
                <g key={i}>
                  <line x1={leftPad} y1={y} x2={chartW - rightPad} y2={y} stroke="#f0f0f0" strokeWidth="1" />
                  <text x={leftPad - 8} y={y + 4} textAnchor="end" fontSize="10" fill="#9ca3af">{tick}</text>
                </g>
              );
            })}

            {/* X axis */}
            <line x1={leftPad} y1={chartH + 10} x2={chartW - rightPad} y2={chartH + 10} stroke="#e5e7eb" strokeWidth="1" />

            {/* X axis label */}
            <text x={chartW - rightPad + 15} y={chartH + 24} textAnchor="end" fontSize="8" fontWeight="600" fill="#6b7280">sprint</text>

            {/* Y axis label */}
            <text x={leftPad - 8} y={14} textAnchor="end" fontSize="8" fontWeight="600" fill="#6b7280">cards</text>

            {/* clipPath defs — มุมมนบนสุดของแต่ละ bar */}
            <defs>
              {trendBySprint.map(({ sprint, total }, i) => {
                const x      = leftPad + i * groupW + (groupW - barW) / 2;
                const fullH  = chartH * 0.85 * (total / maxVal);
                const barTop = toY(total) + 10;
                return (
                  <clipPath key={sprint.id} id={`clip-dist-${sprint.id}`}>
                    <rect x={x} y={barTop} width={barW} height={fullH} rx="3" />
                  </clipPath>
                );
              })}
            </defs>

            {/* Bars */}
            {trendBySprint.map(({ sprint, total, typeCounts }, i) => {
              const x      = leftPad + i * groupW + (groupW - barW) / 2;
              const fullH  = chartH * 0.85 * (total / maxVal);
              const barTop = toY(total) + 10;
              let stackY   = barTop;

              const showTip = (e) => {
                setTooltip({
                  x: e.clientX + window.scrollX,
                  y: e.clientY - 12 + window.scrollY,
                  lines: [
                    sprint.name,
                    ...allTypes.filter(t => typeCounts[t] > 0).map(t => `${t}: ${typeCounts[t]}`),
                    `รวม ${total} cards`,
                  ],
                });
              };
              const moveTip = (e) => setTooltip(prev => prev ? { ...prev, x: e.clientX + window.scrollX, y: e.clientY - 12 + window.scrollY } : null);
              const hideTip = () => setTooltip(null);

              return (
                <g
                  key={sprint.id}
                  className="cursor-pointer group"
                  onClick={() => navigate(`/sprint-dashboard/distribution/${sprint.id}`)}
                  onMouseEnter={showTip}
                  onMouseMove={moveTip}
                  onMouseLeave={hideTip}
                >
                  {/* Stacked segments — ครอบด้วย clipPath เพื่อให้มุมบนมน */}
                  <g clipPath={`url(#clip-dist-${sprint.id})`}>
                    {allTypes.map((type) => {
                      const count = typeCounts[type] || 0;
                      const segH  = total > 0 ? fullH * (count / total) : 0;
                      const segY  = stackY;
                      stackY += segH;
                      return segH > 0 ? (
                        <rect
                          key={type}
                          x={x} y={segY} width={barW} height={segH}
                          fill={getTypeColor(type)}
                          opacity="0.9"
                        />
                      ) : null;
                    })}
                    {/* Hover highlight overlay */}
                    {total > 0 && (
                      <rect x={x} y={barTop} width={barW} height={fullH}
                        fill="white" opacity="0" className="group-hover:opacity-10" />
                    )}
                  </g>

                  {/* Total label on top */}
                  {total > 0 && (
                    <text x={x + barW / 2} y={barTop - 5} textAnchor="middle" fontSize="9" fontWeight="700" fill="#4b5563">
                      {total}
                    </text>
                  )}

                  {/* Sprint name */}
                  <text
                    x={x + barW / 2} y={chartH + 24}
                    textAnchor="middle" fontSize="9" fontWeight="700"
                    className="fill-gray-700 group-hover:fill-blue-600 cursor-pointer"
                  >
                    {displayName(sprint.name)}
                    <title>คลิกดูรายละเอียด {sprint.name}</title>
                  </text>
                  <text x={x + barW / 2} y={chartH + 38} textAnchor="middle" fontSize="8" fill="#9ca3af">
                    {sprint.name.replace(/\d+$/, '').trim().slice(0, 6)}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>
      </div>

      {/* Tooltip */}
      {tooltip && (
        <div
          className="fixed z-50 bg-gray-800 text-white text-xs rounded-lg px-3 py-2 pointer-events-none whitespace-pre-line shadow-lg"
          style={{ left: tooltip.x, top: tooltip.y, transform: 'translate(-50%, -100%)' }}
        >
          {tooltip.lines?.map((l, i) => (
            <div key={i} className={i === 0 ? 'font-semibold mb-1' : i === tooltip.lines.length - 1 ? 'mt-1 font-bold border-t border-gray-600 pt-1' : 'text-gray-300'}>{l}</div>
          ))}
        </div>
      )}

      {/* Summary table */}
      <div className="overflow-x-auto rounded-xl border border-gray-100">
        <table className="w-full text-sm text-left">
          <thead className="bg-gray-50 text-xs font-semibold text-gray-500 sticky top-0">
            <tr>
              <th className="px-4 py-3">Sprint</th>
              {allTypes.map(t => (
                <th key={t} className="px-4 py-3 text-center" style={{ color: getTypeColor(t) }}>{t}</th>
              ))}
              <th className="px-4 py-3 text-center">รวม</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {[...trendBySprint].reverse().map(({ sprint, total, typeCounts }) => (
              <tr
                key={sprint.id}
                className="hover:bg-slate-50 cursor-pointer group"
                onClick={() => navigate(`/sprint-dashboard/distribution/${sprint.id}`)}
              >
                <td className="px-4 py-3 font-medium text-gray-800 group-hover:text-blue-700 flex items-center gap-1">
                  {sprint.name}
                  <span className="material-icons text-sm text-gray-300 group-hover:text-blue-500">open_in_new</span>
                </td>
                {allTypes.map(t => (
                  <td key={t} className="px-4 py-3 text-center text-gray-600">{typeCounts[t] || '—'}</td>
                ))}
                <td className="px-4 py-3 text-center font-bold text-gray-800">{total}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default WorkDistributionChart;
