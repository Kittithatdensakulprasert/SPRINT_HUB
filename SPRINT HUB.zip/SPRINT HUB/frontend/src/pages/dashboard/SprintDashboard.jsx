/**
 * SprintDashboard.jsx
 * หน้าแดชบอร์ดหลักสำหรับสรุปผล Sprint (Jira Analytics)
 *
 * หน้าที่:
 * 1. โหลด sprint list ทั้งหมด
 * 2. รีเฟรชหน้าเบราว์เซอร์จะ sync distribution ทุก sprint + sprint results active/future จาก Jira
 * 3. ดึง sprint results ทั้งหมดจาก DB
 * 4. สร้าง velocity data สำหรับแต่ละ sprint (target/done/existing/new)
 * 5. ส่ง velocity data ให้ VelocityChart แสดงกราฟ
 * 6. คลิกที่กราฟ/ตาราง → navigate ไป SprintResults ของ sprint นั้น
 * 7. รองรับ window focus event (กลับมาที่หน้านี้จะ reload ข้อมูลใหม่)
 *
 * State สำคัญ:
 * - sprints: รายการ sprint ทั้งหมด
 * - velocityData: ข้อมูลที่แปลงแล้วสำหรับกราฟ
 * - jiraConfigured: สถานะว่า Jira พร้อมใช้หรือไม่
 * - isInitialSync: สถานะกำลัง sync จาก Jira
 *
 * API ที่ใช้:
 * - sprintApi.getAll(), jiraApi.getStatus()
 * - jiraApi.syncActiveFutureSprintResults() — sync sprint results ทุก active/future sprint
 * - sprintResultApi.getAll() — ดึงผลลัพธ์ทั้งหมด
 */

import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import VelocityChart from './VelocityChart';
import WorkDistributionChart from './WorkDistributionChart';
import { sprintApi, sprintResultApi, jiraApi } from '../../services/api';

const SprintDashboard = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [sprints, setSprints] = useState([]);
  const [chartType, setChartType] = useState(location.state?.chartType || 'velocity');
  const [chartDropdownOpen, setChartDropdownOpen] = useState(false);
  const chartDropdownRef = React.useRef(null);
  const [error, setError] = useState(null);
  const [jiraConfigured, setJiraConfigured] = useState(false);
  const [velocityData, setVelocityData] = useState([]);
  const [isInitialSync, setIsInitialSync] = useState(false);
  const [distSprintId, setDistSprintId] = useState(null);
  const [distIsSyncing, setDistIsSyncing] = useState(false);

  React.useEffect(() => {
    const handler = (e) => { if (chartDropdownRef.current && !chartDropdownRef.current.contains(e.target)) setChartDropdownOpen(false); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const chartTypes = [
    { id: 'velocity', label: 'Velocity Chart', desc: 'เปรียบเทียบเป้าหมายเทียบงานเสร็จ' },
    { id: 'distribution', label: 'Work Distribution', desc: 'งานตาม Issue Type และ System' },
  ];
  const activeChart = chartTypes.find(c => c.id === chartType) || chartTypes[0];

  const buildVelocityData = (sprintList, allResults) => {
    const resultsBySprint = allResults.reduce((acc, r) => {
      acc[r.sprintId] = acc[r.sprintId] || [];
      acc[r.sprintId].push(r);
      return acc;
    }, {});
    return sprintList.map((s) => {
      const results = resultsBySprint[s.id] || [];
      // Cards data
      const target = results.reduce((sum, r) => sum + (r.targetPts || 0), 0);
      const done = results.reduce((sum, r) => sum + (r.donePts || 0), 0);
      const existing = results.reduce((sum, r) => sum + Number(r.existingPts || 0), 0);
      const newPts = results.reduce((sum, r) => sum + Number(r.newPts || 0), 0);
      // Story points data
      const targetPoints = results.reduce((sum, r) => sum + (r.targetPoints || 0), 0);
      const donePoints = results.reduce((sum, r) => sum + (r.donePoints || 0), 0);
      const existingPoints = results.reduce((sum, r) => sum + Number(r.existingPoints || 0), 0);
      const newPoints = results.reduce((sum, r) => sum + Number(r.newPoints || 0), 0);
      
      return { 
        id: s.id, 
        name: s.name, 
        target, done, existing, new: newPts,
        targetPoints, donePoints, existingPoints, newPoints
      };
    }).reverse();
  };

  const loadData = React.useCallback(async (forceSync = false, syncSprints = false) => {
    try {
      const jiraStatus = await jiraApi.getStatus().catch(() => ({ configured: false }));
      setJiraConfigured(jiraStatus.configured);

      // Auto-sync: เช็ค DB ว่างก่อน → ถ้าว่าง sync ทุก sprint, ไม่งั้น sync แค่ active/future ครั้งเดียวต่อ session
      const SESSION_KEY = 'sprint_hub_synced';
      const existingResults = jiraStatus.configured && !forceSync
        ? await sprintResultApi.getAll().catch(() => [])
        : [];
      const isDbEmpty = existingResults.length === 0;

      if (jiraStatus.configured && !forceSync && (isDbEmpty || !sessionStorage.getItem(SESSION_KEY))) {
        sessionStorage.setItem(SESSION_KEY, '1');
        setIsInitialSync(true);

        if (isDbEmpty) {
          // DB ว่าง (ครั้งแรก / ลบ DB ใหม่) → sync sprints + ทุก sprint results + distribution
          await jiraApi.syncSprints().catch(() => null);
          await Promise.all([
            jiraApi.syncAllDistribution().catch(() => null),
            jiraApi.syncAllSprintResults().catch(() => null),
          ]);
        } else {
          // DB มีข้อมูลแล้ว → sync แค่ active/future
          await Promise.all([
            jiraApi.syncAllDistribution().catch(() => null),
            jiraApi.syncActiveFutureSprintResults().catch(() => null),
          ]);
        }
        setIsInitialSync(false);
      }

      // ถ้ากดปุ่ม Sync: ดึง sprint list ใหม่จาก Jira ด้วย (เผื่อมี sprint ใหม่)
      if (jiraStatus.configured && syncSprints) {
        await jiraApi.syncSprints().catch(() => null);
      }

      // ถ้ากดปุ่ม Sync: sync distribution ทุก sprint + sprint results เฉพาะ active/future
      if (jiraStatus.configured && forceSync) {
        setIsInitialSync(true);
        await Promise.all([
          jiraApi.syncAllDistribution().catch(() => null),
          jiraApi.syncActiveFutureSprintResults().catch(() => null),
        ]);
        setIsInitialSync(false);
      }

      // ดึงข้อมูลจาก DB เสมอ
      const sprintList = await sprintApi.getAll();
      setSprints(sprintList);
      if (sprintList.length > 0) {
        // set default sprint สำหรับ distribution (active หรืออันล่าสุด)
        setDistSprintId(prev => prev || (sprintList.find(s => s.status === 'active') || sprintList[sprintList.length - 1])?.id);
        const allResults = await sprintResultApi.getAll();
        setVelocityData(buildVelocityData(sprintList, allResults));
      }
    } catch (e) {
      setError('ไม่สามารถโหลดข้อมูลได้ ตรวจสอบการเชื่อมต่อ Backend');
    }
  }, []);

  useEffect(() => {
    loadData();
    const onFocus = () => loadData();
    const onForceSync = async (e) => {
      try {
        await loadData(true, e?.detail?.syncSprints === true);
        window.dispatchEvent(new CustomEvent('jira-sync-done', { detail: { success: true } }));
      } catch {
        window.dispatchEvent(new CustomEvent('jira-sync-done', { detail: { success: false } }));
      }
    };
    const onDistSyncing = () => setIsInitialSync(true);
    const onSyncDone = () => setIsInitialSync(false);
    window.addEventListener('focus', onFocus);
    window.addEventListener('jira-force-sync', onForceSync);
    window.addEventListener('jira-dist-syncing', onDistSyncing);
    window.addEventListener('jira-sync-done', onSyncDone);
    return () => {
      window.removeEventListener('focus', onFocus);
      window.removeEventListener('jira-force-sync', onForceSync);
      window.removeEventListener('jira-dist-syncing', onDistSyncing);
      window.removeEventListener('jira-sync-done', onSyncDone);
    };
  }, [loadData]);

  const handleSprintClick = (sprintId) => {
    navigate(`/sprint-dashboard/${sprintId}`);
  };

  return (
    <div className="p-6 space-y-6">

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 rounded-xl px-4 py-3 text-sm flex items-center gap-2">
          <span className="material-icons text-base">error_outline</span>{error}
        </div>
      )}

      <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm flex justify-between items-start gap-4 flex-wrap">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-gray-900">การประมวลผลและการวิเคราะห์ทีม (Jira Analytics)</h1>
            <span
              title={jiraConfigured ? 'เชื่อมต่อ Jira แล้ว' : 'ไม่ได้เชื่อมต่อ Jira'}
              className={`w-2.5 h-2.5 rounded-full shrink-0 ${jiraConfigured ? 'bg-emerald-500' : 'bg-red-400'}`}
            />
          </div>
          <p className="text-sm text-gray-500 mt-1">ดูภาพรวมและวิเคราะห์ Velocity ทีมจากข้อมูลทุก Sprint</p>
        </div>
      </div>

      <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow space-y-4">
        <div className="flex flex-col sm:flex-row justify-between sm:items-center border-b border-gray-100 pb-4 gap-3">
          <div className="flex items-center gap-2">
            <span className="material-icons text-gray-600">{chartType === 'velocity' ? 'analytics' : 'bar_chart'}</span>
            <span className="font-bold text-gray-900 text-lg">{activeChart.label}</span>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
          <div className="relative" ref={chartDropdownRef}>
            <button
              onClick={() => setChartDropdownOpen(!chartDropdownOpen)}
              className="flex items-center gap-3 bg-white border border-gray-200 hover:border-blue-400 rounded-2xl px-4 py-2.5 shadow-sm transition cursor-pointer"
            >
              <div className="text-left">
                <p className="text-xs text-gray-400 font-medium leading-none mb-1">ประเภทกราฟ</p>
                <p className="text-sm font-bold text-slate-800 leading-none">{activeChart.label}</p>
              </div>
              <span className={`material-icons text-gray-400 text-base transition-transform ${chartDropdownOpen ? 'rotate-180' : ''}`}>expand_more</span>
            </button>
            {chartDropdownOpen && (
              <div className="absolute right-0 top-full mt-2 w-72 bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden z-50">
                {chartTypes.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => { setChartType(c.id); setChartDropdownOpen(false); }}
                    className={`w-full flex items-center justify-between px-4 py-3 text-left hover:bg-blue-50 transition border-0 cursor-pointer ${
                      c.id === chartType ? 'bg-blue-50' : 'bg-white'
                    }`}
                  >
                    <div>
                      <p className={`text-sm font-semibold ${c.id === chartType ? 'text-blue-700' : 'text-gray-800'}`}>{c.label}</p>
                      <p className="text-xs text-gray-400 mt-0.5">{c.desc}</p>
                    </div>
                    {c.id === chartType && <span className="material-icons text-blue-500 text-base">check_circle</span>}
                  </button>
                ))}
              </div>
            )}
          </div>
          </div>
        </div>

        {isInitialSync && (
          <div className="flex items-center gap-2 text-sm text-amber-600 bg-amber-50 px-4 py-2 rounded-lg">
            <span className="material-icons text-sm animate-spin">sync</span>
            กำลัง Sync ข้อมูล Sprint...
          </div>
        )}

        {chartType === 'velocity' && (
          <VelocityChart data={velocityData} onSprintClick={handleSprintClick} />
        )}
        {chartType === 'distribution' && (
          <WorkDistributionChart
            sprints={sprints}
            jiraConfigured={jiraConfigured}
          />
        )}
      </div>
    </div>
  );
};

export default SprintDashboard;
