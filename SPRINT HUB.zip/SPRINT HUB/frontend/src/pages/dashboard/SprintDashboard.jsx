import React, { useState, useEffect, useCallback } from 'react';
import JiraDetailModal from './JiraDetailModal';
import SprintSelector from '../../components/SprintSelector';
import VelocityChart from './VelocityChart';
import { sprintApi, teamMemberApi, sprintResultApi, jiraApi } from '../../services/api';

const SprintDashboard = () => {
  const [sprints, setSprints] = useState([]);
  const [selectedSprint, setSelectedSprint] = useState(null);
  const [teamMembers, setTeamMembers] = useState([]);
  const [sprintResults, setSprintResults] = useState([]);
  const [selectedMember, setSelectedMember] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [chartType, setChartType] = useState('velocity');
  const [chartDropdownOpen, setChartDropdownOpen] = useState(false);
  const chartDropdownRef = React.useRef(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [error, setError] = useState(null);
  const [jiraConfigured, setJiraConfigured] = useState(false);
  const [velocityData, setVelocityData] = useState([]);

  React.useEffect(() => {
    const handler = (e) => { if (chartDropdownRef.current && !chartDropdownRef.current.contains(e.target)) setChartDropdownOpen(false); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const chartTypes = [
    { id: 'velocity', label: 'Velocity Chart', desc: 'เปรียบเทียบเป้าหมายเทียบงานเสร็จ' },
  ];
  const activeChart = chartTypes.find(c => c.id === chartType) || chartTypes[0];

  // โหลด sprints + members + jira status ตอนเปิดหน้า
  useEffect(() => {
    const init = async () => {
      try {
        const [sprintList, members, jiraStatus] = await Promise.all([
          sprintApi.getAll(),
          teamMemberApi.getActive(),
          jiraApi.getStatus().catch(() => ({ configured: false })),
        ]);
        setSprints(sprintList);
        const isEnglish = (name) => /^[A-Za-z]/.test(name);
        setTeamMembers([...members].sort((a, b) => {
          const aEng = isEnglish(a.name);
          const bEng = isEnglish(b.name);
          if (aEng !== bEng) return aEng ? -1 : 1;
          return a.name.localeCompare(b.name, aEng ? 'en' : 'th');
        }));
        setJiraConfigured(jiraStatus.configured);
        if (sprintList.length > 0) {
          const active = sprintList.find(s => s.status === 'active') || sprintList[0];
          setSelectedSprint(active);
        }

        // โหลด velocity data ทุก sprint (ดึงทีเดียว กลุ่มตาม sprintId)
        if (sprintList.length > 0) {
          const allResults = await sprintResultApi.getAll();
          const resultsBySprint = allResults.reduce((acc, r) => {
            acc[r.sprintId] = acc[r.sprintId] || [];
            acc[r.sprintId].push(r);
            return acc;
          }, {});
          const vData = sprintList.map((s) => {
            const results = resultsBySprint[s.id] || [];
            const target = results.reduce((sum, r) => sum + (r.targetPts || 0), 0);
            const done = results.reduce((sum, r) => sum + (r.donePts || 0), 0);
            return { name: s.name, target, done };
          }).reverse();
          setVelocityData(vData);
        }
      } catch (e) {
        setError('ไม่สามารถโหลดข้อมูลได้ ตรวจสอบการเชื่อมต่อ Backend');
      }
    };
    init();
  }, []);

  // Auto-sync + ดึงผล เมื่อ selectedSprint เปลี่ยน
  useEffect(() => {
    if (!selectedSprint) return;
    loadSprintData(selectedSprint);
  }, [selectedSprint]);

  const loadSprintData = useCallback(async (sprint) => {
    setIsLoading(true);
    setError(null);
    try {
      const results = await sprintResultApi.getBySprint(sprint.id);
      setSprintResults(results);

      const isActive = sprint.status === 'active';
      const syncKey = `synced_result_${sprint.id}`;
      const lastSync = sessionStorage.getItem(syncKey);
      const expiredOrMissing = !lastSync || (Date.now() - parseInt(lastSync)) > 30 * 60 * 1000;
      const hasNoData = results.length === 0;

      if (jiraConfigured && isActive && (expiredOrMissing || hasNoData)) {
        setIsSyncing(true);
        await jiraApi.syncSprintResults(sprint.id).catch(() => null);
        const updated = await sprintResultApi.getBySprint(sprint.id);
        setSprintResults(updated);
        sessionStorage.setItem(syncKey, String(Date.now()));
        setIsSyncing(false);
      }
    } catch (e) {
      setError('โหลดข้อมูล Sprint ไม่สำเร็จ');
    } finally {
      setIsLoading(false);
    }
  }, [jiraConfigured]);

  const handleMemberClick = (member) => {
    setSelectedMember(member);
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setSelectedMember(null);
  };

  const sprintOptions = sprints.map(s => ({ id: s.id, name: s.name, dates: `${s.startDate} – ${s.endDate}`, isActive: s.status === 'active' }));

  const calculateKPIs = () => {
    const totalTarget = sprintResults.reduce((sum, r) => sum + (r.targetPts || 0), 0);
    const totalDone = sprintResults.reduce((sum, r) => sum + (r.donePts || 0), 0);
    const totalRemaining = sprintResults.reduce((sum, r) => sum + (r.remainingPts || 0), 0);
    const successPercent = totalTarget > 0 ? ((totalDone / totalTarget) * 100).toFixed(1) : 0;
    return { successPercent, totalDone, totalRemaining, totalTarget };
  };

  const kpis = calculateKPIs();

  return (
    <div className="p-6 space-y-6">

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 rounded-xl px-4 py-3 text-sm flex items-center gap-2">
          <span className="material-icons text-base">error_outline</span>{error}
        </div>
      )}

      <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm flex justify-between items-start gap-4 flex-wrap">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-gray-900">แดชบอร์ดสรุปงานประจำ Sprint</h1>
            <span
              title={jiraConfigured ? 'เชื่อมต่อ Jira แล้ว' : 'ไม่ได้เชื่อมต่อ Jira'}
              className={`w-2.5 h-2.5 rounded-full shrink-0 ${jiraConfigured ? 'bg-emerald-500' : 'bg-red-400'}`}
            />
          </div>
          <p className="text-sm text-gray-500 mt-1">ดูภาพรวม ประเมินประสิทธิภาพและงาน Jira รายบุคคล</p>
        </div>
        <SprintSelector
          value={selectedSprint?.name || ''}
          onChange={(name) => setSelectedSprint(sprints.find(s => s.name === name) || null)}
          sprints={sprintOptions}
        />
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className={`bg-white p-6 rounded-2xl border border-blue-100 shadow flex items-center justify-between ${isLoading ? 'opacity-50 animate-pulse' : ''}`}>
          <div>
            <p className="text-xs font-semibold uppercase text-gray-400 tracking-wider">เปอร์เซ็นต์ความสำเร็จทีม (Velocity)</p>
            <h3 className="text-3xl font-bold text-blue-600 mt-2">{kpis.successPercent}%</h3>
          </div>
        </div>
        <div className={`bg-white p-6 rounded-2xl border border-emerald-100 shadow flex items-center justify-between ${isLoading ? 'opacity-50 animate-pulse' : ''}`}>
          <div>
            <p className="text-xs font-semibold uppercase text-gray-400 tracking-wider">งานที่ทำเสร็จ (Done Tasks)</p>
            <h3 className="text-3xl font-bold text-emerald-600 mt-2">{kpis.totalDone} / {kpis.totalTarget} <span className="text-sm font-normal text-gray-400">Tasks</span></h3>
          </div>
        </div>
        <div className={`bg-white p-6 rounded-2xl border border-amber-100 shadow flex items-center justify-between ${isLoading ? 'opacity-50 animate-pulse' : ''}`}>
          <div>
            <p className="text-xs font-semibold uppercase text-gray-400 tracking-wider">งานเหลือค้างในระบบ (Remaining)</p>
            <h3 className="text-3xl font-bold text-amber-600 mt-2">{kpis.totalRemaining} <span className="text-sm font-normal text-gray-400">Tasks</span></h3>
          </div>
        </div>
      </div>

      {/* Individual Results Table */}
      <div className="bg-white rounded-2xl shadow border border-gray-200 overflow-hidden">
        <div className="p-5 border-b border-gray-200 flex justify-between items-center flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <span className="material-icons text-gray-500">leaderboard</span>
            <span className="font-semibold text-gray-900">สรุปคะแนนประสิทธิภาพการส่งมอบงานรายบุคคล</span>
            <span className="text-xs bg-gray-100 text-gray-500 px-2 py-0.5 rounded-full font-medium">{teamMembers.length} คน</span>
          </div>
          <div className="flex items-center gap-2">
            {isSyncing && <span className="text-xs text-slate-500 flex items-center gap-1"><span className="material-icons text-sm animate-spin">sync</span>กำลัง Sync...</span>}
          </div>
        </div>
        <div className="max-h-[480px] overflow-y-auto">
        <table className="w-full text-left border-collapse">
          <thead className="sticky top-0 z-10">
            <tr className="bg-gray-50 text-gray-500 text-xs font-semibold border-b border-gray-200">
              <th className="py-3 px-6 text-left">สมาชิกทีม</th>
              <th className="py-3 px-4 text-center">งานทั้งหมด</th>
              <th className="py-3 px-4 text-center">ทำเสร็จแล้ว</th>
              <th className="py-3 px-4 text-center">ยังค้างอยู่</th>
              <th className="py-3 px-6 text-left">ความคืบหน้า</th>
              <th className="py-3 px-4 text-right">รายละเอียด</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-50 text-sm">
            {isLoading && (
              <tr><td colSpan={6} className="py-12 text-center">
                <span className="material-icons text-3xl text-gray-200 animate-spin block mb-2">refresh</span>
                <p className="text-gray-400 text-sm">กำลังโหลดข้อมูล...</p>
              </td></tr>
            )}
            {!isLoading && teamMembers.length === 0 && (
              <tr>
                <td colSpan={6} className="py-16 text-center">
                  <span className="material-icons text-4xl text-gray-200 block mb-3">group</span>
                  <p className="text-gray-400 font-medium text-sm">ยังไม่มีข้อมูลสมาชิกทีม</p>
                  <p className="text-gray-300 text-xs mt-1">เพิ่มสมาชิกในหน้า Configuration ก่อน</p>
                </td>
              </tr>
            )}
            {teamMembers.map((member) => {
              const result = sprintResults.find(r => r.memberId === member.id) || { targetPts: 0, donePts: 0, remainingPts: 0 };
              const pct = result.targetPts > 0 ? Math.min(100, Math.round((result.donePts / result.targetPts) * 100)) : 0;
              const isDone = result.remainingPts === 0;
              const initials = member.name.split(' ').map(w => w[0]).slice(0, 2).join('');
              return (
                <tr key={member.id} className="hover:bg-slate-50 transition border-b border-gray-100 last:border-0">
                  <td className="py-3.5 px-6">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-slate-700 text-white flex items-center justify-center text-xs font-bold shrink-0">
                        {initials}
                      </div>
                      <div>
                        <p className="font-semibold text-gray-800 text-sm">{member.name}</p>
                        <p className="text-xs text-gray-400">{member.jiraUsername}</p>
                      </div>
                    </div>
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    <span className="inline-block bg-gray-100 text-gray-600 font-semibold text-sm px-3 py-1 rounded-full">{result.targetPts} <span className="font-normal text-xs">tasks</span></span>
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    <span className="inline-block bg-emerald-50 text-emerald-700 font-semibold text-sm px-3 py-1 rounded-full">{result.donePts} <span className="font-normal text-xs">tasks</span></span>
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    {isDone
                      ? <span className="text-gray-300 font-semibold text-sm">—</span>
                      : <span className="inline-block bg-amber-50 text-amber-700 font-semibold text-sm px-3 py-1 rounded-full">{result.remainingPts} <span className="font-normal text-xs">tasks</span></span>
                    }
                  </td>
                  <td className="py-3.5 px-6 min-w-[200px]">
                    <div className="flex items-center gap-2.5">
                      <div className="flex-1 bg-gray-100 rounded-full h-2 overflow-hidden">
                        <div
                          className={`h-2 rounded-full transition-all duration-500 ${pct >= 100 ? 'bg-emerald-500' : pct >= 60 ? 'bg-amber-400' : 'bg-red-400'}`}
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                      <span className={`text-xs font-bold w-9 text-right shrink-0 ${pct >= 100 ? 'text-emerald-600' : pct >= 60 ? 'text-amber-600' : 'text-red-500'}`}>{pct}%</span>
                    </div>
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <button
                      onClick={() => handleMemberClick(member)}
                      className="text-xs font-semibold text-slate-500 hover:text-amber-700 hover:bg-amber-50 px-3 py-1.5 rounded-lg border border-gray-200 hover:border-amber-300 transition cursor-pointer bg-white"
                    >
                      ดูรายละเอียด
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        </div>
      </div>

      {/* Analytics Charts */}
      <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow space-y-4">
        <div className="flex flex-col sm:flex-row justify-between sm:items-center border-b border-gray-100 pb-4 gap-2">
          <div className="flex items-center gap-2">
            <span className="material-icons text-gray-600">analytics</span>
            <span className="font-bold text-gray-900 text-lg">การประมวลผลและการวิเคราะห์ทีม (Jira Analytics)</span>
          </div>
          <div className="relative" ref={chartDropdownRef}>
            <button
              onClick={() => setChartDropdownOpen(!chartDropdownOpen)}
              className="flex items-center gap-3 bg-white border border-gray-200 hover:border-yellow-400 rounded-2xl px-4 py-2.5 shadow-sm transition cursor-pointer"
            >
              <div className="text-left">
                <p className="text-xs text-gray-400 font-medium leading-none mb-1">ประเภทกราฟ</p>
                <p className="text-sm font-bold text-slate-800 leading-none">{activeChart.label}</p>
              </div>
              <span className={`material-icons text-gray-400 text-base transition-transform ${chartDropdownOpen ? 'rotate-180' : ''}`}>expand_more</span>
            </button>
            {chartDropdownOpen && (
              <div className="absolute right-0 top-full mt-2 w-72 bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden z-50">
                {chartTypes.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => { setChartType(c.id); setChartDropdownOpen(false); }}
                    className={`w-full flex items-center justify-between px-4 py-3 text-left hover:bg-amber-50 transition border-0 cursor-pointer ${
                      c.id === chartType ? 'bg-amber-50' : 'bg-white'
                    }`}
                  >
                    <div>
                      <p className={`text-sm font-semibold ${c.id === chartType ? 'text-amber-700' : 'text-gray-800'}`}>{c.label}</p>
                      <p className="text-xs text-gray-400 mt-0.5">{c.desc}</p>
                    </div>
                    {c.id === chartType && <span className="material-icons text-amber-500 text-base">check_circle</span>}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
        
        <VelocityChart data={velocityData} />
      </div>

      {/* Drill-down Modal */}
      {showModal && selectedMember && (
        <JiraDetailModal
          member={selectedMember}
          sprintId={selectedSprint?.id}
          onClose={handleCloseModal}
        />
      )}
    </div>
  );
};

export default SprintDashboard;
