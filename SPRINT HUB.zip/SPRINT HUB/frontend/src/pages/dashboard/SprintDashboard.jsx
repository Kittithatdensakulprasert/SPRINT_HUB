import React, { useState, useEffect } from 'react';
import JiraDetailModal from './JiraDetailModal';
import SprintSelector from '../../components/SprintSelector';

const SprintDashboard = () => {
  const [teamMembers, setTeamMembers] = useState([]);
  const [sprintResults, setSprintResults] = useState([]);
  const [selectedMember, setSelectedMember] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [chartType, setChartType] = useState('velocity');
  const [chartDropdownOpen, setChartDropdownOpen] = useState(false);
  const chartDropdownRef = React.useRef(null);
  const [analyticsData, setAnalyticsData] = useState(null);

  React.useEffect(() => {
    const handler = (e) => { if (chartDropdownRef.current && !chartDropdownRef.current.contains(e.target)) setChartDropdownOpen(false); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const chartTypes = [
    { id: 'velocity',   label: 'Velocity Chart',            desc: 'เปรียบเทียบเป้าหมายเทียบงานเสร็จ' },
    { id: 'burndown',   label: 'Sprint Burndown',            desc: 'ติดตามงานที่เหลือรายวัน' },
    { id: 'throughput', label: 'Throughput Report',          desc: 'จำนวนงานที่เสร็จต่อ Sprint' },
    { id: 'cfd',        label: 'Cumulative Flow Diagram',    desc: 'ตรวจเช็คคอขวดขั้นตอนงาน' },
    { id: 'workdist',   label: 'Work Distribution',          desc: 'สัดส่วนงานแต่ละประเภทใน Squad' },
    { id: 'control',    label: 'Control Chart',              desc: 'วัด Cycle Time รายงาน' },
    { id: 'epic',       label: 'Epic Burndown',              desc: 'ความคืบหน้าภาพรวมโครงการใหญ่' },
  ];
  const activeChart = chartTypes.find(c => c.id === chartType) || chartTypes[0];
  const [selectedSprint, setSelectedSprint] = useState('Krungsri Sprint #24');

  const sprints = [
    { name: 'Krungsri Sprint #24', dates: '2 – 15 มิ.ย. 2568', isActive: true },
    { name: 'Krungsri Sprint #23', dates: '19 พ.ค. – 1 มิ.ย. 2568', isActive: false },
    { name: 'Krungsri Sprint #22', dates: '5 – 18 พ.ค. 2568', isActive: false },
  ];

  useEffect(() => {
    // TODO: fetch from API
    // setIsLoading(true);
    // fetch(`/api/jira/analytics?sprint=${selectedSprint}&type=${chartType}`)
    //   .then(r => r.ok ? r.json() : Promise.reject())
    //   .then(data => { setAnalyticsData(data); setIsLoading(false); })
    //   .catch(() => { setIsLoading(false); });
  }, []);

  const handleMemberClick = (member) => {
    setSelectedMember(member);
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setSelectedMember(null);
  };

  const handleExportToExcel = () => {
    console.log('Exporting to Excel...');
  };

  const calculateKPIs = () => {
    const totalTarget = sprintResults.reduce((sum, r) => sum + r.targetPts, 0);
    const totalDone = sprintResults.reduce((sum, r) => sum + r.donePts, 0);
    const totalRemaining = sprintResults.reduce((sum, r) => sum + r.remainingPts, 0);
    const successPercent = totalTarget > 0 ? ((totalDone / totalTarget) * 100).toFixed(1) : 0;

    return { successPercent, totalDone, totalRemaining };
  };

  const kpis = calculateKPIs();

  return (
    <div className="p-6 space-y-6">
      <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm flex justify-between items-start gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">แดชบอร์ดสรุปงานประจำ Sprint</h1>
          <p className="text-sm text-gray-500 mt-1">ดูภาพรวม ประเมินประสิทธิภาพและงาน Jira รายบุคคล</p>
        </div>
        <SprintSelector value={selectedSprint} onChange={setSelectedSprint} sprints={sprints} />
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-blue-100 shadow flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold uppercase text-gray-400 tracking-wider">เปอร์เซ็นต์ความสำเร็จทีม (Velocity)</p>
            <h3 className="text-3xl font-bold text-blue-600 mt-2">{kpis.successPercent}%</h3>
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-emerald-100 shadow flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold uppercase text-gray-400 tracking-wider">รวมแต้มทำเสร็จ (Done Points)</p>
            <h3 className="text-3xl font-bold text-emerald-600 mt-2">{kpis.totalDone} / {kpis.totalDone + kpis.totalRemaining} <span className="text-sm font-normal text-gray-400">Points</span></h3>
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-amber-100 shadow flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold uppercase text-gray-400 tracking-wider">งานเหลือค้างในระบบ (Remaining)</p>
            <h3 className="text-3xl font-bold text-amber-600 mt-2">{kpis.totalRemaining} <span className="text-sm font-normal text-gray-400">Points</span></h3>
          </div>
        </div>
      </div>

      {/* Individual Results Table */}
      <div className="bg-white rounded-2xl shadow border border-gray-200 overflow-hidden">
        <div className="p-5 border-b border-gray-200 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <span className="material-icons text-gray-500">leaderboard</span>
            <span className="font-semibold text-gray-900">สรุปคะแนนประสิทธิภาพการส่งมอบงานรายบุคคล</span>
            <span className="text-xs bg-gray-100 text-gray-500 px-2 py-0.5 rounded-full font-medium">{teamMembers.length} คน</span>
          </div>
        </div>
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-gray-50 text-gray-400 text-xs font-semibold border-b border-gray-100 uppercase tracking-wider">
              <th className="py-3 px-6">สมาชิกทีม</th>
              <th className="py-3 px-4 text-center">เป้าหมาย</th>
              <th className="py-3 px-4 text-center">เสร็จแล้ว</th>
              <th className="py-3 px-4 text-center">ค้างอยู่</th>
              <th className="py-3 px-6">ความคืบหน้า</th>
              <th className="py-3 px-4 text-right">รายละเอียด</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-50 text-sm">
            {teamMembers.length === 0 && (
              <tr>
                <td colSpan={6} className="py-16 text-center">
                  <span className="material-icons text-4xl text-gray-200 block mb-3">group</span>
                  <p className="text-gray-400 font-medium text-sm">ยังไม่มีข้อมูลสมาชิกทีม</p>
                  <p className="text-gray-300 text-xs mt-1">เชื่อมต่อ API หรือเพิ่มสมาชิกในหน้าตั้งค่า</p>
                </td>
              </tr>
            )}
            {teamMembers.map((member) => {
              const result = sprintResults.find(r => r.memberId === member.id) || { targetPts: 0, donePts: 0, remainingPts: 0 };
              const pct = result.targetPts > 0 ? Math.min(100, Math.round((result.donePts / result.targetPts) * 100)) : 0;
              const isDone = result.remainingPts === 0;
              const initials = member.name.split(' ').map(w => w[0]).slice(0, 2).join('');
              return (
                <tr key={member.id} className="hover:bg-amber-50/20 transition">
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-slate-700 text-white flex items-center justify-center text-xs font-bold shrink-0">
                        {initials}
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900 text-sm">{member.name}</p>
                        <p className="text-xs text-gray-400">{member.jiraUsername}</p>
                      </div>
                    </div>
                  </td>
                  <td className="py-4 px-4 text-center">
                    <span className="font-semibold text-gray-700">{result.targetPts}</span>
                    <span className="text-xs text-gray-400 ml-0.5">pts</span>
                  </td>
                  <td className="py-4 px-4 text-center">
                    <span className="font-bold text-emerald-600">{result.donePts}</span>
                    <span className="text-xs text-gray-400 ml-0.5">pts</span>
                  </td>
                  <td className="py-4 px-4 text-center">
                    <span className={`font-bold ${isDone ? 'text-gray-300' : 'text-red-500'}`}>
                      {isDone ? '—' : `${result.remainingPts} pts`}
                    </span>
                  </td>
                  <td className="py-4 px-6 min-w-[180px]">
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-gray-100 rounded-full h-2 overflow-hidden">
                        <div
                          className={`h-2 rounded-full transition-all ${pct >= 100 ? 'bg-emerald-500' : pct >= 60 ? 'bg-yellow-400' : 'bg-red-400'}`}
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                      <span className="text-xs font-bold text-gray-500 w-8 text-right shrink-0">{pct}%</span>
                      {isDone && (
                        <span className="material-icons text-emerald-500 text-base shrink-0">check_circle</span>
                      )}
                    </div>
                  </td>
                  <td className="py-4 px-4 text-right">
                    <button
                      onClick={() => handleMemberClick(member)}
                      className="inline-flex items-center gap-1 text-xs font-semibold text-slate-600 hover:text-amber-700 hover:bg-amber-50 px-3 py-1.5 rounded-lg border border-gray-200 hover:border-amber-300 transition cursor-pointer bg-white"
                    >
                      <span className="material-icons text-sm">open_in_new</span>
                      รายละเอียดงาน
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Analytics Charts */}
      <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow space-y-4">
        <div className="flex flex-col sm:flex-row justify-between sm:items-center border-b border-gray-100 pb-4 gap-2">
          <div className="flex items-center gap-2">
            <span className="material-icons text-gray-600">analytics</span>
            <span className="font-bold text-gray-900 text-lg">การประมวลผลและการวิเคราะห์ทีม (Jira Analytics)</span>
          </div>
          <div className="relative" ref={chartDropdownRef}>
            <button
              onClick={() => setChartDropdownOpen(!chartDropdownOpen)}
              className="flex items-center gap-3 bg-white border border-gray-200 hover:border-yellow-400 rounded-2xl px-4 py-2.5 shadow-sm transition cursor-pointer"
            >
              <div className="text-left">
                <p className="text-xs text-gray-400 font-medium leading-none mb-1">ประเภทกราฟ</p>
                <p className="text-sm font-bold text-slate-800 leading-none">{activeChart.label}</p>
              </div>
              <span className={`material-icons text-gray-400 text-base transition-transform ${chartDropdownOpen ? 'rotate-180' : ''}`}>expand_more</span>
            </button>
            {chartDropdownOpen && (
              <div className="absolute right-0 top-full mt-2 w-72 bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden z-50">
                {chartTypes.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => { setChartType(c.id); setChartDropdownOpen(false); }}
                    className={`w-full flex items-center justify-between px-4 py-3 text-left hover:bg-amber-50 transition border-0 cursor-pointer ${
                      c.id === chartType ? 'bg-amber-50' : 'bg-white'
                    }`}
                  >
                    <div>
                      <p className={`text-sm font-semibold ${c.id === chartType ? 'text-amber-700' : 'text-gray-800'}`}>{c.label}</p>
                      <p className="text-xs text-gray-400 mt-0.5">{c.desc}</p>
                    </div>
                    {c.id === chartType && <span className="material-icons text-amber-500 text-base">check_circle</span>}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
        
        <div className="h-64 bg-slate-50 border-2 border-dashed border-gray-200 rounded-xl flex items-center justify-center p-4">
          <div className="flex flex-col items-center gap-2 text-center">
            <span className="material-icons text-4xl text-gray-200">insert_chart</span>
            <p className="text-sm font-medium text-gray-400">{activeChart.label}</p>
            <p className="text-xs text-gray-300">เชื่อมต่อ Jira API เพื่อแสดงข้อมูลจริง</p>
          </div>
        </div>

        {/* Data Table below chart */}
        <div className="border-t border-gray-100 pt-4">
          <div className="flex flex-col items-center gap-2 py-6 text-center">
            <span className="material-icons text-3xl text-gray-200">table_chart</span>
            <p className="text-sm text-gray-400">ยังไม่มีข้อมูล {activeChart.label}</p>
            <p className="text-xs text-gray-300">เชื่อมต่อ Jira API เพื่อแสดงตารางข้อมูลจริง</p>
          </div>
        </div>
      </div>

      {/* Drill-down Modal */}
      {showModal && selectedMember && (
        <JiraDetailModal 
          member={selectedMember}
          onClose={handleCloseModal}
        />
      )}
    </div>
  );
};

export default SprintDashboard;
