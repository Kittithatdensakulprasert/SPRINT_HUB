import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import JiraDetailModal from './JiraDetailModal';
import MemberVelocityModal from './MemberVelocityModal';
import SprintSelector from '../../components/SprintSelector';
import { sprintApi, teamMemberApi, sprintResultApi, jiraApi } from '../../services/api';

const getSprintNumber = (sprintName) => {
  if (!sprintName) return null;
  const match = sprintName.match(/Sprint\s+(\d+)/i);
  return match ? match[1] : null;
};

const SprintResults = () => {
  const { sprintId } = useParams();
  const navigate = useNavigate();
  const [sprints, setSprints] = useState([]);
  const [selectedSprint, setSelectedSprint] = useState(null);
  const [teamMembers, setTeamMembers] = useState([]);
  const [sprintResults, setSprintResults] = useState([]);
  const [selectedMember, setSelectedMember] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [jiraSprintId, setJiraSprintId] = useState(null);
  const [showVelocityModal, setShowVelocityModal] = useState(false);
  const [velocityMember, setVelocityMember] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [error, setError] = useState(null);
  const [jiraConfigured, setJiraConfigured] = useState(false);

  const isEnglishName = (name) => /^[A-Za-z]/.test(name);

  useEffect(() => {
    const init = async () => {
      try {
        const [sprintList, members, jiraStatus] = await Promise.all([
          sprintApi.getAll(),
          teamMemberApi.getActive(),
          jiraApi.getStatus().catch(() => ({ configured: false })),
        ]);
        setSprints(sprintList);
        setTeamMembers([...members].sort((a, b) => {
          const aEng = isEnglishName(a.name);
          const bEng = isEnglishName(b.name);
          if (aEng !== bEng) return aEng ? -1 : 1;
          return a.name.localeCompare(b.name, aEng ? 'en' : 'th');
        }));
        setJiraConfigured(jiraStatus.configured);

        const selected = sprintList.find(s => String(s.id) === sprintId) || sprintList[0];
        if (selected) setSelectedSprint(selected);
      } catch (e) {
        setError('ไม่สามารถโหลดข้อมูลได้ ตรวจสอบการเชื่อมต่อ Backend');
      }
    };
    init();
  }, [sprintId]);

  useEffect(() => {
    if (!selectedSprint) return;
    loadSprintData(selectedSprint);
  }, [selectedSprint]);

  const loadSprintData = useCallback(async (sprint) => {
    setIsLoading(true);
    setError(null);
    try {
      const results = await sprintResultApi.getBySprint(sprint.id);
      setSprintResults(results);

      const isActive = sprint.status === 'active';
      const syncKey = `synced_result_${sprint.id}`;
      const lastSync = sessionStorage.getItem(syncKey);
      const expiredOrMissing = !lastSync || (Date.now() - parseInt(lastSync)) > 30 * 60 * 1000;
      const hasNoData = results.length === 0;

      if (jiraConfigured && isActive && (expiredOrMissing || hasNoData)) {
        setIsSyncing(true);
        await jiraApi.syncSprintResults(sprint.id).catch(() => null);
        const updated = await sprintResultApi.getBySprint(sprint.id);
        setSprintResults(updated);
        sessionStorage.setItem(syncKey, String(Date.now()));
        setIsSyncing(false);
      }
    } catch (e) {
      setError('โหลดข้อมูล Sprint ไม่สำเร็จ');
    } finally {
      setIsLoading(false);
    }
  }, [jiraConfigured]);

  const handleMemberClick = (member, overrideSprintId) => {
    setSelectedMember(member);
    setJiraSprintId(overrideSprintId ?? selectedSprint?.id ?? null);
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setSelectedMember(null);
    setJiraSprintId(null);
  };

  const handleOpenVelocity = (member) => {
    setVelocityMember(member);
    setShowVelocityModal(true);
  };

  const handleCloseVelocity = () => {
    setShowVelocityModal(false);
    setVelocityMember(null);
  };

  const handleSprintChange = (name) => {
    const s = sprints.find(sp => sp.name === name);
    if (s) navigate(`/sprint-dashboard/${s.id}`);
  };

  const sprintOptions = sprints.map(s => ({ id: s.id, name: s.name, dates: `${s.startDate} – ${s.endDate}`, isActive: s.status === 'active' }));

  const calculateKPIs = () => {
    const totalTarget = sprintResults.reduce((sum, r) => sum + (r.targetPts || 0), 0);
    const totalDone = sprintResults.reduce((sum, r) => sum + (r.donePts || 0), 0);
    const totalRemaining = sprintResults.reduce((sum, r) => sum + (r.remainingPts || 0), 0);
    const successPercent = totalTarget > 0 ? ((totalDone / totalTarget) * 100).toFixed(1) : 0;
    return { successPercent, totalDone, totalRemaining, totalTarget };
  };

  const kpis = calculateKPIs();

  return (
    <div className="p-6 space-y-6">
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 rounded-xl px-4 py-3 text-sm flex items-center gap-2">
          <span className="material-icons text-base">error_outline</span>{error}
        </div>
      )}

      <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm flex justify-between items-end gap-4 flex-wrap">
        <div>
          <Link
            to="/sprint-dashboard"
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-700 bg-white border border-gray-200 hover:border-amber-400 hover:text-amber-700 hover:bg-amber-50 px-3 py-1.5 rounded-lg mb-2 transition shadow-sm"
          >
            <span className="material-icons text-sm">arrow_back</span>
            กลับไป Jira Analytics
          </Link>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-gray-900">แดชบอร์ดสรุปงานประจำ Sprint</h1>
            {getSprintNumber(selectedSprint?.name) && (
              <span className="text-lg font-bold text-emerald-600 bg-emerald-50 px-2.5 py-0.5 rounded-lg border border-emerald-100">
                #{getSprintNumber(selectedSprint?.name)}
              </span>
            )}
            <span
              title={jiraConfigured ? 'เชื่อมต่อ Jira แล้ว' : 'ไม่ได้เชื่อมต่อ Jira'}
              className={`w-2.5 h-2.5 rounded-full shrink-0 ${jiraConfigured ? 'bg-emerald-500' : 'bg-red-400'}`}
            />
          </div>
          <div className="flex items-center gap-2 mt-1 flex-wrap">
            <p className="text-sm text-gray-500">ดูภาพรวมและงาน Jira รายบุคคล</p>
            {selectedSprint?.startDate && selectedSprint?.endDate && (
              <span className="inline-flex items-center gap-1.5 text-xs font-medium text-gray-500 bg-gray-100 px-2.5 py-1 rounded-full">
                <span className="material-icons text-xs text-gray-400">calendar_today</span>
                {new Date(selectedSprint.startDate).toLocaleDateString('th-TH', { day: 'numeric', month: 'short', year: 'numeric' })}
                {' – '}
                {new Date(selectedSprint.endDate).toLocaleDateString('th-TH', { day: 'numeric', month: 'short', year: 'numeric' })}
              </span>
            )}
          </div>
        </div>
        <SprintSelector
          value={selectedSprint?.name || ''}
          onChange={handleSprintChange}
          sprints={sprintOptions}
        />
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className={`bg-white p-6 rounded-2xl border border-blue-100 shadow flex items-center justify-between ${isLoading ? 'opacity-50 animate-pulse' : ''}`}>
          <div>
            <p className="text-xs font-semibold uppercase text-gray-400 tracking-wider">เปอร์เซ็นต์ความสำเร็จทีม (Velocity)</p>
            <h3 className="text-3xl font-bold text-blue-600 mt-2">{kpis.successPercent}%</h3>
          </div>
        </div>
        <div className={`bg-white p-6 rounded-2xl border border-emerald-100 shadow flex items-center justify-between ${isLoading ? 'opacity-50 animate-pulse' : ''}`}>
          <div>
            <p className="text-xs font-semibold uppercase text-gray-400 tracking-wider">งานที่ทำเสร็จ (Done Cards)</p>
            <h3 className="text-3xl font-bold text-emerald-600 mt-2">{kpis.totalDone} / {kpis.totalTarget} <span className="text-sm font-normal text-gray-400">Cards</span></h3>
          </div>
        </div>
        <div className={`bg-white p-6 rounded-2xl border border-amber-100 shadow flex items-center justify-between ${isLoading ? 'opacity-50 animate-pulse' : ''}`}>
          <div>
            <p className="text-xs font-semibold uppercase text-gray-400 tracking-wider">งานเหลือค้าง (Remaining)</p>
            <h3 className="text-3xl font-bold text-amber-600 mt-2">{kpis.totalRemaining} <span className="text-sm font-normal text-gray-400">Cards</span></h3>
          </div>
        </div>
      </div>

      {/* Individual Results Table */}
      <div className="bg-white rounded-2xl shadow border border-gray-200 overflow-hidden">
        <div className="p-5 border-b border-gray-200 flex justify-between items-center flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <span className="material-icons text-gray-500">leaderboard</span>
            <span className="font-semibold text-gray-900">สรุปคะแนนประสิทธิภาพ Cards รายบุคคล</span>
            <span className="text-xs bg-gray-100 text-gray-500 px-2 py-0.5 rounded-full font-medium">{teamMembers.length} คน</span>
          </div>
          <div className="flex items-center gap-2">
            {isSyncing && <span className="text-xs text-slate-500 flex items-center gap-1"><span className="material-icons text-sm animate-spin">sync</span>กำลัง Sync...</span>}
          </div>
        </div>
        <div>
          <table className="w-full text-left border-collapse">
            <thead className="sticky top-0 z-10">
              <tr className="bg-gray-50 text-gray-500 text-xs font-semibold border-b border-gray-200">
                <th className="py-3 px-6 text-left">สมาชิกทีม</th>
                <th className="py-3 px-4 text-center">Cards ทั้งหมด</th>
                <th className="py-3 px-4 text-center">Done Cards</th>
                <th className="py-3 px-4 text-center">Remaining Cards</th>
                <th className="py-3 px-6 text-left">ความคืบหน้า</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50 text-sm">
              {isLoading && (
                <tr><td colSpan={5} className="py-12 text-center">
                  <span className="material-icons text-3xl text-gray-200 animate-spin block mb-2">refresh</span>
                  <p className="text-gray-400 text-sm">กำลังโหลดข้อมูล...</p>
                </td></tr>
              )}
              {!isLoading && teamMembers.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-16 text-center">
                    <span className="material-icons text-4xl text-gray-200 block mb-3">group</span>
                    <p className="text-gray-400 font-medium text-sm">ยังไม่มีข้อมูลสมาชิกทีม</p>
                    <p className="text-gray-300 text-xs mt-1">เพิ่มสมาชิกในหน้า Configuration ก่อน</p>
                  </td>
                </tr>
              )}
              {teamMembers.map((member) => {
                const result = sprintResults.find(r => r.memberId === member.id) || { targetPts: 0, donePts: 0, remainingPts: 0 };
                const pct = result.targetPts > 0 ? Math.min(100, Math.round((result.donePts / result.targetPts) * 100)) : 0;
                const isDone = result.remainingPts === 0;
                const initials = member.name.split(' ').map(w => w[0]).slice(0, 2).join('');
                return (
                  <tr key={member.id} className="hover:bg-slate-50 transition border-b border-gray-100 last:border-0 cursor-pointer group" onClick={() => handleOpenVelocity(member)}>
                    <td className="py-3.5 px-6">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-slate-700 group-hover:bg-amber-600 text-white flex items-center justify-center text-xs font-bold shrink-0 transition">
                          {initials}
                        </div>
                        <div>
                          <p className="font-semibold text-gray-800 group-hover:text-amber-700 text-sm transition flex items-center gap-1">
                            {member.name}
                            <span className="material-icons text-sm text-gray-300 group-hover:text-amber-500 transition">bar_chart</span>
                          </p>
                          <p className="text-xs text-gray-400">{member.jiraUsername}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <span className="inline-block bg-gray-100 text-gray-600 font-semibold text-sm px-3 py-1 rounded-full">{result.targetPts} <span className="font-normal text-xs">cards</span></span>
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <span className="inline-block bg-emerald-50 text-emerald-700 font-semibold text-sm px-3 py-1 rounded-full">{result.donePts} <span className="font-normal text-xs">cards</span></span>
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      {isDone
                        ? <span className="text-gray-300 font-semibold text-sm">—</span>
                        : <span className="inline-block bg-amber-50 text-amber-700 font-semibold text-sm px-3 py-1 rounded-full">{result.remainingPts} <span className="font-normal text-xs">cards</span></span>
                      }
                    </td>
                    <td className="py-3.5 px-6 min-w-[200px]">
                      <div className="flex items-center gap-2.5">
                        <div className="flex-1 bg-gray-100 rounded-full h-2 overflow-hidden">
                          <div
                            className="h-2 rounded-full transition-all duration-500 bg-emerald-500"
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                        <span className="text-xs font-bold w-9 text-right shrink-0 text-emerald-600">{pct}%</span>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Jira Detail Modal */}
      {showModal && selectedMember && (
        <JiraDetailModal
          member={selectedMember}
          sprintId={jiraSprintId ?? selectedSprint?.id}
          onClose={handleCloseModal}
          onBack={jiraSprintId ? () => {
            handleCloseModal();
            handleOpenVelocity(selectedMember);
          } : undefined}
        />
      )}

      {/* Member Velocity Modal */}
      {showVelocityModal && velocityMember && (
        <MemberVelocityModal
          member={velocityMember}
          onClose={handleCloseVelocity}
          onOpenJira={(sprintId) => {
            handleCloseVelocity();
            handleMemberClick(velocityMember, sprintId);
          }}
        />
      )}
    </div>
  );
};

export default SprintResults;
