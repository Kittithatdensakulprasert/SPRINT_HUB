/**
 * MemberDistribution.jsx
 * หน้ารายละเอียด Work Distribution ตามคนใน sprint หนึ่ง
 * แสดง member × issue type พร้อม drill-down ระบบที่ทำและงาน
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { jiraApi, sprintApi, emailApi } from '../../services/api';
import SendEmailModal from './SendEmailModal';

const TYPE_COLORS = {
  Functional: '#10b981',
  Defect:     '#ef4444',
  Default:    '#8b5cf6',
};
const SYSTEM_COLORS = [
  '#f59e0b','#06b6d4','#ec4899','#84cc16','#6366f1','#14b8a6','#f97316','#a855f7','#64748b','#ef4444','#3b82f6',
];
const normalizeType = (type) => {
  if (type === 'Task' || type === 'Story') return 'Functional';
  if (type === 'Bug') return 'Defect';
  return type;
};
const getTypeColor = (type) => TYPE_COLORS[normalizeType(type)] || TYPE_COLORS.Default;
const getSystemColor = (name) => {
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
  const idx = Math.abs(hash) % SYSTEM_COLORS.length;
  return SYSTEM_COLORS[idx];
};

const MemberDistribution = ({ embedded = false }) => {
  const { sprintId } = useParams();
  const navigate = useNavigate();

  const [sprint, setSprint] = useState(null);
  const [memberDistribution, setMemberDistribution] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const [error, setError] = useState(null);
  const [jiraConfigured, setJiraConfigured] = useState(false);
  const [modal, setModal] = useState(null); // { member, issues[], isLoading }
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [isSendingEmail, setIsSendingEmail] = useState(false);
  const [emailResult, setEmailResult] = useState(null);
  const contentRef = useRef(null);

  const loadData = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const [sprintData, jiraStatus] = await Promise.all([
        sprintApi.getById(Number(sprintId)),
        jiraApi.getStatus().catch(() => ({ configured: false })),
      ]);
      setSprint(sprintData);
      setJiraConfigured(jiraStatus.configured);

      let data = await jiraApi.getMemberDistribution(Number(sprintId));
      // ถ้า DB ว่าง + Jira พร้อม → auto sync ครั้งแรก
      if (data.length === 0 && jiraStatus.configured) {
        setIsSyncing(true);
        await jiraApi.syncDistribution(Number(sprintId)).catch(() => null);
        setIsSyncing(false);
        data = await jiraApi.getMemberDistribution(Number(sprintId));
      }
      setMemberDistribution(data);
    } catch (e) {
      setError('ไม่สามารถโหลดข้อมูลได้');
    } finally {
      setIsSyncing(false);
      setIsLoading(false);
    }
  }, [sprintId]);

  const handleSendEmail = ({ recipients, subject, bodyText, pdfDataUrl }) => {
    setShowEmailModal(false);
    setIsSendingEmail(true);
    setEmailResult({ success: null, message: 'กำลังส่งอีเมล...' });
    emailApi.sendReport({ recipients, subject, bodyText, sprintName: sprint?.name, pdfBase64: pdfDataUrl })
      .then(() => {
        setEmailResult({ success: true, message: `ส่งอีเมลสำเร็จ ถึง ${recipients.length} คน` });
      })
      .catch(e => {
        setEmailResult({ success: false, message: 'ส่งอีเมลไม่สำเร็จ: ' + (e.message || 'ตรวจสอบการตั้งค่า SMTP') });
      })
      .finally(() => {
        setIsSendingEmail(false);
        setTimeout(() => setEmailResult(null), 6000);
      });
  };

  // Filters
  const [searchName, setSearchName] = useState('');
  const [systemFilter, setSystemFilter] = useState([]);
  const [typeFilter, setTypeFilter] = useState(''); // '' | 'Functional' | 'Defect'
  const [isSystemOpen, setIsSystemOpen] = useState(false);
  const systemDropdownRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (systemDropdownRef.current && !systemDropdownRef.current.contains(e.target)) {
        setIsSystemOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    loadData();
  }, [sprintId]);

  // ฟัง jira-sync-done จาก Sidebar
  useEffect(() => {
    const handleSyncDone = async (e) => {
      if (e?.detail?.success === false || !sprintId) return;
      setIsSyncing(true);
      try {
        await loadData();
      } finally {
        setIsSyncing(false);
      }
    };
    window.addEventListener('jira-sync-done', handleSyncDone);
    return () => window.removeEventListener('jira-sync-done', handleSyncDone);
  }, [sprintId, loadData]);

  const openMemberModal = async (member) => {
    setModal({ member, issues: [], isLoading: true, error: null });
    try {
      const res = await jiraApi.getMemberIssues(Number(sprintId), member.accountId);
      setModal({ member, issues: res.issues || [], isLoading: false, error: null });
    } catch {
      setModal({ member, issues: [], isLoading: false, error: 'โหลดข้อมูลไม่สำเร็จ' });
    }
  };

  // --- aggregate per member with breakdown ---
  const membersMap = memberDistribution.reduce((acc, d) => {
    const id = d.memberAccountId;
    if (!acc[id]) {
      acc[id] = {
        accountId: id,
        name: d.memberName,
        functional: 0,
        defect: 0,
        systems: new Set(),
        total: 0,
        bySystem: {}, // { system: { Functional, Defect, total } }
      };
    }
    const sys = d.systemName || 'OTHER';
    const t = normalizeType(d.issueType);
    if (!acc[id].bySystem[sys]) acc[id].bySystem[sys] = { Functional: 0, Defect: 0, total: 0 };
    if (t === 'Functional') {
      acc[id].functional += d.totalCount;
      acc[id].bySystem[sys].Functional += d.totalCount;
    } else if (t === 'Defect') {
      acc[id].defect += d.totalCount;
      acc[id].bySystem[sys].Defect += d.totalCount;
    } else {
      acc[id].functional += d.totalCount; // fallback
      acc[id].bySystem[sys].Functional += d.totalCount;
    }
    acc[id].systems.add(sys);
    acc[id].total += d.totalCount;
    acc[id].bySystem[sys].total += d.totalCount;
    return acc;
  }, {});

  const allSystems = [...new Set(memberDistribution.map(d => d.systemName || 'OTHER'))].sort();

  // apply filters
  const filteredMembers = Object.values(membersMap)
    .map(m => {
      const effectiveSystems = systemFilter.length > 0
        ? [...m.systems].filter(s => systemFilter.includes(s))
        : [...m.systems];
      let functional = 0;
      let defect = 0;
      let total = 0;
      effectiveSystems.forEach(sys => {
        const bs = m.bySystem[sys] || { Functional: 0, Defect: 0, total: 0 };
        functional += typeFilter === 'Defect' ? 0 : (typeFilter === 'Functional' ? bs.Functional : bs.Functional);
        defect += typeFilter === 'Functional' ? 0 : (typeFilter === 'Defect' ? bs.Defect : bs.Defect);
        total += typeFilter === 'Functional' ? bs.Functional : (typeFilter === 'Defect' ? bs.Defect : bs.total);
      });
      return { ...m, functional, defect, total, displaySystems: effectiveSystems };
    })
    .filter(m => {
      if (searchName && !m.name.toLowerCase().includes(searchName.toLowerCase())) return false;
      if (systemFilter.length > 0 && ![...m.systems].some(s => systemFilter.includes(s))) return false;
      if (typeFilter && m[typeFilter.toLowerCase()] === 0) return false;
      return true;
    })
    .sort((a, b) => {
      const isEnglishName = (name) => /^[A-Za-z]/.test(name);
      const aEng = isEnglishName(a.name);
      const bEng = isEnglishName(b.name);
      if (aEng !== bEng) return aEng ? -1 : 1;
      return a.name.localeCompare(b.name, aEng ? 'en' : 'th');
    });

  const totalCards = filteredMembers.reduce((s, m) => s + m.total, 0);
  const totalFunctional = filteredMembers.reduce((s, m) => s + m.functional, 0);
  const totalDefect = filteredMembers.reduce((s, m) => s + m.defect, 0);

  return (
    <div className={embedded ? '' : 'p-6 space-y-6'}>
      {!embedded && emailResult && (
        <div className={`fixed top-4 right-4 z-50 px-4 py-3 rounded-xl shadow-lg text-sm font-semibold flex items-center gap-2 ${
          emailResult.success === null ? 'bg-amber-500 text-white' : emailResult.success ? 'bg-emerald-600 text-white' : 'bg-red-600 text-white'
        }`}>
          <span className={`material-icons text-base ${emailResult.success === null ? 'animate-spin' : ''}`}>
            {emailResult.success === null ? 'sync' : emailResult.success ? 'check_circle' : 'error_outline'}
          </span>
          {emailResult.message}
        </div>
      )}
      <div ref={contentRef} className="space-y-6">
      {!embedded && (
        <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm flex items-end justify-between gap-4 flex-wrap">
          <div>
            <Link
              to="/sprint-dashboard"
              state={{ chartType: 'distribution' }}
              className="no-print inline-flex items-center gap-1.5 text-xs font-semibold text-slate-700 bg-white border border-gray-200 hover:border-amber-400 hover:text-amber-700 hover:bg-amber-50 px-3 py-1.5 rounded-lg mb-2 transition shadow-sm"
            >
              <span className="material-icons text-sm">arrow_back</span>
              กลับไป Jira Analytics
            </Link>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold text-gray-900">Member Distribution</h1>
              {sprint?.name?.match(/(\d+)$/) && (
                <span className="text-lg font-bold text-emerald-600 bg-emerald-50 px-2.5 py-0.5 rounded-lg border border-emerald-100">
                  #{sprint.name.match(/(\d+)$/)[1]}
                </span>
              )}
            </div>
            <p className="text-sm text-gray-400 mt-1">{sprint?.name}</p>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center bg-gray-200/70 rounded-full p-1">
              <button
                onClick={() => navigate(`/sprint-dashboard/distribution/${sprintId}`)}
                className="px-5 py-1.5 text-xs font-semibold rounded-full transition-all duration-200 text-gray-500 hover:text-gray-700"
              >
                System View
              </button>
              <button
                onClick={() => navigate(`/sprint-dashboard/member-distribution/${sprintId}`)}
                className="px-5 py-1.5 text-xs font-semibold rounded-full transition-all duration-200 bg-gray-800 text-white shadow-sm"
              >
                Member View
              </button>
            </div>
            <button
              onClick={() => setShowEmailModal(true)}
              className="no-print inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-gradient-to-r from-amber-500 to-orange-500 text-white text-xs font-bold shadow-md hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0 active:scale-95 transition-all border-0 cursor-pointer"
            >
              <span className="material-icons text-sm">forward_to_inbox</span>
              ส่งรายงาน
            </button>
          </div>
        </div>
      )}

      {isSyncing && (
        <div className="flex items-center gap-2 text-sm text-amber-600 bg-amber-50 px-4 py-2 rounded-lg">
          <span className="material-icons text-sm animate-spin">sync</span>
          กำลัง Sync ข้อมูล Sprint...
        </div>
      )}

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-2xl px-5 py-3 flex items-center gap-3">
          <span className="material-icons text-red-400">error_outline</span>
          <p className="text-sm font-semibold text-red-700">{error}</p>
        </div>
      )}

      {isLoading ? (
        <div className="bg-white rounded-2xl p-16 border border-gray-200 flex flex-col items-center gap-3">
          <span className="material-icons text-4xl text-gray-300 animate-spin">refresh</span>
          <p className="text-sm text-gray-400">กำลังโหลดข้อมูล...</p>
        </div>
      ) : filteredMembers.length === 0 ? (
        <div className="bg-white rounded-2xl p-16 border border-gray-200 flex flex-col items-center gap-3">
          <span className="material-icons text-4xl text-gray-300">search_off</span>
          <p className="text-sm text-gray-400">
            {memberDistribution.length === 0
              ? 'ยังไม่มีข้อมูล — กด "Sync ข้อมูล" ใน Sidebar'
              : 'ไม่พบข้อมูลที่ตรงกับตัวกรอง'}
          </p>
        </div>
      ) : (
        <>
          {/* KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm">
              <p className="text-xs text-gray-400 font-medium">งานทั้งหมด</p>
              <p className="text-3xl font-bold text-gray-800 mt-1">{totalCards}</p>
              <p className="text-xs text-gray-400 mt-1">cards</p>
            </div>
            <div className="bg-white p-5 rounded-2xl border shadow-sm" style={{ borderColor: `${TYPE_COLORS.Functional}40` }}>
              <p className="text-xs text-gray-400 font-medium">Functional</p>
              <p className="text-3xl font-bold mt-1" style={{ color: TYPE_COLORS.Functional }}>{totalFunctional}</p>
              <p className="text-xs text-gray-400 mt-1">{totalCards > 0 ? Math.round(totalFunctional / totalCards * 100) : 0}% ของทั้งหมด</p>
            </div>
            <div className="bg-white p-5 rounded-2xl border shadow-sm" style={{ borderColor: `${TYPE_COLORS.Defect}40` }}>
              <p className="text-xs text-gray-400 font-medium">Defect</p>
              <p className="text-3xl font-bold mt-1" style={{ color: TYPE_COLORS.Defect }}>{totalDefect}</p>
              <p className="text-xs text-gray-400 mt-1">{totalCards > 0 ? Math.round(totalDefect / totalCards * 100) : 0}% ของทั้งหมด</p>
            </div>
          </div>

          {/* Member Table */}
          <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm space-y-4">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between border-b border-gray-100 pb-4 gap-3">
              <div className="flex items-center gap-2">
                <span className="material-icons text-gray-600">people</span>
                <span className="font-bold text-gray-900 text-lg">การกระจายงานตามคน</span>
              </div>

              {/* Controls row */}
              <div className="flex flex-wrap items-center gap-2 no-print">
                {/* Search */}
                <div className="relative">
                  <span className="material-icons absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400 text-sm">search</span>
                  <input
                    type="text"
                    value={searchName}
                    onChange={e => setSearchName(e.target.value)}
                    placeholder="ค้นหาชื่อ..."
                    className="w-40 pl-8 pr-2 py-1.5 text-xs border border-gray-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-300 focus:border-amber-300"
                  />
                </div>

                {/* System filter */}
                <div className="relative" ref={systemDropdownRef}>
                  <button
                    onClick={() => setIsSystemOpen(o => !o)}
                    className="flex items-center gap-2 pl-3 pr-2 py-1.5 text-xs font-medium text-gray-700 border border-gray-200 rounded-lg hover:border-amber-300 hover:bg-amber-50/50 focus:outline-none focus:ring-1 focus:ring-amber-300 focus:border-amber-300 bg-white transition min-w-[140px]"
                  >
                    <span className="flex-1 text-left">
                      {systemFilter.length === 0
                        ? 'ทุกระบบ'
                        : systemFilter.length === 1
                          ? systemFilter[0]
                          : `เลือก ${systemFilter.length} ระบบ`}
                    </span>
                    <span className={`material-icons text-gray-400 text-sm transition-transform ${isSystemOpen ? 'rotate-180' : ''}`}>expand_more</span>
                  </button>
                  {isSystemOpen && (
                    <div className="absolute z-10 mt-1 w-full min-w-[180px] bg-white border border-gray-200 rounded-lg shadow-lg overflow-hidden py-1 max-h-60 overflow-y-auto">
                      <div
                        onClick={() => setSystemFilter([])}
                        className={`px-3 py-1.5 text-xs cursor-pointer transition hover:bg-amber-50 flex items-center gap-2 ${systemFilter.length === 0 ? 'bg-amber-50 text-amber-700 font-semibold' : 'text-gray-700'}`}
                      >
                        <span className="flex-1">ทุกระบบ</span>
                        <span className="material-icons text-sm">{systemFilter.length === 0 ? 'check_box' : 'check_box_outline_blank'}</span>
                      </div>
                      <div className="border-t border-gray-100 my-1" />
                      {allSystems.map(sys => {
                        const selected = systemFilter.includes(sys);
                        return (
                          <div
                            key={sys}
                            onClick={() => {
                              setSystemFilter(prev =>
                                selected ? prev.filter(s => s !== sys) : [...prev, sys]
                              );
                            }}
                            className={`px-3 py-1.5 text-xs cursor-pointer transition hover:bg-amber-50 flex items-center gap-2 ${selected ? 'bg-amber-50 text-amber-700 font-semibold' : 'text-gray-700'}`}
                          >
                            <span
                              className="w-2 h-2 rounded-full"
                              style={{ backgroundColor: getSystemColor(sys) }}
                            />
                            <span className="flex-1">{sys}</span>
                            <span className="material-icons text-sm">{selected ? 'check_box' : 'check_box_outline_blank'}</span>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* Type segmented */}
                <div className="flex items-center bg-gray-100 rounded-full p-1">
                  {[
                    { key: '', label: 'ทั้งหมด' },
                    { key: 'Functional', label: 'Functional' },
                    { key: 'Defect', label: 'Defect' },
                  ].map(({ key, label }) => {
                    const activeBg = key === 'Functional' ? 'bg-emerald-500'
                      : key === 'Defect' ? 'bg-red-500'
                      : 'bg-gray-800';
                    return (
                      <button
                        key={key || 'all'}
                        onClick={() => setTypeFilter(key)}
                        className={`px-3 py-1.5 text-xs font-semibold rounded-full transition-all duration-200 ${
                          typeFilter === key
                            ? `${activeBg} text-white shadow-sm`
                            : 'text-gray-500 hover:text-gray-700'
                        }`}
                      >
                        {label}
                      </button>
                    );
                  })}
                </div>

              </div>
            </div>

            <div className="rounded-xl border border-gray-100 overflow-hidden">
              <table className="w-full text-sm text-left">
                <thead className="bg-gray-50 text-xs font-semibold text-gray-500">
                  <tr>
                    <th className="px-4 py-3">Member</th>
                    <th className="px-4 py-3">ระบบที่ทำ</th>
                    <th className="px-4 py-3 text-center" style={{ color: TYPE_COLORS.Functional }}>Functional</th>
                    <th className="px-4 py-3 text-center" style={{ color: TYPE_COLORS.Defect }}>Defect</th>
                    <th className="px-4 py-3 text-center">รวม</th>
                    <th className="px-4 py-3 text-center no-print">รายละเอียด</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {filteredMembers.map((member) => (
                    <tr key={member.accountId} className="hover:bg-slate-50">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-full bg-slate-700 text-white flex items-center justify-center text-xs font-bold shrink-0">
                            {member.name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase()}
                          </div>
                          <span className="font-medium text-gray-800 text-sm">{member.name}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex flex-wrap gap-1.5">
                          {[...member.displaySystems].sort().map(sys => (
                            <span
                              key={sys}
                              className="text-[10px] font-semibold px-2 py-0.5 rounded-full border"
                              style={{ borderColor: `${getSystemColor(sys)}40`, backgroundColor: `${getSystemColor(sys)}10`, color: getSystemColor(sys) }}
                            >
                              {sys}
                            </span>
                          ))}
                        </div>
                      </td>
                      <td className="px-4 py-3 text-center text-sm text-gray-600">{member.functional || '—'}</td>
                      <td className="px-4 py-3 text-center text-sm text-gray-600">{member.defect || '—'}</td>
                      <td className="px-4 py-3 text-center text-sm font-bold text-gray-800">{member.total}</td>
                      <td className="px-4 py-3 text-center no-print">
                        <button
                          onClick={() => openMemberModal(member)}
                          className="inline-flex items-center gap-1 text-xs font-semibold text-slate-400 hover:text-amber-700 hover:bg-amber-50 px-2.5 py-1 rounded-lg border border-gray-100 hover:border-amber-300 transition"
                        >
                          <span className="material-icons text-sm">assignment</span>
                          ดูรายละเอียด
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="bg-gray-50 border-t-2 border-gray-100 text-sm font-bold">
                    <td className="px-4 py-3 text-gray-800">รวม</td>
                    <td className="px-4 py-3 text-gray-400 font-normal">{allSystems.length} systems</td>
                    <td className="px-4 py-3 text-center text-gray-600">{totalFunctional || '—'}</td>
                    <td className="px-4 py-3 text-center text-gray-600">{totalDefect || '—'}</td>
                    <td className="px-4 py-3 text-center text-sm font-bold text-gray-800">{totalCards}</td>
                    <td className="px-4 py-3 no-print" />
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </>
      )}

      {/* Member Detail Modal */}
      {modal && (() => {
        const typeOrder = { Functional: 0, Defect: 1 };
        const sortByType = (a, b) => {
          const ta = typeOrder[normalizeType(a.issueType)] ?? 99;
          const tb = typeOrder[normalizeType(b.issueType)] ?? 99;
          if (ta !== tb) return ta - tb;
          return a.key.localeCompare(b.key);
        };
        const done   = modal.issues.filter(i => i.statusCategory === 'done').sort(sortByType);
        const inprog = modal.issues.filter(i => i.statusCategory === 'indeterminate').sort(sortByType);
        const todo   = modal.issues.filter(i => i.statusCategory !== 'done' && i.statusCategory !== 'indeterminate').sort(sortByType);
        return (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={() => setModal(null)}>
            <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden border border-gray-100" onClick={e => e.stopPropagation()}>

              {/* Header */}
              <div className="px-6 py-4 flex justify-between items-center border-b border-gray-100">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-slate-700 text-white flex items-center justify-center text-sm font-bold shrink-0">
                    {modal.member.name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase()}
                  </div>
                  <div>
                    <p className="font-bold text-gray-900 text-sm">{modal.member.name}</p>
                    <p className="text-xs text-gray-400">Member Distribution · {sprint?.name || ''}</p>
                  </div>
                </div>
                <button
                  onClick={() => setModal(null)}
                  className="text-gray-400 hover:text-gray-600 p-1.5 rounded-lg hover:bg-gray-100 transition cursor-pointer border-0 bg-transparent"
                >
                  <span className="material-icons text-xl">close</span>
                </button>
              </div>

              {modal.isLoading ? (
                <div className="flex flex-col items-center justify-center py-16 gap-3">
                  <span className="material-icons text-4xl text-gray-300 animate-spin">refresh</span>
                  <p className="text-sm text-gray-400">กำลังดึงข้อมูลจาก Jira...</p>
                </div>
              ) : modal.error ? (
                <div className="flex items-center justify-center gap-2 text-sm text-red-500 py-16">
                  <span className="material-icons text-base">error_outline</span>
                  ไม่สามารถดึงข้อมูลจาก Jira ได้
                </div>
              ) : (
                <>
                  {/* Summary stats */}
                  <div className="grid grid-cols-3 divide-x divide-gray-100 border-b border-gray-100 bg-gray-50">
                    <div className="px-6 py-4 text-center">
                      <p className="text-2xl font-bold text-gray-800">{modal.issues.length}</p>
                      <p className="text-sm text-gray-400 mt-1">งานทั้งหมด</p>
                    </div>
                    <div className="px-6 py-4 text-center">
                      <p className="text-2xl font-bold text-emerald-600">{done.length}</p>
                      <p className="text-sm text-gray-400 mt-1">เสร็จแล้ว</p>
                    </div>
                    <div className="px-6 py-4 text-center">
                      <p className="text-2xl font-bold text-amber-500">{inprog.length + todo.length}</p>
                      <p className="text-sm text-gray-400 mt-1">ค้างอยู่</p>
                    </div>
                  </div>

                  {/* Issue lists grouped by status */}
                  <div className="p-6 space-y-6 max-h-[500px] overflow-y-auto">
                    {modal.issues.length === 0 ? (
                      <p className="text-base text-gray-400 italic text-center py-8">ไม่พบ Issues</p>
                    ) : (
                      <>
                        {/* Done */}
                        {done.length > 0 && (
                          <div>
                            <div className="flex items-center gap-2 mb-4">
                              <span className="w-3 h-3 rounded-full bg-emerald-500 shrink-0"></span>
                              <span className="text-sm font-bold text-gray-500 uppercase tracking-wider">เสร็จสมบูรณ์ ({done.length} cards)</span>
                            </div>
                            <div className="space-y-3">
                              {done.map(issue => (
                                <div
                                  key={issue.key}
                                  className="flex items-start justify-between gap-4 p-4 bg-white rounded-xl border border-gray-100 hover:border-emerald-200 hover:bg-emerald-50/30 transition shadow-sm"
                                >
                                  <div className="flex items-start gap-3 min-w-0 flex-1">
                                    <span className="w-2 h-2 rounded-full bg-emerald-500 mt-2.5 shrink-0"></span>
                                    <div className="min-w-0 flex-1">
                                      <span className="text-xs font-bold text-gray-400 uppercase">{issue.key}</span>
                                      <p className="text-base text-gray-800 font-medium leading-snug mt-1">{issue.summary}</p>
                                    </div>
                                  </div>
                                  <div className="flex items-center gap-1.5 shrink-0">
                                    <span
                                      className="text-[10px] font-bold px-2 py-0.5 rounded-full border"
                                      style={{ borderColor: `${getSystemColor(issue.system)}40`, backgroundColor: `${getSystemColor(issue.system)}10`, color: getSystemColor(issue.system) }}
                                    >
                                      {issue.system}
                                    </span>
                                    <span className="text-xs font-bold px-2.5 py-1 rounded-lg" style={{ backgroundColor: `${getTypeColor(issue.issueType)}15`, color: getTypeColor(issue.issueType) }}>
                                      {normalizeType(issue.issueType)}
                                    </span>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Pending */}
                        {(inprog.length > 0 || todo.length > 0) && (
                          <div>
                            <div className="flex items-center gap-2 mb-4">
                              <span className="w-3 h-3 rounded-full bg-amber-400 shrink-0"></span>
                              <span className="text-sm font-bold text-gray-500 uppercase tracking-wider">ค้างอยู่ ({inprog.length + todo.length} cards)</span>
                            </div>
                            <div className="space-y-3">
                              {[...inprog, ...todo].map(issue => (
                                <div
                                  key={issue.key}
                                  className="flex items-start justify-between gap-4 p-4 bg-white rounded-xl border border-gray-100 hover:border-amber-200 hover:bg-amber-50/30 transition shadow-sm"
                                >
                                  <div className="flex items-start gap-3 min-w-0 flex-1">
                                    <span className="w-2 h-2 rounded-full bg-amber-400 mt-2.5 shrink-0"></span>
                                    <div className="min-w-0 flex-1">
                                      <span className="text-xs font-bold text-gray-400 uppercase">{issue.key}</span>
                                      <p className="text-base text-gray-800 font-medium leading-snug mt-1">{issue.summary}</p>
                                    </div>
                                  </div>
                                  <div className="flex items-center gap-1.5 shrink-0">
                                    <span
                                      className="text-[10px] font-bold px-2 py-0.5 rounded-full border"
                                      style={{ borderColor: `${getSystemColor(issue.system)}40`, backgroundColor: `${getSystemColor(issue.system)}10`, color: getSystemColor(issue.system) }}
                                    >
                                      {issue.system}
                                    </span>
                                    <span className="text-xs font-bold px-2.5 py-1 rounded-lg" style={{ backgroundColor: `${getTypeColor(issue.issueType)}15`, color: getTypeColor(issue.issueType) }}>
                                      {normalizeType(issue.issueType)}
                                    </span>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                </>
              )}
            </div>
          </div>
        );
      })()}
      </div>{/* end contentRef */}
      {!embedded && (
        <SendEmailModal
          isOpen={showEmailModal}
          onClose={() => setShowEmailModal(false)}
          onConfirm={handleSendEmail}
          sprintName={sprint?.name}
          isGenerating={isSendingEmail}
          contentRef={contentRef}
        />
      )}
    </div>
  );
};

export default MemberDistribution;
