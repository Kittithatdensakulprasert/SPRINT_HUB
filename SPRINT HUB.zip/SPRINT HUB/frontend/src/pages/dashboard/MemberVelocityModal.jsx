import React, { useState, useEffect } from 'react';
import { sprintApi, sprintResultApi } from '../../services/api';

const MemberVelocityModal = ({ member, onClose, onOpenJira }) => {
  const [chartData, setChartData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showAll, setShowAll] = useState(false);

  useEffect(() => {
    const load = async () => {
      try {
        const [sprintList, allResults] = await Promise.all([
          sprintApi.getAll(),
          sprintResultApi.getAll(),
        ]);
        const memberResults = allResults.filter(r => r.memberId === member.id);
        const resultBySprint = {};
        memberResults.forEach(r => { resultBySprint[r.sprintId] = r; });

        const data = sprintList
          .map(s => {
            const r = resultBySprint[s.id];
            return {
              id: s.id,
              name: s.name,
              target: r?.targetPts || 0,
              done: r?.donePts || 0,
              remaining: r?.remainingPts || 0,
            };
          })
          .filter(d => d.target > 0 || d.done > 0)
          .reverse();

        setChartData(data);
      } catch (e) {
        setChartData([]);
      } finally {
        setIsLoading(false);
      }
    };
    load();
  }, [member.id]);

  const initials = member.name.split(' ').map(w => w[0]).slice(0, 2).join('');

  const displayData = showAll ? chartData : chartData.slice(-10);

  const avgPct = chartData.length > 0
    ? Math.round(chartData.reduce((sum, d) => sum + (d.target > 0 ? (d.done / d.target) * 100 : 0), 0) / chartData.length)
    : 0;

  const totalDone = chartData.reduce((sum, d) => sum + d.done, 0);
  const totalTarget = chartData.reduce((sum, d) => sum + d.target, 0);

  const displayName = (name) => {
    const m = name.match(/(\d{2,4})$/);
    return m ? m[1] : name.slice(0, 8);
  };

  const chartH = 200;
  const groupW = 60;
  const barW = 24;
  const leftPad = 44;
  const rightPad = 16;
  const chartW = Math.max(360, displayData.length * groupW + leftPad + rightPad);

  const rawMax = Math.max(...displayData.flatMap(d => [d.target, d.done]), 1);
  const maxVal = Math.ceil(rawMax / 10) * 10 || 10;
  const yTicks = [0, maxVal * 0.25, maxVal * 0.5, maxVal * 0.75, maxVal].map(v => Math.round(v));

  const toY = (val) => chartH - (val / maxVal) * chartH * 0.85;
  const toPctY = (pct) => chartH - (pct / 100) * chartH * 0.85;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4" onClick={onClose}>
      <div
        className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 pt-6 pb-4 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-slate-700 text-white flex items-center justify-center text-sm font-bold shrink-0">
              {initials}
            </div>
            <div>
              <h2 className="text-lg font-bold text-gray-900">{member.name}</h2>
              <p className="text-xs text-gray-400">{member.jiraUsername}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition"
          >
            <span className="material-icons text-lg">close</span>
          </button>
        </div>

        <div className="px-6 py-5 space-y-5">
          {/* KPI summary */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-blue-50 rounded-xl p-3 text-center">
              <p className="text-xs text-blue-400 font-semibold">% สำเร็จเฉลี่ย</p>
              <p className={`text-2xl font-bold mt-1 ${avgPct >= 100 ? 'text-emerald-600' : avgPct >= 60 ? 'text-amber-600' : 'text-red-500'}`}>{avgPct}%</p>
            </div>
            <div className="bg-emerald-50 rounded-xl p-3 text-center">
              <p className="text-xs text-emerald-400 font-semibold">Done รวม</p>
              <p className="text-2xl font-bold text-emerald-600 mt-1">{totalDone} <span className="text-xs font-normal text-gray-400">cards</span></p>
            </div>
          </div>

          {/* Legend + toggle */}
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs text-gray-500">
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-sm bg-slate-300" />
                <span>เป้าหมาย (Target)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-sm bg-emerald-400" />
                <span>สำเร็จตามเป้าหมาย ≥ 100%</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-sm bg-amber-400" />
                <span>ต่ำกว่าเป้าหมาย ≥ 50%</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-sm bg-red-400" />
                <span>ต่ำกว่าเป้าหมาย 50%</span>
              </div>
            </div>
            {chartData.length > 10 && (
              <button
                onClick={() => setShowAll(!showAll)}
                className="text-xs font-semibold text-slate-500 hover:text-amber-700 bg-white border border-gray-200 hover:border-amber-300 rounded-lg px-3 py-1.5 transition cursor-pointer shrink-0"
              >
                {showAll ? 'แสดง 10 ล่าสุด' : `แสดงทั้งหมด (${chartData.length})`}
              </button>
            )}
          </div>

          {/* Chart */}
          {isLoading ? (
            <div className="flex items-center justify-center py-16">
              <span className="material-icons text-3xl text-gray-200 animate-spin">refresh</span>
            </div>
          ) : chartData.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <span className="material-icons text-4xl text-gray-200 block mb-2">insert_chart</span>
              <p className="text-sm text-gray-400">ยังไม่มีข้อมูล Sprint Results</p>
            </div>
          ) : (
            <div className="w-full overflow-x-auto pb-2">
              <div style={{ minWidth: `${chartW}px` }}>
                <svg viewBox={`0 0 ${chartW} ${chartH + 50}`} className="w-full" style={{ minHeight: '240px' }}>
                  {/* Y grid + labels */}
                  {yTicks.map((tick, i) => {
                    const y = toY(tick) + 10;
                    return (
                      <g key={i}>
                        <line x1={leftPad} y1={y} x2={chartW - rightPad} y2={y} stroke="#f0f0f0" strokeWidth="1" />
                        <text x={leftPad - 6} y={y + 4} textAnchor="end" fontSize="9" fill="#9ca3af">{tick}</text>
                      </g>
                    );
                  })}

                  {/* X axis */}
                  <line x1={leftPad} y1={chartH + 10} x2={chartW - rightPad} y2={chartH + 10} stroke="#e5e7eb" strokeWidth="1" />

                  {/* Bars */}
                  {displayData.map((d, i) => {
                    const x = leftPad + i * groupW + (groupW - 2 * barW - 4) / 2;
                    const targetH = chartH * 0.85 * (d.target / maxVal);
                    const doneH = chartH * 0.85 * (d.done / maxVal);
                    const pct = d.target > 0 ? Math.round((d.done / d.target) * 100) : 0;
                    const lineY = toPctY(pct) + 10;
                    const doneColor = pct >= 100 ? '#34d399' : pct >= 50 ? '#fbbf24' : '#f87171';

                    return (
                      <g key={i}>
                        {/* Target bar (slate gray) */}
                        <rect x={x} y={toY(d.target) + 10} width={barW} height={targetH} rx="3" fill="#cbd5e1" />
                        {targetH > 14 && d.target > 0 && (
                          <text x={x + barW / 2} y={toY(d.target) + 6} textAnchor="middle" fontSize="9" fill="#475569" fontWeight="600">{d.target}</text>
                        )}

                        {/* Done bar */}
                        <rect x={x + barW + 4} y={toY(d.done) + 10} width={barW} height={doneH} rx="3" fill={doneColor} />
                        {doneH > 14 && d.done > 0 && (
                          <text x={x + barW + 4 + barW / 2} y={toY(d.done) + 6} textAnchor="middle" fontSize="9" fill="#374151" fontWeight="600">{d.done}</text>
                        )}

                        {/* % line dot */}
                        <circle cx={x + barW + 4 + barW / 2} cy={lineY} r="3" fill="#3b82f6" />

                        {/* Sprint label */}
                        <text x={x + barW + 2} y={chartH + 24} textAnchor="middle" fontSize="9" fill="#6b7280" fontWeight="600">
                          {displayName(d.name)}
                        </text>

                        {/* % label */}
                        <text x={x + barW + 4 + barW / 2} y={chartH + 38} textAnchor="middle" fontSize="9"
                          fill={pct >= 100 ? '#059669' : pct >= 60 ? '#d97706' : '#dc2626'} fontWeight="700">
                          {pct}%
                        </text>
                      </g>
                    );
                  })}

                  {/* % trend line */}
                  {displayData.length > 1 && (
                    <polyline
                      fill="none" stroke="#3b82f6" strokeWidth="1.5" strokeDasharray="4 2"
                      points={displayData.map((d, i) => {
                        const x = leftPad + i * groupW + (groupW - 2 * barW - 4) / 2 + barW + 4 + barW / 2;
                        const pct = d.target > 0 ? (d.done / d.target) * 100 : 0;
                        const y = toPctY(pct) + 10;
                        return `${x},${y}`;
                      }).join(' ')}
                    />
                  )}
                </svg>
              </div>
            </div>
          )}

          {/* Table */}
          {!isLoading && chartData.length > 0 && (
            <div className="rounded-xl border border-gray-100 overflow-hidden">
              <table className="w-full text-sm text-left">
                <thead className="bg-gray-50 text-xs font-semibold text-gray-500">
                  <tr>
                    <th className="px-4 py-2.5">Sprint</th>
                    <th className="px-4 py-2.5 text-center">เป้าหมาย</th>
                    <th className="px-4 py-2.5 text-center">Done</th>
                    <th className="px-4 py-2.5 text-center">% สำเร็จ</th>
                    <th className="px-4 py-2.5 text-center">รายละเอียด</th>
                    {onOpenJira && <th className="px-4 py-2.5"></th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {[...displayData].reverse().map((d, i) => {
                    const pct = d.target > 0 ? Math.round((d.done / d.target) * 100) : 0;
                    return (
                      <tr key={i} className="hover:bg-slate-50">
                        <td className="px-4 py-2.5 font-medium text-gray-700 text-xs">{d.name}</td>
                        <td className="px-4 py-2.5 text-center text-gray-500 text-xs">{d.target}</td>
                        <td className="px-4 py-2.5 text-center font-semibold text-emerald-600 text-xs">{d.done}</td>
                        <td className="px-4 py-2.5 text-center">
                          <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-bold ${pct >= 100 ? 'bg-emerald-100 text-emerald-700' : pct >= 50 ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-700'}`}>
                            {pct}%
                          </span>
                        </td>
                        {onOpenJira && (
                          <td className="px-4 py-2.5 text-right">
                            <button
                              onClick={() => onOpenJira(d.id)}
                              className="inline-flex items-center gap-1 text-xs font-semibold text-slate-400 hover:text-amber-700 hover:bg-amber-50 px-2.5 py-1 rounded-lg border border-gray-100 hover:border-amber-300 transition"
                            >
                              <span className="material-icons text-sm">assignment</span>
                              ดูรายละเอียด
                            </button>
                          </td>
                        )}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MemberVelocityModal;
