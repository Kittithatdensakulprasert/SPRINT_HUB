/**
 * SprintDistribution.jsx
 * หน้ารายละเอียด Work Distribution ของ sprint หนึ่ง
 * แสดง bar chart แบ่งตาม Issue Type และ System
 */

import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { jiraApi, sprintApi } from '../../services/api';

const TYPE_COLORS = {
  Bug:     '#ef4444',
  Story:   '#3b82f6',
  Task:    '#10b981',
  Default: '#8b5cf6',
};
const getTypeColor = (type) => TYPE_COLORS[type] || TYPE_COLORS.Default;

const SprintDistribution = () => {
  const { sprintId } = useParams();

  const [sprint, setSprint] = useState(null);
  const [distribution, setDistribution] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const [error, setError] = useState(null);
  const [jiraConfigured, setJiraConfigured] = useState(false);
  const [modal, setModal] = useState(null); // { system, issues[], isLoading }

  useEffect(() => {
    loadData();
  }, [sprintId]);

  // ฟัง jira-force-sync จาก Sidebar
  useEffect(() => {
    const handleForceSync = async (e) => {
      if (!sprintId) return;
      setIsSyncing(true);
      try {
        await jiraApi.syncDistribution(Number(sprintId)).catch(() => null);
        const data = await jiraApi.getDistribution(Number(sprintId));
        setDistribution(data);
        window.dispatchEvent(new CustomEvent('jira-sync-done', { detail: { success: true } }));
      } catch {
        window.dispatchEvent(new CustomEvent('jira-sync-done', { detail: { success: false } }));
      } finally {
        setIsSyncing(false);
      }
    };
    window.addEventListener('jira-force-sync', handleForceSync);
    return () => window.removeEventListener('jira-force-sync', handleForceSync);
  }, [sprintId]);

  const loadData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const [sprintData, jiraStatus] = await Promise.all([
        sprintApi.getById(Number(sprintId)),
        jiraApi.getStatus().catch(() => ({ configured: false })),
      ]);
      setSprint(sprintData);
      setJiraConfigured(jiraStatus.configured);

      let data = await jiraApi.getDistribution(Number(sprintId));
      // ถ้า DB ว่าง + Jira พร้อม → auto sync ครั้งแรก
      if (data.length === 0 && jiraStatus.configured) {
        setIsSyncing(true);
        await jiraApi.syncDistribution(Number(sprintId)).catch(() => null);
        setIsSyncing(false);
        data = await jiraApi.getDistribution(Number(sprintId));
      }
      setDistribution(data);
    } catch (e) {
      setError('ไม่สามารถโหลดข้อมูลได้');
    } finally {
      setIsLoading(false);
    }
  };

  // --- aggregate ---
  const byType = distribution.reduce((acc, d) => {
    acc[d.issueType] = (acc[d.issueType] || 0) + d.totalCount;
    return acc;
  }, {});
  const typeEntries = Object.entries(byType).sort((a, b) => b[1] - a[1]);
  const totalByType = typeEntries.reduce((s, [, v]) => s + v, 0);

  const bySystem = distribution.reduce((acc, d) => {
    const sys = d.systemName || 'OTHER';
    acc[sys] = (acc[sys] || 0) + d.totalCount;
    return acc;
  }, {});
  const systemEntries = Object.entries(bySystem).sort((a, b) => b[1] - a[1]);
  const totalBySystem = systemEntries.reduce((s, [, v]) => s + v, 0);

  // cross table: issueType × system
  const TYPE_ORDER = ['Task', 'Bug', 'Story'];
  const rawTypes = [...new Set(distribution.map(d => d.issueType))];
  const allTypes = [
    ...TYPE_ORDER.filter(t => rawTypes.includes(t)),
    ...rawTypes.filter(t => !TYPE_ORDER.includes(t)).sort(),
  ];
  const allSystems = [...new Set(distribution.map(d => d.systemName || 'OTHER'))].sort();
  const crossMap   = {};
  distribution.forEach(d => {
    const sys = d.systemName || 'OTHER';
    if (!crossMap[d.issueType]) crossMap[d.issueType] = {};
    crossMap[d.issueType][sys] = (crossMap[d.issueType][sys] || 0) + d.totalCount;
  });

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm flex items-center justify-between gap-4 flex-wrap">
        <div>
          <Link
            to="/sprint-dashboard"
            state={{ chartType: 'distribution' }}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-700 bg-white border border-gray-200 hover:border-amber-400 hover:text-amber-700 hover:bg-amber-50 px-3 py-1.5 rounded-lg mb-2 transition shadow-sm"
          >
            <span className="material-icons text-sm">arrow_back</span>
            กลับไป Jira Analytics
          </Link>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-gray-900">Work Distribution</h1>
            {sprint?.name?.match(/(\d+)$/) && (
              <span className="text-lg font-bold text-emerald-600 bg-emerald-50 px-2.5 py-0.5 rounded-lg border border-emerald-100">
                #{sprint.name.match(/(\d+)$/)[1]}
              </span>
            )}
            <span
              title={jiraConfigured ? 'เชื่อมต่อ Jira แล้ว' : 'ไม่ได้เชื่อมต่อ Jira'}
              className={`w-2.5 h-2.5 rounded-full shrink-0 ${jiraConfigured ? 'bg-emerald-500' : 'bg-red-400'}`}
            />
          </div>
          <div className="flex items-center gap-2 mt-1 flex-wrap">
            <p className="text-sm text-gray-500">ดูการกระจายงานตาม Issue Type และ System</p>
            {sprint?.startDate && sprint?.endDate && (
              <span className="inline-flex items-center gap-1.5 text-xs font-medium text-gray-500 bg-gray-100 px-2.5 py-1 rounded-full">
                <span className="material-icons text-xs text-gray-400">calendar_today</span>
                {new Date(sprint.startDate).toLocaleDateString('th-TH', { day: 'numeric', month: 'short', year: 'numeric' })}
                {' – '}
                {new Date(sprint.endDate).toLocaleDateString('th-TH', { day: 'numeric', month: 'short', year: 'numeric' })}
              </span>
            )}
          </div>
        </div>
      </div>

      {isSyncing && (
        <div className="flex items-center gap-2 text-sm text-amber-600 bg-amber-50 px-4 py-2 rounded-lg">
          <span className="material-icons text-sm animate-spin">sync</span>
          กำลัง Sync ข้อมูล Sprint...
        </div>
      )}

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-2xl px-5 py-3 flex items-center gap-3">
          <span className="material-icons text-red-400">error_outline</span>
          <p className="text-sm font-semibold text-red-700">{error}</p>
        </div>
      )}

      {isLoading ? (
        <div className="bg-white rounded-2xl p-16 border border-gray-200 flex flex-col items-center gap-3">
          <span className="material-icons text-4xl text-gray-300 animate-spin">refresh</span>
          <p className="text-sm text-gray-400">กำลังโหลดข้อมูล...</p>
        </div>
      ) : distribution.length === 0 ? (
        <div className="bg-white rounded-2xl p-16 border border-gray-200 flex flex-col items-center gap-3">
          <span className="material-icons text-4xl text-gray-300">bar_chart</span>
          <p className="text-sm text-gray-400">ยังไม่มีข้อมูล — กด "Sync ข้อมูล" ใน Sidebar</p>
        </div>
      ) : (
        <>
          {/* KPI Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm">
              <p className="text-xs text-gray-400 font-medium">งานทั้งหมด</p>
              <p className="text-3xl font-bold text-gray-800 mt-1">{totalByType}</p>
              <p className="text-xs text-gray-400 mt-1">cards</p>
            </div>
            {allTypes.filter(t => byType[t]).map(type => {
              const count = byType[type] || 0;
              const pct = totalByType > 0 ? Math.round(count / totalByType * 100) : 0;
              const color = getTypeColor(type);
              return (
                <div key={type} className="bg-white p-5 rounded-2xl border shadow-sm" style={{ borderColor: `${color}40` }}>
                  <p className="text-xs text-gray-400 font-medium">{type}</p>
                  <p className="text-3xl font-bold mt-1" style={{ color }}>{count}</p>
                  <p className="text-xs text-gray-400 mt-1">{pct}% ของทั้งหมด</p>
                </div>
              );
            })}
          </div>

          {/* Distribution Table */}
          <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm space-y-4">
            {/* Section header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-gray-100 pb-4 gap-3">
              <div className="flex items-center gap-2">
                <span className="material-icons text-gray-500">bar_chart</span>
                <span className="font-bold text-gray-900 text-lg">การกระจายงานตามระบบ</span>
              </div>
              <div className="flex items-center gap-3">
                {allTypes.map(type => (
                  <span key={type} className="flex items-center gap-1.5 text-xs font-semibold text-gray-500">
                    <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: getTypeColor(type) }} />
                    {type}
                  </span>
                ))}
              </div>
            </div>

            {/* Table */}
            <div className="rounded-xl border border-gray-100 overflow-hidden">
              <table className="w-full text-sm text-left">
                <thead className="bg-gray-50 text-xs font-semibold text-gray-500">
                  <tr>
                    <th className="px-4 py-3">System</th>
                    <th className="px-4 py-3 w-44">สัดส่วน</th>
                    {allTypes.map(type => (
                      <th key={type} className="px-4 py-3 text-center" style={{ color: getTypeColor(type) }}>{type}</th>
                    ))}
                    <th className="px-4 py-3 text-center">รวม</th>
                    <th className="px-4 py-3 text-center">รายละเอียด</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {systemEntries.map(([sys, sysTotal]) => {
                    const pct = totalBySystem > 0 ? Math.round((sysTotal / totalBySystem) * 100) : 0;
                    const systemIssues = allTypes.map(type => {
                      const count = crossMap[type]?.[sys] || 0;
                      return { type, count };
                    }).filter(({ count }) => count > 0);
                    return (
                      <tr key={sys} className="hover:bg-slate-50">
                        <td className="px-4 py-3 font-medium text-gray-700 text-xs">{sys}</td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <div className="flex-1 h-3 bg-gray-100 rounded-full overflow-hidden">
                              <div
                                className="h-full rounded-full transition-all duration-700 bg-emerald-400"
                                style={{ width: `${Math.max(pct, 2)}%` }}
                              />
                            </div>
                            <span className="text-xs font-semibold text-gray-500 w-8 shrink-0 text-right">{pct}%</span>
                          </div>
                        </td>
                        {allTypes.map(type => {
                          const val = crossMap[type]?.[sys] || 0;
                          const color = getTypeColor(type);
                          return (
                            <td key={type} className="px-4 py-3 text-center">
                              {val > 0 ? (
                                <span
                                  className="inline-flex items-center justify-center min-w-[2rem] px-2 py-0.5 rounded-full text-xs font-bold"
                                  style={{ backgroundColor: `${color}18`, color }}
                                >
                                  {val}
                                </span>
                              ) : (
                                <span className="text-gray-300 text-xs">—</span>
                              )}
                            </td>
                          );
                        })}
                        <td className="px-4 py-3 text-center text-xs font-bold text-gray-700">{sysTotal}</td>
                        <td className="px-4 py-3 text-center">
                          {systemIssues.length > 0 && (
                            <button
                              onClick={async () => {
                                setModal({ system: sys, issues: [], isLoading: true });
                                try {
                                  const res = await jiraApi.getSystemIssues(Number(sprintId), sys);
                                  setModal({ system: sys, issues: res.issues || [], isLoading: false });
                                } catch {
                                  setModal({ system: sys, issues: [], isLoading: false, error: true });
                                }
                              }}
                              className="inline-flex items-center gap-1 text-xs font-semibold text-slate-400 hover:text-amber-700 hover:bg-amber-50 px-2.5 py-1 rounded-lg border border-gray-100 hover:border-amber-300 transition"
                            >
                              <span className="material-icons text-sm">assignment</span>
                              ดูรายละเอียด
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr className="bg-gray-50 border-t-2 border-gray-100 text-xs font-bold">
                    <td className="px-4 py-3 text-gray-600">รวม</td>
                    <td className="px-4 py-3 text-gray-400 font-normal">{totalBySystem} cards</td>
                    {allTypes.map(type => (
                      <td key={type} className="px-4 py-3 text-center" style={{ color: getTypeColor(type) }}>
                        {allSystems.reduce((s, sys) => s + (crossMap[type]?.[sys] || 0), 0)}
                      </td>
                    ))}
                    <td className="px-4 py-3 text-center">
                      <span className="inline-flex items-center justify-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-gray-800 text-white">{totalByType}</span>
                    </td>
                    <td />
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </>
      )}

      {/* Issue Detail Modal — live from Jira, styled like JiraDetailModal */}
      {modal && (() => {
        const done   = modal.issues.filter(i => i.statusCategory === 'done');
        const inprog = modal.issues.filter(i => i.statusCategory === 'indeterminate');
        const todo   = modal.issues.filter(i => i.statusCategory !== 'done' && i.statusCategory !== 'indeterminate');
        return (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={() => setModal(null)}>
            <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden border border-gray-100" onClick={e => e.stopPropagation()}>

              {/* Header */}
              <div className="px-6 py-4 flex justify-between items-center border-b border-gray-100">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-slate-700 text-white flex items-center justify-center text-sm font-bold shrink-0">
                    <span className="material-icons text-lg">folder</span>
                  </div>
                  <div>
                    <p className="font-bold text-gray-900 text-sm">{modal.system}</p>
                    <p className="text-xs text-gray-400">Work Distribution · {sprint?.name || ''}</p>
                  </div>
                </div>
                <button
                  onClick={() => setModal(null)}
                  className="text-gray-400 hover:text-gray-600 p-1.5 rounded-lg hover:bg-gray-100 transition cursor-pointer border-0 bg-transparent"
                >
                  <span className="material-icons text-xl">close</span>
                </button>
              </div>

              {modal.isLoading ? (
                <div className="flex flex-col items-center justify-center py-16 gap-3">
                  <span className="material-icons text-4xl text-gray-300 animate-spin">refresh</span>
                  <p className="text-sm text-gray-400">กำลังดึงข้อมูลจาก Jira...</p>
                </div>
              ) : modal.error ? (
                <div className="flex items-center justify-center gap-2 text-sm text-red-500 py-16">
                  <span className="material-icons text-base">error_outline</span>
                  ไม่สามารถดึงข้อมูลจาก Jira ได้
                </div>
              ) : (
                <>
                  {/* Summary stats */}
                  <div className="grid grid-cols-3 divide-x divide-gray-100 border-b border-gray-100 bg-gray-50">
                    <div className="px-6 py-4 text-center">
                      <p className="text-2xl font-bold text-gray-800">{modal.issues.length}</p>
                      <p className="text-sm text-gray-400 mt-1">งานทั้งหมด</p>
                    </div>
                    <div className="px-6 py-4 text-center">
                      <p className="text-2xl font-bold text-emerald-600">{done.length}</p>
                      <p className="text-sm text-gray-400 mt-1">เสร็จแล้ว</p>
                    </div>
                    <div className="px-6 py-4 text-center">
                      <p className="text-2xl font-bold text-amber-500">{inprog.length + todo.length}</p>
                      <p className="text-sm text-gray-400 mt-1">ค้างอยู่</p>
                    </div>
                  </div>

                  {/* Issue lists */}
                  <div className="p-6 space-y-6 max-h-[500px] overflow-y-auto">
                    {modal.issues.length === 0 ? (
                      <p className="text-base text-gray-400 italic text-center py-8">ไม่พบ Issues</p>
                    ) : (
                      <>
                        {/* Done */}
                        {done.length > 0 && (
                          <div>
                            <div className="flex items-center gap-2 mb-4">
                              <span className="w-3 h-3 rounded-full bg-emerald-500 shrink-0"></span>
                              <span className="text-sm font-bold text-gray-500 uppercase tracking-wider">เสร็จสมบูรณ์ ({done.length} cards)</span>
                            </div>
                            <div className="space-y-3">
                              {done.map(issue => (
                                <div
                                  key={issue.key}
                                  className="flex items-start justify-between gap-4 p-4 bg-white rounded-xl border border-gray-100 shadow-sm"
                                >
                                  <div className="flex items-start gap-3 min-w-0 flex-1">
                                    <span className="w-2 h-2 rounded-full bg-emerald-500 mt-2.5 shrink-0"></span>
                                    <div className="min-w-0 flex-1">
                                      <span className="text-xs font-bold text-gray-400 uppercase">{issue.key}</span>
                                      <p className="text-base text-gray-800 font-medium leading-snug mt-1">{issue.summary}</p>
                                    </div>
                                  </div>
                                  <span className="text-xs font-bold px-2.5 py-1 rounded-lg shrink-0" style={{ backgroundColor: `${getTypeColor(issue.issueType)}15`, color: getTypeColor(issue.issueType) }}>
                                    {issue.issueType}
                                  </span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* In Progress + Todo */}
                        {(inprog.length > 0 || todo.length > 0) && (
                          <div>
                            <div className="flex items-center gap-2 mb-4">
                              <span className="w-3 h-3 rounded-full bg-amber-400 shrink-0"></span>
                              <span className="text-sm font-bold text-gray-500 uppercase tracking-wider">ค้างอยู่ ({inprog.length + todo.length} cards)</span>
                            </div>
                            <div className="space-y-3">
                              {[...inprog, ...todo].map(issue => (
                                <div
                                  key={issue.key}
                                  className="flex items-start justify-between gap-4 p-4 bg-white rounded-xl border border-gray-100 shadow-sm"
                                >
                                  <div className="flex items-start gap-3 min-w-0 flex-1">
                                    <span className="w-2 h-2 rounded-full bg-amber-400 mt-2.5 shrink-0"></span>
                                    <div className="min-w-0 flex-1">
                                      <span className="text-xs font-bold text-gray-400 uppercase">{issue.key}</span>
                                      <p className="text-base text-gray-800 font-medium leading-snug mt-1">{issue.summary}</p>
                                    </div>
                                  </div>
                                  <span className="text-xs font-bold px-2.5 py-1 rounded-lg shrink-0" style={{ backgroundColor: `${getTypeColor(issue.issueType)}15`, color: getTypeColor(issue.issueType) }}>
                                    {issue.issueType}
                                  </span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                </>
              )}
            </div>
          </div>
        );
      })()}
    </div>
  );
};

export default SprintDistribution;
