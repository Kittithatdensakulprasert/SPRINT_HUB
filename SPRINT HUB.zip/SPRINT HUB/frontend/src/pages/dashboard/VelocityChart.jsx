/**
 * VelocityChart.jsx
 * คอมโพเนนต์ SVG สำหรับแสดงกราฟ Velocity เปรียบเทียบ target vs done ของแต่ละ sprint
 *
 * หน้าที่:
 * 1. รับ props `data` เป็น array ของ sprint ที่มี target/done/existing/new ทั้ง cards และ points
 * 2. รับ props `onSprintClick` (optional) เพื่อเปิดหน้ารายละเอียด sprint นั้น
 * 3. สลับมุมมองระหว่าง Cards กับ Points ด้วย Segmented Control
 * 4. แสดงกราฟ bar chart (target = สีเทา, done = สีเขียว/เหลือง/แดง ตาม %)
 * 5. แสดง trend line (เส้นประ) แสดง % สำเร็จ
 * 6. แสดงตารางสรุปด้านล่าง
 * 7. รองรับ tooltip เมื่อ hover บนกราฟ
 * 8. รองรับการสลับ “แสดง 6 ล่าสุด” หรือ “แสดงทั้งหมด”
 *
 * State สำคัญ:
 * - viewMode: 'cards' | 'points'
 * - showAll: แสดงทั้งหมดหรือแค่ 6 ล่าสุด
 * - tooltip: ข้อมูล hover บนกราฟ
 *
 * การคำนวณ:
 * - processedData: แปลง data ตาม viewMode ที่เลือก
 * - displayData: ถ้า showAll=false แสดงแค่ 6 sprint ล่าสุด
 * - maxVal: ค่าสูงสุดของกราฟ ปัดขึ้นเป็นหลักสิบ
 */

import React, { useState } from 'react';

const VelocityChart = ({ data, onSprintClick }) => {
  const [showAll, setShowAll] = useState(false);
  const [tooltip, setTooltip] = useState(null);
  const [viewMode, setViewMode] = useState('cards'); // 'cards' | 'points'

  if (!data || data.length === 0) {
    return (
      <div className="h-64 bg-slate-50 border-2 border-dashed border-gray-200 rounded-xl flex items-center justify-center">
        <div className="flex flex-col items-center gap-2 text-center">
          <span className="material-icons text-4xl text-gray-200">insert_chart</span>
          <p className="text-sm font-medium text-gray-400">Velocity Chart</p>
          <p className="text-xs text-gray-300">ยังไม่มีข้อมูล Sprint Results</p>
        </div>
      </div>
    );
  }

  // แปลงข้อมูลตาม viewMode
  const processedData = data.map(d => {
    if (viewMode === 'points') {
      // สมมติว่ามี story points ใน data (targetPoints, donePoints, existingPoints, newPoints)
      // ถ้ายังไม่มี ใช้ cards เป็น default
      return {
        ...d,
        target: d.targetPoints || d.target,
        done: d.donePoints || d.done,
        existing: d.existingPoints || d.existing,
        new: d.newPoints || d.new,
      };
    }
    return d; // cards mode
  });

  // โชว์ทั้งหมดหรือแค่ 10 ล่าสุดตามที่เลือก
  const displayData = showAll ? processedData : processedData.slice(-10);

  const chartH = 220;
  const groupW = 70;        // ความกว้างต่อ sprint
  const barW = 22;          // ความกว้างแท่ง
  const leftPad = 50;
  const rightPad = 20;
  const chartW = Math.max(400, displayData.length * groupW + leftPad + rightPad);

  const rawMax = Math.max(...displayData.flatMap(d => [d.target, d.done]), 1);
  const maxVal = Math.ceil(rawMax / 10) * 10; // ปัดขึ้นเป็น 10
  const yTicks = [0, maxVal * 0.25, maxVal * 0.5, maxVal * 0.75, maxVal].map(v => Math.round(v));

  const toY = (val) => chartH - (val / maxVal) * chartH * 0.85;
  const toPctY = (pct) => chartH - (pct / 100) * chartH * 0.85;

  const avgPct = Math.round(processedData.reduce((sum, d) => sum + (d.target > 0 ? (d.done / d.target) * 100 : 0), 0) / processedData.length);

  const displayName = (name) => {
    const m = name.match(/(\d{2,4})$/);
    return m ? m[1] : name.slice(0, 8);
  };

  return (
    <div className="space-y-4">
      {/* Header + toggle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5">
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-sm bg-slate-300" />
              <span className="text-xs text-gray-500">งานเก่า (Existing)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-sm bg-sky-400" />
              <span className="text-xs text-gray-500">งานใหม่ (New)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-1 bg-blue-400 rounded" />
              <span className="text-xs text-gray-500">% ความสำเร็จ</span>
            </div>
            <div className="w-px h-3 bg-gray-400" />
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-sm bg-emerald-400" />
              <span className="text-xs text-gray-500">สำเร็จตามเป้าหมาย ≥ 100%</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-sm bg-amber-400" />
              <span className="text-xs text-gray-500">ต่ำกว่าเป้าหมาย ≥ 50%</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-sm bg-red-400" />
              <span className="text-xs text-gray-500">ต่ำกว่าเป้าหมาย 50%</span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center bg-gray-200/70 rounded-full p-1">
            <button
              onClick={() => setViewMode('cards')}
              className={`px-5 py-1.5 text-xs font-semibold rounded-full transition-all duration-200 ${
                viewMode === 'cards'
                  ? 'bg-gray-800 text-white shadow-sm'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >Cards</button>
            <button
              onClick={() => setViewMode('points')}
              className={`px-5 py-1.5 text-xs font-semibold rounded-full transition-all duration-200 ${
                viewMode === 'points'
                  ? 'bg-gray-800 text-white shadow-sm'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >Points</button>
          </div>
          {data.length > 10 && (
            <button
              onClick={() => setShowAll(!showAll)}
              className="text-xs font-semibold text-slate-500 hover:text-blue-700 bg-white border border-gray-200 hover:border-blue-300 rounded-lg px-3 py-1.5 transition cursor-pointer whitespace-nowrap flex-shrink-0"
            >
              {showAll ? 'แสดง 10 ล่าสุด' : `แสดงทั้งหมด (${data.length})`}
            </button>
          )}
        </div>
      </div>

      {/* Chart */}
      <div className="w-full overflow-x-auto pb-2">
        <div style={{ minWidth: `${chartW}px` }}>
          <svg viewBox={`0 0 ${chartW} ${chartH + 55}`} className="w-full" style={{ minHeight: '260px' }}>
            {/* Y axis grid + labels */}
            {yTicks.map((tick, i) => {
              const y = toY(tick) + 10;
              return (
                <g key={i}>
                  <line x1={leftPad} y1={y} x2={chartW - rightPad} y2={y} stroke="#f0f0f0" strokeWidth="1" />
                  <text x={leftPad - 8} y={y + 4} textAnchor="end" fontSize="10" fill="#9ca3af">{tick}</text>
                </g>
              );
            })}

            {/* X axis */}
            <line x1={leftPad} y1={chartH + 10} x2={chartW - rightPad} y2={chartH + 10} stroke="#e5e7eb" strokeWidth="1" />

            <text
              x={chartW - rightPad + 15}
              y={chartH + 24}
              textAnchor="end"
              fontSize="8"
              fontWeight="600"
              fill="#6b7280"
            >
              sprint
            </text>

            <text
              x={leftPad - 8}
              y={14}
              textAnchor="end"
              fontSize="8"
              fontWeight="600"
              fill="#6b7280"
            >
              cards
            </text>

            {/* clipPath defs — มุมมนบนสุดของแต่ละ bar */}
            <defs>
              {displayData.map((d, i) => {
                const x = leftPad + i * groupW + (groupW - 2 * barW - 4) / 2;
                const targetH = chartH * 0.85 * (d.target / maxVal);
                const doneH   = chartH * 0.85 * (d.done / maxVal);
                const barTop  = toY(d.target) + 10;
                const doneTop = toY(d.done) + 10;
                return (
                  <g key={i}>
                    <clipPath id={`clip-vel-target-${i}`}>
                      <rect x={x} y={barTop} width={barW} height={targetH} rx="3" />
                    </clipPath>
                    <clipPath id={`clip-vel-done-${i}`}>
                      <rect x={x + barW + 4} y={doneTop} width={barW} height={doneH} rx="3" />
                    </clipPath>
                  </g>
                );
              })}
            </defs>

            {/* Bars + labels */}
            {displayData.map((d, i) => {
              const x = leftPad + i * groupW + (groupW - 2 * barW - 4) / 2;
              const targetH = chartH * 0.85 * (d.target / maxVal);
              const doneH = chartH * 0.85 * (d.done / maxVal);
              const pct = d.target > 0 ? Math.round((d.done / d.target) * 100) : 0;
              const lineY = toPctY(pct) + 10;
              const color = pct >= 100 ? '#34d399' : pct >= 60 ? '#fbbf24' : '#f87171';

              const existing = Number(d.existing || 0);
              const newPts = Number(d.new || 0);
              const splitTotal = existing + newPts > 0 ? existing + newPts : (existing > 0 ? existing : d.target);
              const existingH = splitTotal > 0 ? targetH * (existing / splitTotal) : targetH;
              const newH = splitTotal > 0 ? targetH * (newPts / splitTotal) : 0;
              const barTop = toY(d.target) + 10;
              const existingY = barTop + newH;
              const newY = barTop;

              const isClickable = onSprintClick && d.id;

              const unit = viewMode === 'points' ? 'pts' : 'cards';
              const showBarTooltip = (e) => {
                setTooltip({
                  x: e.clientX + window.scrollX,
                  y: e.clientY - 12 + window.scrollY,
                  lines: [
                    d.name,
                    `เป้าหมาย: ${d.target} ${unit}`,
                    ...(existing > 0 ? [`งานเก่า: ${existing} ${unit}`] : []),
                    ...(newPts > 0  ? [`งานใหม่: ${newPts} ${unit}`]  : []),
                    `เสร็จ: ${d.done} ${unit} (${pct}%)`,
                  ],
                });
              };
              const moveBarTooltip = (e) => {
                setTooltip(prev => prev ? { ...prev, x: e.clientX + window.scrollX, y: e.clientY - 12 + window.scrollY } : null);
              };
              const hideBarTooltip = () => setTooltip(null);

              return (
                <g key={i}
                  onMouseEnter={showBarTooltip}
                  onMouseMove={moveBarTooltip}
                  onMouseLeave={hideBarTooltip}
                  onClick={() => isClickable && onSprintClick(d.id)}
                  className={isClickable ? 'cursor-pointer group' : ''}
                >
                  {/* Target bar — ครอบด้วย clipPath ให้มุมบนมนทั้งก้อน */}
                  <g clipPath={`url(#clip-vel-target-${i})`}>
                    <rect x={x} y={existingY} width={barW} height={existingH} fill="#cbd5e1" />
                    {newH > 0 && <rect x={x} y={newY} width={barW} height={newH} fill="#38bdf8" />}
                  </g>
                  {/* Done bar */}
                  <g clipPath={`url(#clip-vel-done-${i})`}>
                    <rect x={x + barW + 4} y={toY(d.done) + 10} width={barW} height={doneH} fill={color} />
                  </g>
                  {existingH > 12 && existing > 0 && (
                    <text x={x + barW / 2} y={existingY + existingH / 2 + 4} textAnchor="middle" fontSize="10" fill="#475569" fontWeight="700">{existing}</text>
                  )}
                  {newH > 12 && newPts > 0 && (
                    <text x={x + barW / 2} y={newY + newH / 2 + 4} textAnchor="middle" fontSize="10" fill="#ffffff" fontWeight="700">{newPts}</text>
                  )}
                  {d.done > 0 && (
                    <text x={x + barW + 4 + barW / 2} y={toY(d.done) + 6} textAnchor="middle" fontSize="9" fill="#4b5563" fontWeight="600">
                      {d.done}
                    </text>
                  )}

                  <circle cx={x + barW + 4 + barW / 2} cy={lineY} r="3" fill="#3b82f6" />

                  <text
                    x={x + barW + 2} y={chartH + 24} textAnchor="middle" fontSize="9"
                    className={`${isClickable ? 'fill-black group-hover:fill-blue-600' : 'fill-gray-500'}`}
                    fontWeight={isClickable ? '700' : '400'}
                  >
                    {displayName(d.name)}
                    {isClickable && <title>คลิกเพื่อดูรายละเอียด {d.name}</title>}
                  </text>
                  <text x={x + barW + 4 + barW / 2} y={chartH + 40} textAnchor="middle" fontSize="9"
                    fill={pct >= 100 ? '#059669' : pct >= 60 ? '#d97706' : '#dc2626'} fontWeight="700">
                    {pct}%
                  </text>
                </g>
              );
            })}

            {/* % line connecting dots */}
            {displayData.length > 1 && (
              <polyline
                fill="none" stroke="#3b82f6" strokeWidth="1.5" strokeDasharray="4 2"
                points={displayData.map((d, i) => {
                  const x = leftPad + i * groupW + (groupW - 2 * barW - 4) / 2 + barW + 4 + barW / 2;
                  const pct = d.target > 0 ? (d.done / d.target) * 100 : 0;
                  const y = toPctY(pct) + 10;
                  return `${x},${y}`;
                }).join(' ')}
              />
            )}
          </svg>
        </div>
      </div>

      {tooltip && (
        <div
          className="fixed z-50 pointer-events-none bg-gray-800 text-white text-xs rounded-lg px-3 py-2 shadow-lg"
          style={{ left: tooltip.x, top: tooltip.y, transform: 'translate(-50%, -100%)' }}
        >
          {tooltip.lines?.map((l, i) => (
            <div key={i} className={i === 0 ? 'font-semibold mb-1' : i === tooltip.lines.length - 1 ? 'mt-1 font-bold border-t border-gray-600 pt-1' : 'text-gray-300'}>{l}</div>
          ))}
        </div>
      )}

      {/* Summary stats */}
      <div className="grid grid-cols-2 gap-3 bg-gray-50 rounded-xl p-4 border border-gray-100">
        <div className="text-center">
          <p className="text-xs text-gray-400">Sprints ทั้งหมด</p>
          <p className="text-lg font-bold text-gray-700">{data.length}</p>
        </div>
        <div className="text-center">
          <p className="text-xs text-gray-400">% สำเร็จเฉลี่ย</p>
          <p className={`text-lg font-bold ${avgPct >= 100 ? 'text-emerald-600' : avgPct >= 60 ? 'text-amber-600' : 'text-red-500'}`}>{avgPct}%</p>
        </div>
      </div>

      {/* Data table */}
      <div className="relative overflow-x-auto rounded-xl border border-gray-100">
        <table className="w-full text-sm text-left">
          <thead className="bg-gray-50 text-xs font-semibold text-gray-500 sticky top-0 z-10">
            <tr>
              <th className="px-4 py-3">Sprint</th>
              <th className="px-4 py-3 text-center">เป้าหมาย ({viewMode === 'points' ? 'pts' : 'cards'})</th>
              <th className="px-4 py-3 text-center">เสร็จแล้ว ({viewMode === 'points' ? 'pts' : 'cards'})</th>
              <th className="px-4 py-3 text-center">ค้าง ({viewMode === 'points' ? 'pts' : 'cards'})</th>
              <th className="px-4 py-3 text-center">% สำเร็จ</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {[...displayData].reverse().map((d, i) => {
              const target = viewMode === 'points' ? (d.targetPoints || 0) : (d.target || 0);
              const done = viewMode === 'points' ? (d.donePoints || 0) : (d.done || 0);
              const pct = target > 0 ? Math.round((done / target) * 100) : 0;
              const remaining = target - done;
              const isClickable = onSprintClick && d.id;
              return (
                <tr
                  key={i}
                  className={`hover:bg-slate-50 ${isClickable ? 'cursor-pointer group' : ''}`}
                  onClick={() => isClickable && onSprintClick(d.id)}
                  title={isClickable ? `คลิกเพื่อดูรายละเอียด ${d.name}` : ''}
                >
                  <td className="px-4 py-3 font-medium text-gray-800">
                    <span className={`inline-flex items-center gap-1 ${isClickable ? 'text-black group-hover:text-blue-600' : ''}`}>
                      {d.name}
                      {isClickable && <span className="material-icons text-sm text-black group-hover:text-blue-600">open_in_new</span>}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-center text-gray-600">{target} {viewMode === 'points' ? 'pts' : 'cards'}</td>
                  <td className="px-4 py-3 text-center font-semibold text-emerald-600">{done} {viewMode === 'points' ? 'pts' : 'cards'}</td>
                  <td className="px-4 py-3 text-center font-semibold text-amber-600">{remaining > 0 ? `${remaining} ${viewMode === 'points' ? 'pts' : 'cards'}` : '—'}</td>
                  <td className="px-4 py-3 text-center">
                    <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-bold ${pct >= 100 ? 'bg-emerald-100 text-emerald-700' : pct >= 60 ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-700'}`}>
                      {pct}%
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default VelocityChart;
