import React from 'react';

const VelocityChart = ({ data }) => {
  if (!data || data.length === 0) {
    return (
      <div className="h-64 bg-slate-50 border-2 border-dashed border-gray-200 rounded-xl flex items-center justify-center">
        <div className="flex flex-col items-center gap-2 text-center">
          <span className="material-icons text-4xl text-gray-200">insert_chart</span>
          <p className="text-sm font-medium text-gray-400">Velocity Chart</p>
          <p className="text-xs text-gray-300">ยังไม่มีข้อมูล Sprint Results</p>
        </div>
      </div>
    );
  }

  const maxVal = Math.max(...data.flatMap(d => [d.target, d.done]), 1);
  const chartH = 200;
  const chartW = 600;
  const barW = Math.min(40, (chartW / data.length) * 0.35);
  const gap = chartW / data.length;
  const pad = gap * 0.15;

  const toY = (val) => chartH - (val / maxVal) * chartH * 0.9;

  const yTicks = [0, 0.25, 0.5, 0.75, 1].map(f => Math.round(maxVal * f));

  return (
    <div className="w-full overflow-x-auto">
      <div className="min-w-[500px]">
        {/* Legend */}
        <div className="flex items-center gap-4 mb-3">
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded-sm bg-slate-300" />
            <span className="text-xs text-gray-500">Target Pts</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded-sm bg-yellow-400" />
            <span className="text-xs text-gray-500">Done Pts</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-1 bg-blue-400 rounded" />
            <span className="text-xs text-gray-500">% สำเร็จ</span>
          </div>
        </div>

        <svg viewBox={`0 0 ${chartW + 60} ${chartH + 60}`} className="w-full">
          {/* Y axis grid + labels */}
          {yTicks.map((tick, i) => {
            const y = toY(tick) + 10;
            return (
              <g key={i}>
                <line x1="50" y1={y} x2={chartW + 50} y2={y} stroke="#f0f0f0" strokeWidth="1" />
                <text x="44" y={y + 4} textAnchor="end" fontSize="10" fill="#aaa">{tick}</text>
              </g>
            );
          })}

          {/* Bars */}
          {data.map((d, i) => {
            const x = 50 + i * gap + pad;
            const targetH = chartH * 0.9 * (d.target / maxVal);
            const doneH = chartH * 0.9 * (d.done / maxVal);
            const pct = d.target > 0 ? Math.round((d.done / d.target) * 100) : 0;
            const lineY = toY(d.done) + 10;

            return (
              <g key={i}>
                {/* Target bar */}
                <rect
                  x={x} y={toY(d.target) + 10}
                  width={barW} height={targetH}
                  rx="3" fill="#e2e8f0"
                />
                {/* Done bar */}
                <rect
                  x={x + barW + 3} y={toY(d.done) + 10}
                  width={barW} height={doneH}
                  rx="3" fill={pct >= 100 ? '#34d399' : pct >= 60 ? '#fbbf24' : '#f87171'}
                />
                {/* Done pts label */}
                {d.done > 0 && (
                  <text x={x + barW + 3 + barW / 2} y={toY(d.done) + 6} textAnchor="middle" fontSize="9" fill="#555" fontWeight="600">
                    {d.done}
                  </text>
                )}
                {/* % line dot */}
                <circle cx={x + barW + 3 + barW / 2} cy={lineY} r="3" fill="#60a5fa" />
                {/* Sprint label */}
                <text
                  x={x + barW + 1} y={chartH + 24}
                  textAnchor="middle" fontSize="9" fill="#666"
                  transform={`rotate(-30, ${x + barW + 1}, ${chartH + 24})`}
                >
                  {d.name.length > 14 ? d.name.slice(-10) : d.name}
                </text>
                {/* % badge */}
                <text x={x + barW + 3 + barW / 2} y={chartH + 42} textAnchor="middle" fontSize="9"
                  fill={pct >= 100 ? '#059669' : pct >= 60 ? '#d97706' : '#dc2626'} fontWeight="700">
                  {pct}%
                </text>
              </g>
            );
          })}

          {/* % line connecting dots */}
          {data.length > 1 && (
            <polyline
              fill="none" stroke="#93c5fd" strokeWidth="1.5" strokeDasharray="4 2"
              points={data.map((d, i) => {
                const x = 50 + i * gap + pad + barW + 3 + barW / 2;
                const y = toY(d.done) + 10;
                return `${x},${y}`;
              }).join(' ')}
            />
          )}

          {/* X axis */}
          <line x1="50" y1={chartH + 10} x2={chartW + 50} y2={chartH + 10} stroke="#e5e7eb" strokeWidth="1" />
        </svg>
      </div>
    </div>
  );
};

export default VelocityChart;
