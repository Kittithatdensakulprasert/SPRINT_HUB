import React, { useState } from 'react';

const VelocityChart = ({ data, onSprintClick }) => {
  const [showAll, setShowAll] = useState(false);
  const [tooltip, setTooltip] = useState(null);

  if (!data || data.length === 0) {
    return (
      <div className="h-64 bg-slate-50 border-2 border-dashed border-gray-200 rounded-xl flex items-center justify-center">
        <div className="flex flex-col items-center gap-2 text-center">
          <span className="material-icons text-4xl text-gray-200">insert_chart</span>
          <p className="text-sm font-medium text-gray-400">Velocity Chart</p>
          <p className="text-xs text-gray-300">ยังไม่มีข้อมูล Sprint Results</p>
        </div>
      </div>
    );
  }

  // โชว์ทั้งหมดหรือแค่ 10 ล่าสุดตามที่เลือก
  const displayData = showAll ? data : data.slice(-10);

  const chartH = 220;
  const groupW = 70;        // ความกว้างต่อ sprint
  const barW = 22;          // ความกว้างแท่ง
  const leftPad = 50;
  const rightPad = 20;
  const chartW = Math.max(400, displayData.length * groupW + leftPad + rightPad);

  const rawMax = Math.max(...displayData.flatMap(d => [d.target, d.done]), 1);
  const maxVal = Math.ceil(rawMax / 10) * 10; // ปัดขึ้นเป็น 10
  const yTicks = [0, maxVal * 0.25, maxVal * 0.5, maxVal * 0.75, maxVal].map(v => Math.round(v));

  const toY = (val) => chartH - (val / maxVal) * chartH * 0.85;
  const toPctY = (pct) => chartH - (pct / 100) * chartH * 0.85;

  const avgPct = Math.round(data.reduce((sum, d) => sum + (d.target > 0 ? (d.done / d.target) * 100 : 0), 0) / data.length);

  const displayName = (name) => {
    const m = name.match(/(\d{2,4})$/);
    return m ? m[1] : name.slice(0, 8);
  };

  return (
    <div className="space-y-4">
      {/* Header + toggle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5">
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-sm bg-slate-300" />
              <span className="text-xs text-gray-500">งานเก่า (Existing)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-sm bg-sky-400" />
              <span className="text-xs text-gray-500">งานใหม่ (New)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-1 bg-blue-400 rounded" />
              <span className="text-xs text-gray-500">% ความสำเร็จ</span>
            </div>
            <div className="w-px h-3 bg-gray-400" />
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-sm bg-emerald-400" />
              <span className="text-xs text-gray-500">สำเร็จตามเป้าหมาย ≥ 100%</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-sm bg-amber-400" />
              <span className="text-xs text-gray-500">ต่ำกว่าเป้าหมาย ≥ 50%</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-sm bg-red-400" />
              <span className="text-xs text-gray-500">ต่ำกว่าเป้าหมาย 50%</span>
            </div>
          </div>
        </div>
        {data.length > 10 && (
          <button
            onClick={() => setShowAll(!showAll)}
            className="text-xs font-semibold text-slate-500 hover:text-amber-700 bg-white border border-gray-200 hover:border-amber-300 rounded-lg px-3 py-1.5 transition cursor-pointer"
          >
            {showAll ? 'แสดง 10 ล่าสุด' : `แสดงทั้งหมด (${data.length})`}
          </button>
        )}
      </div>

      {/* Chart */}
      <div className="w-full overflow-x-auto pb-2">
        <div style={{ minWidth: `${chartW}px` }}>
          <svg viewBox={`0 0 ${chartW} ${chartH + 55}`} className="w-full" style={{ minHeight: '260px' }}>
            {/* Y axis grid + labels */}
            {yTicks.map((tick, i) => {
              const y = toY(tick) + 10;
              return (
                <g key={i}>
                  <line x1={leftPad} y1={y} x2={chartW - rightPad} y2={y} stroke="#f0f0f0" strokeWidth="1" />
                  <text x={leftPad - 8} y={y + 4} textAnchor="end" fontSize="10" fill="#9ca3af">{tick}</text>
                </g>
              );
            })}

            {/* X axis */}
            <line x1={leftPad} y1={chartH + 10} x2={chartW - rightPad} y2={chartH + 10} stroke="#e5e7eb" strokeWidth="1" />

            <text
              x={rightPad + 750}
              y={chartH + 24}
              textAnchor="end"
              fontSize="8"
              fontWeight="600"
              fill="#6b7280"
            >
              sprint
            </text>
            
            <text
              x={leftPad}
              y={25}
              textAnchor="end"
              fontSize="8"
              fontWeight="600"
              fill="#6b7280"
            >
              ความสำเร็จ
            </text>

            {/* Bars + labels */}
            {displayData.map((d, i) => {
              const x = leftPad + i * groupW + (groupW - 2 * barW - 4) / 2;
              const targetH = chartH * 0.85 * (d.target / maxVal);
              const doneH = chartH * 0.85 * (d.done / maxVal);
              const pct = d.target > 0 ? Math.round((d.done / d.target) * 100) : 0;
              const lineY = toPctY(pct) + 10;
              const color = pct >= 100 ? '#34d399' : pct >= 60 ? '#fbbf24' : '#f87171';

              const existing = Number(d.existing || 0);
              const newPts = Number(d.new || 0);
              const splitTotal = existing + newPts > 0 ? existing + newPts : (existing > 0 ? existing : d.target);
              const existingH = splitTotal > 0 ? targetH * (existing / splitTotal) : targetH;
              const newH = splitTotal > 0 ? targetH * (newPts / splitTotal) : 0;
              const barTop = toY(d.target) + 10;
              const existingY = barTop + newH;
              const newY = barTop;

              const isClickable = onSprintClick && d.id;

              const showBarTooltip = (e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                setTooltip({
                  x: rect.left + rect.width / 2 + window.scrollX,
                  y: rect.top - 12 + window.scrollY,
                  text: `งานเก่า: ${existing || d.target} cards | งานใหม่: ${newPts} cards`,
                });
              };
              const moveBarTooltip = (e) => {
                setTooltip(prev => prev ? { ...prev, x: e.clientX + window.scrollX, y: e.clientY - 12 + window.scrollY } : null);
              };
              const hideBarTooltip = () => setTooltip(null);

              return (
                <g key={i}
                  onMouseEnter={showBarTooltip}
                  onMouseMove={moveBarTooltip}
                  onMouseLeave={hideBarTooltip}
                  className="cursor-pointer"
                >
                  <rect x={x} y={existingY} width={barW} height={existingH} rx={newH > 0 ? "0" : "3"} fill="#cbd5e1" />
                  {newH > 0 && (
                    <rect x={x} y={newY} width={barW} height={newH} rx="3" fill="#38bdf8" />
                  )}
                  {existingH > 12 && existing > 0 && (
                    <text x={x + barW / 2} y={existingY + existingH / 2 + 4} textAnchor="middle" fontSize="10" fill="#475569" fontWeight="700">{existing}</text>
                  )}
                  {newH > 12 && newPts > 0 && (
                    <text x={x + barW / 2} y={newY + newH / 2 + 4} textAnchor="middle" fontSize="10" fill="#ffffff" fontWeight="700">{newPts}</text>
                  )}
                  <rect x={x + barW + 4} y={toY(d.done) + 10} width={barW} height={doneH} rx="3" fill={color} />

                  {d.done > 0 && (
                    <text x={x + barW + 4 + barW / 2} y={toY(d.done) + 6} textAnchor="middle" fontSize="9" fill="#4b5563" fontWeight="600">
                      {d.done}
                    </text>
                  )}

                  <circle cx={x + barW + 4 + barW / 2} cy={lineY} r="3" fill="#3b82f6" />

                  <text
                    x={x + barW + 2} y={chartH + 24} textAnchor="middle" fontSize="9"
                    className={`${isClickable ? 'fill-black hover:fill-amber-600 cursor-pointer' : 'fill-gray-500'}`}
                    fontWeight={isClickable ? '700' : '400'}
                    onClick={() => isClickable && onSprintClick(d.id)}
                  >
                    {displayName(d.name)}
                    {isClickable && <title>คลิกเพื่อดูรายละเอียด {d.name}</title>}
                  </text>
                  <text x={x + barW + 4 + barW / 2} y={chartH + 40} textAnchor="middle" fontSize="9"
                    fill={pct >= 100 ? '#059669' : pct >= 60 ? '#d97706' : '#dc2626'} fontWeight="700">
                    {pct}%
                  </text>
                </g>
              );
            })}

            {/* % line connecting dots */}
            {displayData.length > 1 && (
              <polyline
                fill="none" stroke="#3b82f6" strokeWidth="1.5" strokeDasharray="4 2"
                points={displayData.map((d, i) => {
                  const x = leftPad + i * groupW + (groupW - 2 * barW - 4) / 2 + barW + 4 + barW / 2;
                  const pct = d.target > 0 ? (d.done / d.target) * 100 : 0;
                  const y = toPctY(pct) + 10;
                  return `${x},${y}`;
                }).join(' ')}
              />
            )}
          </svg>
        </div>
      </div>

      {tooltip && (
        <div
          className="fixed z-50 pointer-events-none bg-gray-900 text-white text-xs rounded-lg px-2.5 py-1.5 shadow-lg whitespace-nowrap"
          style={{ left: tooltip.x, top: tooltip.y, transform: 'translate(-50%, -100%)' }}
        >
          {tooltip.text}
          <div className="absolute left-1/2 top-full -translate-x-1/2 border-4 border-transparent border-t-gray-900" />
        </div>
      )}

      {/* Summary stats */}
      <div className="grid grid-cols-2 gap-3 bg-gray-50 rounded-xl p-4 border border-gray-100">
        <div className="text-center">
          <p className="text-xs text-gray-400">Sprints ทั้งหมด</p>
          <p className="text-lg font-bold text-gray-700">{data.length}</p>
        </div>
        <div className="text-center">
          <p className="text-xs text-gray-400">% สำเร็จเฉลี่ย</p>
          <p className={`text-lg font-bold ${avgPct >= 100 ? 'text-emerald-600' : avgPct >= 60 ? 'text-amber-600' : 'text-red-500'}`}>{avgPct}%</p>
        </div>
      </div>

      {/* Data table */}
      <div className="relative overflow-x-auto rounded-xl border border-gray-100">
        <table className="w-full text-sm text-left">
          <thead className="bg-gray-50 text-xs font-semibold text-gray-500 sticky top-0 z-10">
            <tr>
              <th className="px-4 py-3">Sprint</th>
              <th className="px-4 py-3 text-center">เป้าหมาย</th>
              <th className="px-4 py-3 text-center">เสร็จแล้ว</th>
              <th className="px-4 py-3 text-center">ค้าง</th>
              <th className="px-4 py-3 text-center">% สำเร็จ</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {[...displayData].reverse().map((d, i) => {
              const pct = d.target > 0 ? Math.round((d.done / d.target) * 100) : 0;
              const remaining = d.target - d.done;
              const isClickable = onSprintClick && d.id;
              return (
                <tr
                  key={i}
                  className={`hover:bg-slate-50 ${isClickable ? 'cursor-pointer group' : ''}`}
                  onClick={() => isClickable && onSprintClick(d.id)}
                  title={isClickable ? `คลิกเพื่อดูรายละเอียด ${d.name}` : ''}
                >
                  <td className="px-4 py-3 font-medium text-gray-800">
                    <span className={`inline-flex items-center gap-1 ${isClickable ? 'text-black group-hover:text-amber-600' : ''}`}>
                      {d.name}
                      {isClickable && <span className="material-icons text-sm text-black group-hover:text-amber-600">open_in_new</span>}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-center text-gray-600">{d.target} cards</td>
                  <td className="px-4 py-3 text-center font-semibold text-emerald-600">{d.done} cards</td>
                  <td className="px-4 py-3 text-center font-semibold text-amber-600">{remaining > 0 ? `${remaining} cards` : '—'}</td>
                  <td className="px-4 py-3 text-center">
                    <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-bold ${pct >= 100 ? 'bg-emerald-100 text-emerald-700' : pct >= 60 ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-700'}`}>
                      {pct}%
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default VelocityChart;
