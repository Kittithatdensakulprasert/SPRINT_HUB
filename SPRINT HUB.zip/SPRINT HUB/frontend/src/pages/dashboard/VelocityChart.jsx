import React, { useState } from 'react';

const VelocityChart = ({ data }) => {
  const [showAll, setShowAll] = useState(false);

  if (!data || data.length === 0) {
    return (
      <div className="h-64 bg-slate-50 border-2 border-dashed border-gray-200 rounded-xl flex items-center justify-center">
        <div className="flex flex-col items-center gap-2 text-center">
          <span className="material-icons text-4xl text-gray-200">insert_chart</span>
          <p className="text-sm font-medium text-gray-400">Velocity Chart</p>
          <p className="text-xs text-gray-300">ยังไม่มีข้อมูล Sprint Results</p>
        </div>
      </div>
    );
  }

  // โชว์ทั้งหมดหรือแค่ 12 ล่าสุดตามที่เลือก
  const displayData = showAll ? data : data.slice(-12);

  const chartH = 220;
  const groupW = 70;        // ความกว้างต่อ sprint
  const barW = 22;          // ความกว้างแท่ง
  const leftPad = 40;
  const rightPad = 20;
  const chartW = Math.max(400, displayData.length * groupW + leftPad + rightPad);

  const rawMax = Math.max(...displayData.flatMap(d => [d.target, d.done]), 1);
  const maxVal = Math.ceil(rawMax / 10) * 10; // ปัดขึ้นเป็น 10
  const yTicks = [0, maxVal * 0.25, maxVal * 0.5, maxVal * 0.75, maxVal].map(v => Math.round(v));

  const toY = (val) => chartH - (val / maxVal) * chartH * 0.85;
  const toPctY = (pct) => chartH - (pct / 100) * chartH * 0.85;

  const avgPct = Math.round(data.reduce((sum, d) => sum + (d.target > 0 ? (d.done / d.target) * 100 : 0), 0) / data.length);

  const displayName = (name) => {
    const m = name.match(/(\d{2,4})$/);
    return m ? m[1] : name.slice(0, 8);
  };

  return (
    <div className="space-y-4">
      {/* Header + toggle */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded-sm bg-slate-300" />
            <span className="text-xs text-gray-500">เป้าหมาย (Target)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded-sm bg-emerald-400" />
            <span className="text-xs text-gray-500">เสร็จแล้ว (Done)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-1 bg-blue-400 rounded" />
            <span className="text-xs text-gray-500">% ความสำเร็จ</span>
          </div>
        </div>
        {data.length > 12 && (
          <button
            onClick={() => setShowAll(!showAll)}
            className="text-xs font-semibold text-slate-500 hover:text-amber-700 bg-white border border-gray-200 hover:border-amber-300 rounded-lg px-3 py-1.5 transition cursor-pointer"
          >
            {showAll ? 'แสดง 12 ล่าสุด' : `แสดงทั้งหมด (${data.length})`}
          </button>
        )}
      </div>

      {/* Chart */}
      <div className="w-full overflow-x-auto pb-2">
        <div style={{ minWidth: `${chartW}px` }}>
          <svg viewBox={`0 0 ${chartW} ${chartH + 55}`} className="w-full" style={{ minHeight: '260px' }}>
            {/* Y axis grid + labels */}
            {yTicks.map((tick, i) => {
              const y = toY(tick) + 10;
              return (
                <g key={i}>
                  <line x1={leftPad} y1={y} x2={chartW - rightPad} y2={y} stroke="#f0f0f0" strokeWidth="1" />
                  <text x={leftPad - 8} y={y + 4} textAnchor="end" fontSize="10" fill="#9ca3af">{tick}</text>
                </g>
              );
            })}

            {/* X axis */}
            <line x1={leftPad} y1={chartH + 10} x2={chartW - rightPad} y2={chartH + 10} stroke="#e5e7eb" strokeWidth="1" />

            {/* Bars + labels */}
            {displayData.map((d, i) => {
              const x = leftPad + i * groupW + (groupW - 2 * barW - 4) / 2;
              const targetH = chartH * 0.85 * (d.target / maxVal);
              const doneH = chartH * 0.85 * (d.done / maxVal);
              const pct = d.target > 0 ? Math.round((d.done / d.target) * 100) : 0;
              const lineY = toPctY(pct) + 10;
              const color = pct >= 100 ? '#34d399' : pct >= 60 ? '#fbbf24' : '#f87171';

              return (
                <g key={i}>
                  <rect x={x} y={toY(d.target) + 10} width={barW} height={targetH} rx="3" fill="#e2e8f0" />
                  <rect x={x + barW + 4} y={toY(d.done) + 10} width={barW} height={doneH} rx="3" fill={color} />

                  {d.done > 0 && (
                    <text x={x + barW + 4 + barW / 2} y={toY(d.done) + 6} textAnchor="middle" fontSize="9" fill="#4b5563" fontWeight="600">
                      {d.done}
                    </text>
                  )}

                  <circle cx={x + barW + 4 + barW / 2} cy={lineY} r="3" fill="#3b82f6" />

                  <text x={x + barW + 2} y={chartH + 24} textAnchor="middle" fontSize="9" fill="#6b7280">
                    {displayName(d.name)}
                  </text>
                  <text x={x + barW + 4 + barW / 2} y={chartH + 40} textAnchor="middle" fontSize="9"
                    fill={pct >= 100 ? '#059669' : pct >= 60 ? '#d97706' : '#dc2626'} fontWeight="700">
                    {pct}%
                  </text>
                </g>
              );
            })}

            {/* % line connecting dots */}
            {displayData.length > 1 && (
              <polyline
                fill="none" stroke="#3b82f6" strokeWidth="1.5" strokeDasharray="4 2"
                points={displayData.map((d, i) => {
                  const x = leftPad + i * groupW + (groupW - 2 * barW - 4) / 2 + barW + 4 + barW / 2;
                  const pct = d.target > 0 ? (d.done / d.target) * 100 : 0;
                  const y = toPctY(pct) + 10;
                  return `${x},${y}`;
                }).join(' ')}
              />
            )}
          </svg>
        </div>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-2 gap-3 bg-gray-50 rounded-xl p-4 border border-gray-100">
        <div className="text-center">
          <p className="text-xs text-gray-400">Sprints ทั้งหมด</p>
          <p className="text-lg font-bold text-gray-700">{data.length}</p>
        </div>
        <div className="text-center">
          <p className="text-xs text-gray-400">% สำเร็จเฉลี่ย</p>
          <p className={`text-lg font-bold ${avgPct >= 100 ? 'text-emerald-600' : avgPct >= 60 ? 'text-amber-600' : 'text-red-500'}`}>{avgPct}%</p>
        </div>
      </div>

      {/* Data table */}
      <div className="relative overflow-x-auto overflow-y-auto rounded-xl border border-gray-100 max-h-[260px]">
        <table className="w-full text-sm text-left">
          <thead className="bg-gray-50 text-xs font-semibold text-gray-500 sticky top-0 z-10">
            <tr>
              <th className="px-4 py-3">Sprint</th>
              <th className="px-4 py-3 text-center">เป้าหมาย</th>
              <th className="px-4 py-3 text-center">เสร็จแล้ว</th>
              <th className="px-4 py-3 text-center">ค้าง</th>
              <th className="px-4 py-3 text-center">% สำเร็จ</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {[...data].reverse().map((d, i) => {
              const pct = d.target > 0 ? Math.round((d.done / d.target) * 100) : 0;
              const remaining = d.target - d.done;
              return (
                <tr key={i} className="hover:bg-slate-50">
                  <td className="px-4 py-3 font-medium text-gray-800">{d.name}</td>
                  <td className="px-4 py-3 text-center text-gray-600">{d.target} tasks</td>
                  <td className="px-4 py-3 text-center font-semibold text-emerald-600">{d.done} tasks</td>
                  <td className="px-4 py-3 text-center font-semibold text-amber-600">{remaining > 0 ? `${remaining} tasks` : '—'}</td>
                  <td className="px-4 py-3 text-center">
                    <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-bold ${pct >= 100 ? 'bg-emerald-100 text-emerald-700' : pct >= 60 ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-700'}`}>
                      {pct}%
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default VelocityChart;
