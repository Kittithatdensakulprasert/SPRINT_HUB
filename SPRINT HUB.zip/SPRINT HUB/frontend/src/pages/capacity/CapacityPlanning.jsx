import React, { useState, useEffect } from 'react';
import SprintSelector from '../../components/SprintSelector';
import { teamMemberApi, sprintApi, capacityApi, jiraApi } from '../../services/api';

const CapacityPlanning = () => {
  const [teamMembers, setTeamMembers] = useState([]);
  const [sprints, setSprints] = useState([]);
  const [selectedSprintId, setSelectedSprintId] = useState(null);
  const [capacityData, setCapacityData] = useState([]);
  const [editingCell, setEditingCell] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState(null);
  const [successMsg, setSuccessMsg] = useState(null);
  const [jiraConfigured, setJiraConfigured] = useState(false);

  useEffect(() => {
    loadInitialData();
  }, []);

  useEffect(() => {
    if (selectedSprintId && teamMembers.length > 0) {
      loadCapacityData(selectedSprintId);
    }
  }, [selectedSprintId, teamMembers]);

  const loadInitialData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const [members, sprintList, jiraStatus] = await Promise.all([
        teamMemberApi.getActive(),
        sprintApi.getAll(),
        jiraApi.getStatus().catch(() => ({ configured: false })),
      ]);
      setTeamMembers(members);
      setSprints(sprintList);
      setJiraConfigured(jiraStatus.configured);
      if (sprintList.length > 0) setSelectedSprintId(sprintList[0].id);
    } catch (e) {
      setError('ไม่สามารถโหลดข้อมูลได้ ตรวจสอบการเชื่อมต่อ Backend');
    } finally {
      setIsLoading(false);
    }
  };

  const loadCapacityData = async (sprintId) => {
    try {
      // Auto-sync existing points จาก Jira ถ้า config พร้อม
      if (jiraConfigured) {
        await jiraApi.syncExistingPoints(sprintId).catch(() => null);
      }

      const existing = await capacityApi.getBySprint(sprintId);
      setCapacityData(prev => {
        const updated = teamMembers.map(member => {
          const saved = existing.find(c => c.memberId === member.id);
          const prevItem = prev.find(p => p.memberId === member.id);
          if (saved) {
            return {
              memberId: member.id,
              dayStatus: prevItem?.dayStatus || Array(10).fill('1'),
              reservePercent: parseFloat(saved.reservePercent) || 0,
              existingPts: parseFloat(saved.existingPts) || 0,
              availablePts: parseFloat(saved.availablePts) || 0,
              acceptablePts: parseFloat(saved.acceptablePts) || 0,
              finalManDay: parseFloat(saved.finalManDay) || 0,
            };
          }
          return {
            memberId: member.id,
            dayStatus: Array(10).fill('1'),
            reservePercent: 0,
            existingPts: 0,
            availablePts: 0,
            acceptablePts: 0,
            finalManDay: 0,
          };
        });
        return updated;
      });
    } catch {
      setCapacityData(teamMembers.map(member => ({
        memberId: member.id,
        dayStatus: Array(10).fill('1'),
        reservePercent: 0,
        existingPts: 0,
        availablePts: 0,
        acceptablePts: 0,
        finalManDay: 0,
      })));
    }
  };

  const showSuccess = (msg) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(null), 3000);
  };

  const getSprintWorkdays = (startDateStr) => {
    const days = [];
    const d = new Date(startDateStr);
    while (days.length < 10) {
      const dow = d.getDay();
      if (dow !== 0 && dow !== 6) days.push(new Date(d));
      d.setDate(d.getDate() + 1);
    }
    return days;
  };

  const currentSprint = sprints.find(s => s.id === selectedSprintId);
  const dowNames = ['อา', 'จ', 'อ', 'พ', 'พฤ', 'ศ', 'ส'];
  const workdays = currentSprint ? getSprintWorkdays(currentSprint.startDate) : [];
  const dayLabels = workdays.map(d => ({
    date: `${d.getDate()}/${d.getMonth() + 1}`,
    dow: dowNames[d.getDay()],
  }));

  const sprintOptions = sprints.map(s => ({
    name: s.name,
    dates: s.startDate && s.endDate ? `${s.startDate} – ${s.endDate}` : '',
    id: s.id,
  }));

  const MULTIPLIER = 2;

  const recalc = (item) => {
    const workingDays = item.dayStatus.filter(s => s === '1').length;
    const finalManDay = workingDays * (1 - item.reservePercent / 100);
    const availablePts = Math.round(finalManDay * MULTIPLIER);
    const acceptablePts = Math.round(availablePts - item.existingPts);
    return {
      ...item,
      finalManDay: parseFloat(finalManDay.toFixed(1)),
      availablePts,
      acceptablePts,
    };
  };

  const handleDayStatusChange = (memberId, dayIndex, value) => {
    setCapacityData(prev => prev.map(item => {
      if (item.memberId !== memberId) return item;
      const newDayStatus = [...item.dayStatus];
      newDayStatus[dayIndex] = value;
      return recalc({ ...item, dayStatus: newDayStatus });
    }));
  };

  const handleReservePercentChange = (memberId, value) => {
    setCapacityData(prev => prev.map(item => {
      if (item.memberId !== memberId) return item;
      return recalc({ ...item, reservePercent: parseFloat(value) || 0 });
    }));
  };

  const handlePtsOverride = (memberId, field, value) => {
    setCapacityData(prev => prev.map(item => {
      if (item.memberId !== memberId) return item;
      const updated = { ...item, [field]: parseFloat(value) || 0 };
      if (field === 'availablePts' || field === 'existingPts') {
        updated.acceptablePts = parseFloat((updated.availablePts - updated.existingPts).toFixed(1));
      }
      return updated;
    }));
  };

  const EditableCell = ({ memberId, field, value, colorClass, bgClass }) => {
    const key = `${memberId}-${field}`;
    const isEditing = editingCell === key;
    const [localVal, setLocalVal] = React.useState(String(value));

    React.useEffect(() => { setLocalVal(String(value)); }, [value]);

    if (isEditing) return (
      <input
        autoFocus
        type="number"
        value={localVal}
        onChange={(e) => setLocalVal(e.target.value)}
        onBlur={() => { handlePtsOverride(memberId, field, localVal); setEditingCell(null); }}
        onKeyDown={(e) => { if (e.key === 'Enter') { handlePtsOverride(memberId, field, localVal); setEditingCell(null); } if (e.key === 'Escape') setEditingCell(null); }}
        className={`w-16 text-center font-semibold outline-none border border-yellow-400 rounded-lg py-1 text-sm ${bgClass} ${colorClass} [-moz-appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none`}
      />
    );

    return (
      <button
        onClick={() => setEditingCell(key)}
        className={`group inline-flex items-center gap-1 px-2 py-1 rounded-lg hover:ring-2 hover:ring-yellow-300 transition cursor-pointer border-0 ${bgClass}`}
        title="คลิกเพื่อแก้ไขค่า"
      >
        <span className={`font-semibold text-sm ${colorClass}`}>{value}</span>
        <span className="material-icons text-[11px] opacity-0 group-hover:opacity-60 transition text-gray-400">edit</span>
      </button>
    );
  };

  const handleSave = async () => {
    if (!selectedSprintId) return;
    setIsSaving(true);
    setError(null);
    try {
      await capacityApi.batchCalculate({
        sprintId: selectedSprintId,
        members: capacityData.map(item => ({
          memberId: item.memberId,
          leaveDays: item.dayStatus.filter(s => s !== '1').length,
          reservePercent: item.reservePercent,
          existingPts: item.existingPts,
        })),
      });
      showSuccess('บันทึกข้อมูล Capacity Planning แล้ว');
    } catch (e) {
      setError('บันทึกไม่สำเร็จ ลองใหม่อีกครั้ง');
    } finally {
      setIsSaving(false);
    }
  };

  const getDaySelectClass = (value) => {
    if (value === 'L') return 'text-xs bg-red-100 text-red-700 border border-red-200 rounded p-1 font-semibold';
    if (value === 'BL') return 'text-xs bg-amber-100 text-amber-700 border border-amber-200 rounded p-1 font-semibold';
    if (value === 'TR') return 'text-xs bg-blue-100 text-blue-700 border border-blue-200 rounded p-1 font-semibold';
    return 'text-xs bg-gray-50 border border-gray-200 rounded p-1 font-semibold';
  };


  return (
    <div className="p-6 space-y-6">
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-2xl px-5 py-4 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="material-icons text-red-400">error_outline</span>
            <p className="font-semibold text-red-700 text-sm">{error}</p>
          </div>
          <button onClick={() => setError(null)} className="text-red-300 hover:text-red-500 border-0 bg-transparent cursor-pointer shrink-0">
            <span className="material-icons text-lg">close</span>
          </button>
        </div>
      )}
      {successMsg && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-2xl px-5 py-4 flex items-center gap-3">
          <span className="material-icons text-emerald-500">check_circle</span>
          <p className="text-sm font-semibold text-emerald-700">{successMsg}</p>
        </div>
      )}
      {isLoading && (
        <div className="bg-white border border-gray-200 rounded-2xl px-5 py-8 flex flex-col items-center gap-3">
          <span className="material-icons text-4xl text-gray-300 animate-spin">refresh</span>
          <p className="text-sm text-gray-400">กำลังโหลดข้อมูล...</p>
        </div>
      )}
      <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm flex justify-between items-start gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">วางแผนและคำนวณงานประจำ Sprint</h1>
          <p className="text-sm text-gray-500 mt-1">บันทึกวันลาและคำนวณค่า Story Points รายบุคคล</p>
          {jiraConfigured && (
            <span className="inline-flex items-center gap-1 mt-2 text-xs bg-emerald-100 text-emerald-700 font-semibold px-2 py-0.5 rounded-full">
              🔗 Jira Auto-sync Existing Pts
            </span>
          )}
        </div>
        <SprintSelector
          value={currentSprint?.name || ''}
          onChange={(name) => {
            const s = sprints.find(sp => sp.name === name);
            if (s) setSelectedSprintId(s.id);
          }}
          sprints={sprintOptions}
        />
      </div>

      <div className="bg-white rounded-2xl shadow border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-50 text-gray-600 text-xs font-semibold uppercase tracking-wider border-b border-gray-200">
                <th className="py-4 px-6 min-w-[150px]">รายชื่อในทีม</th>
                {dayLabels.map((label, i) => (
                  <th key={i} className="py-3 px-2 text-center w-12">
                    <div className="text-[10px] text-gray-400 font-medium">{label.dow}</div>
                    <div className="text-xs font-bold text-gray-700">{label.date}</div>
                  </th>
                ))}
                <th className="py-4 px-4 text-center min-w-[90px]">Reserve</th>
                <th className="py-4 px-4 text-center bg-gray-100 min-w-[110px]">FinalManDay</th>
                <th className="py-4 px-4 text-center bg-blue-50 text-blue-700 min-w-[110px]">Available Pts</th>
                <th className="py-4 px-4 text-center bg-purple-50 text-purple-700 min-w-[110px]">Existing Pts</th>
                <th className="py-4 px-4 text-center bg-amber-50 text-amber-800 min-w-[120px]">Acceptable Pts</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 text-sm text-gray-700">
              {teamMembers.length === 0 && (
                <tr>
                  <td colSpan={20} className="py-16 text-center">
                    <span className="material-icons text-4xl text-gray-200 block mb-3">people_outline</span>
                    <p className="text-gray-400 font-medium text-sm">ยังไม่มีข้อมูลสมาชิกทีม</p>
                    <p className="text-gray-300 text-xs mt-1">เชื่อมต่อ API หรือเพิ่มสมาชิกในหน้าตั้งค่า</p>
                  </td>
                </tr>
              )}
              {teamMembers.map((member) => {
                const capacity = capacityData.find(item => item.memberId === member.id) || {
                  dayStatus: Array(10).fill('1'),
                  reservePercent: 0,
                  existingPts: 0,
                  availablePts: 0,
                  acceptablePts: 0,
                  finalManDay: 0,
                };
                return (
                  <tr key={member.id} className="hover:bg-amber-50/30 transition">
                    <td className="py-4 px-6 font-medium text-gray-900">{member.name}</td>
                    {capacity.dayStatus.map((status, dayIndex) => (
                      <td key={dayIndex} className="py-3 px-1 text-center">
                        <select
                          className={getDaySelectClass(status)}
                          value={status}
                          onChange={(e) => handleDayStatusChange(member.id, dayIndex, e.target.value)}
                        >
                          <option value="1">1</option>
                          <option value="L">L</option>
                          <option value="BL">BL</option>
                          <option value="TR">TR</option>
                        </select>
                      </td>
                    ))}
                    <td className="py-3 px-4 text-center">
                      <div className="inline-flex items-center gap-1 border border-gray-200 rounded-xl bg-gray-50 px-2 py-1.5 w-16">
                        <input
                          type="number"
                          min="0"
                          max="100"
                          value={capacity.reservePercent === 0 ? '' : capacity.reservePercent}
                          placeholder="0"
                          onChange={(e) => handleReservePercentChange(member.id, e.target.value === '' ? 0 : e.target.value)}
                          className="w-8 text-center bg-transparent text-sm font-semibold outline-none border-0 [-moz-appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                        />
                        <span className="text-xs text-gray-400">%</span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-center font-semibold bg-gray-50 text-gray-600">{capacity.finalManDay} วัน</td>
                    <td className="py-3 px-4 text-center bg-blue-50">
                      <EditableCell memberId={member.id} field="availablePts" value={capacity.availablePts} colorClass="text-blue-600" bgClass="bg-blue-50" />
                    </td>
                    <td className="py-3 px-4 text-center bg-purple-50">
                      <EditableCell memberId={member.id} field="existingPts" value={capacity.existingPts} colorClass="text-purple-600" bgClass="bg-purple-50" />
                    </td>
                    <td className={`py-3 px-4 text-center ${capacity.acceptablePts >= 0 ? 'bg-emerald-50' : 'bg-red-50'}`}>
                      <EditableCell memberId={member.id} field="acceptablePts" value={capacity.acceptablePts} colorClass={capacity.acceptablePts >= 0 ? 'text-emerald-600' : 'text-red-600'} bgClass={capacity.acceptablePts >= 0 ? 'bg-emerald-50' : 'bg-red-50'} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="p-4 bg-gray-50 border-t border-gray-200 flex justify-end">
          <button
            onClick={handleSave}
            disabled={isSaving || !selectedSprintId}
            className="bg-yellow-400 hover:bg-yellow-300 active:scale-95 disabled:opacity-60 text-slate-900 font-bold px-6 py-2.5 rounded-xl transition-all duration-150 shadow-md hover:shadow-lg flex items-center gap-2 cursor-pointer border-0"
          >
            <span className={`material-icons text-base ${isSaving ? 'animate-spin' : ''}`}>{isSaving ? 'refresh' : 'save'}</span>
            <span>{isSaving ? 'กำลังบันทึก...' : 'บันทึก'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default CapacityPlanning;
