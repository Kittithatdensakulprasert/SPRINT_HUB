/**
 * CapacityPlanning.jsx
 * หน้าวางแผนความสามารถ Sprint (Sprint Capacity Planning)
 *
 * หน้าที่:
 * 1. แสดงตารางสมาชิกทีม + วันทำงาน + วันลา + reserve %
 * 2. คำนวณ FinalManDay = workingDays × (1 - reservePercent/100)
 * 3. คำนวณ AvailablePts = FinalManDay × points_per_day (multiplier)
 * 4. คำนวณ AcceptablePts = AvailablePts - ExistingPts
 * 5. ดึง ExistingPts จาก Jira (งานที่ยังไม่เสร็จจาก sprint ก่อน)
 * 6. รองรับการแก้ไข leave days เป็นรายวัน (dayStatus: P=Present, วันลาอื่น)
 * 7. รีเฟรชหน้าเบราว์เซอร์จะ sync existing points จาก Jira
 * 8. บันทึก/คำนวณ batch ผ่าน capacityApi.batchCalculate
 *
 * State สำคัญ:
 * - teamMembers: สมาชิกทีมทั้งหมด
 * - sprints: sprint list
 * - selectedSprintId: sprint ที่เลือก
 * - capacityData: ข้อมูล capacity รายคน (dayStatus, reservePercent, existingPts)
 * - multiplier: ค่า points_per_day (ดึงจาก configApi)
 *
 * API ที่ใช้:
 * - teamMemberApi.getActive(), sprintApi.getAll(), configApi.getByKey('points_per_day')
 * - capacityApi.getBySprint(sprintId)
 * - jiraApi.syncExistingPoints(sprintId) — ดึง existing points ครั้งแรก
 * - jiraApi.syncSprintResults(sprintId) — อัปเดต sprint results ตอนรีเฟรช
 * - capacityApi.batchCalculate(body) — บันทึก/คำนวณ
 */

import React, { useState, useEffect } from 'react';
import SprintSelector from '../../components/SprintSelector';
import { teamMemberApi, sprintApi, capacityApi, jiraApi, configApi } from '../../services/api';

const getSprintNumber = (sprintName) => {
  if (!sprintName) return null;
  const match = sprintName.match(/Sprint\s+(\d+)/i);
  return match ? match[1] : null;
};

const CapacityPlanning = () => {
  const [teamMembers, setTeamMembers] = useState([]);
  const [sprints, setSprints] = useState([]);
  const [selectedSprintId, setSelectedSprintId] = useState(null);
  const [capacityData, setCapacityData] = useState([]);
  const [editingCell, setEditingCell] = useState(null);
  const [multiplier, setMultiplier] = useState(1.4);
  const [isLoading, setIsLoading] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState(null);
  const [successMsg, setSuccessMsg] = useState(null);
  const [jiraConfigured, setJiraConfigured] = useState(false);
  const [memberSearch, setMemberSearch] = useState('');

  useEffect(() => {
    loadInitialData();
  }, []);

  useEffect(() => {
    if (selectedSprintId && teamMembers.length > 0) {
      loadCapacityData(selectedSprintId);
    }
  }, [selectedSprintId, teamMembers]);

  useEffect(() => {
    const handleForceSync = async (e) => {
      try {
        const syncSprints = e?.detail?.syncSprints === true;
        if (syncSprints && jiraConfigured) {
          // ดึง sprint list ใหม่จาก Jira ก่อน เผื่อมี sprint ใหม่
          await jiraApi.syncSprints();
          const newSprints = await sprintApi.getAll();
          setSprints(newSprints);
        }
        if (selectedSprintId && teamMembers.length > 0) {
          await loadCapacityData(selectedSprintId, true);
        }
        window.dispatchEvent(new CustomEvent('jira-sync-done', { detail: { success: true } }));
      } catch {
        window.dispatchEvent(new CustomEvent('jira-sync-done', { detail: { success: false } }));
      }
    };
    window.addEventListener('jira-force-sync', handleForceSync);
    return () => window.removeEventListener('jira-force-sync', handleForceSync);
  }, [selectedSprintId, teamMembers, jiraConfigured]);

  const loadInitialData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const [members, sprintList, jiraStatus, config] = await Promise.all([
        teamMemberApi.getActive(),
        sprintApi.getAll(),
        jiraApi.getStatus().catch(() => ({ configured: false })),
        configApi.getByKey('points_per_day').catch(() => null),
      ]);
      setTeamMembers(members);
      setSprints(sprintList);
      setJiraConfigured(jiraStatus.configured);
      if (config) setMultiplier(parseFloat(config.value) || 1.4);
      if (sprintList.length > 0) {
        const active = sprintList.find(s => s.status === 'active') || sprintList[0];
        setSelectedSprintId(active.id);
      }
    } catch (e) {
      setError('ไม่สามารถโหลดข้อมูลได้ ตรวจสอบการเชื่อมต่อ Backend');
    } finally {
      setIsLoading(false);
    }
  };

  const loadCapacityData = async (sprintId, forceSync = false) => {
    try {
      const activeSprint = sprints.find(s => s.id === sprintId);

      // ตรวจสอบว่ามีข้อมูลใน DB ไหมก่อน
      const existing = await capacityApi.getBySprint(sprintId);
      const hasNoData = existing.length === 0;

      if (jiraConfigured && (activeSprint?.status === 'active' || activeSprint?.status === 'future')) {
        if (hasNoData) {
          // ครั้งแรกสุด: ยังไม่เคยมีข้อมูลเลย → sync existing points อัตโนมัติ
          setIsSyncing(true);
          await jiraApi.syncExistingPoints(sprintId).catch(() => null);
          setIsSyncing(false);
        } else if (forceSync) {
          // กดปุ่ม Sync เท่านั้น → sync sprint results อัปเดต
          setIsSyncing(true);
          await jiraApi.syncSprintResults(sprintId);
          setIsSyncing(false);
        }
      }

      const refreshed = await capacityApi.getBySprint(sprintId);
      setCapacityData(prev => {
        const updated = teamMembers.map(member => {
          const saved = refreshed.find(c => c.memberId === member.id);
          const prevItem = prev.find(p => p.memberId === member.id);
          const normalizeDayStatus = (status) => status.split(',').map(s => s === '1' ? 'P' : s);
          const base = saved ? {
              memberId: member.id,
              dayStatus: saved.dayStatus ? normalizeDayStatus(saved.dayStatus) : (prevItem?.dayStatus || Array(10).fill('P')),
              reservePercent: parseFloat(saved.reservePercent) || 0,
              existingPts: parseFloat(saved.existingPts) || 0,
            } : {
              memberId: member.id,
              dayStatus: Array(10).fill('P'),
              reservePercent: 0,
              existingPts: 0,
            };
          return recalc(base);
        });
        return updated;
      });
    } catch (e) {
      setIsSyncing(false);
      setCapacityData(teamMembers.map(member => recalc({
        memberId: member.id,
        dayStatus: Array(10).fill('P'),
        reservePercent: 0,
        existingPts: 0,
      })));
      if (forceSync) throw e;
    }
  };

  const showSuccess = (msg) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(null), 3000);
  };

  const getSprintWorkdays = (startDateStr) => {
    const days = [];
    const d = new Date(startDateStr);
    while (days.length < 10) {
      const dow = d.getDay();
      if (dow !== 0 && dow !== 6) days.push(new Date(d));
      d.setDate(d.getDate() + 1);
    }
    return days;
  };

  const currentSprint = sprints.find(s => s.id === selectedSprintId);
  const dowNames = ['อา', 'จ', 'อ', 'พ', 'พฤ', 'ศ', 'ส'];
  const workdays = currentSprint ? getSprintWorkdays(currentSprint.startDate) : [];
  const dayLabels = workdays.map(d => ({
    date: `${d.getDate()}/${d.getMonth() + 1}`,
    dow: dowNames[d.getDay()],
  }));

  const sprintOptions = sprints.map(s => ({
    name: s.name,
    dates: s.startDate && s.endDate ? `${s.startDate} – ${s.endDate}` : '',
    id: s.id,
    isActive: s.status === 'active',
  }));

  const recalc = (item) => {
    const workingDays = item.dayStatus.filter(s => s === 'P' || s === '1').length;
    const finalManDay = workingDays * (1 - item.reservePercent / 100);
    const availablePts = Math.round(finalManDay * multiplier);
    const acceptablePts = Math.round(availablePts - item.existingPts);
    return {
      ...item,
      finalManDay: Math.floor(finalManDay),
      availablePts,
      acceptablePts,
    };
  };

  const handleDayStatusChange = (memberId, dayIndex, value) => {
    setCapacityData(prev => prev.map(item => {
      if (item.memberId !== memberId) return item;
      const newDayStatus = [...item.dayStatus];
      newDayStatus[dayIndex] = value;
      return recalc({ ...item, dayStatus: newDayStatus });
    }));
  };

  const handleReservePercentChange = (memberId, value) => {
    setCapacityData(prev => prev.map(item => {
      if (item.memberId !== memberId) return item;
      return recalc({ ...item, reservePercent: parseFloat(value) || 0 });
    }));
  };

  const handlePtsOverride = (memberId, field, value) => {
    setCapacityData(prev => prev.map(item => {
      if (item.memberId !== memberId) return item;
      const updated = { ...item, [field]: parseFloat(value) || 0 };
      if (field === 'availablePts' || field === 'existingPts') {
        updated.acceptablePts = parseFloat((updated.availablePts - updated.existingPts).toFixed(1));
      }
      return updated;
    }));
  };

  const EditableCell = ({ memberId, field, value, colorClass, bgClass }) => {
    const key = `${memberId}-${field}`;
    const isEditing = editingCell === key;
    const [localVal, setLocalVal] = React.useState(String(value));

    React.useEffect(() => { setLocalVal(String(value)); }, [value]);

    if (isEditing) return (
      <input
        autoFocus
        type="number"
        value={localVal}
        onChange={(e) => setLocalVal(e.target.value)}
        onBlur={() => { handlePtsOverride(memberId, field, localVal); setEditingCell(null); }}
        onKeyDown={(e) => { if (e.key === 'Enter') { handlePtsOverride(memberId, field, localVal); setEditingCell(null); } if (e.key === 'Escape') setEditingCell(null); }}
        className={`w-16 text-center font-semibold outline-none border border-yellow-400 rounded-lg py-1 text-sm ${bgClass} ${colorClass} [-moz-appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none`}
      />
    );

    return (
      <button
        onClick={() => setEditingCell(key)}
        className={`group inline-flex items-center gap-1 px-2 py-1 rounded-lg hover:ring-2 hover:ring-yellow-300 transition cursor-pointer border-0 ${bgClass}`}
        title="คลิกเพื่อแก้ไขค่า"
      >
        <span className={`font-semibold text-sm ${colorClass}`}>{value}</span>
        <span className="material-icons text-[11px] opacity-0 group-hover:opacity-60 transition text-gray-400">edit</span>
      </button>
    );
  };

  const handleSave = async () => {
    if (!selectedSprintId) return;
    setIsSaving(true);
    setError(null);
    try {
      await capacityApi.batchCalculate({
        sprintId: selectedSprintId,
        members: capacityData.map(item => ({
          memberId: item.memberId,
          leaveDays: item.dayStatus.filter(s => s !== 'P' && s !== '1').length,
          dayStatus: item.dayStatus.join(','),
          reservePercent: item.reservePercent,
          existingPts: item.existingPts,
        })),
      });
      showSuccess('บันทึกข้อมูล Capacity Planning แล้ว');
    } catch (e) {
      setError('บันทึกไม่สำเร็จ ลองใหม่อีกครั้ง');
    } finally {
      setIsSaving(false);
    }
  };

  const getDaySelectClass = (value) => {
    if (value === 'P' || value === '1') return 'text-xs bg-gray-50 border border-gray-200 rounded p-1 font-semibold';
    if (value === 'L') return 'text-xs bg-red-100 text-red-700 border border-red-200 rounded p-1 font-semibold';
    if (value === 'BL') return 'text-xs bg-amber-100 text-amber-700 border border-amber-200 rounded p-1 font-semibold';
    if (value === 'TR') return 'text-xs bg-blue-100 text-blue-700 border border-blue-200 rounded p-1 font-semibold';
    return 'text-xs bg-gray-50 border border-gray-200 rounded p-1 font-semibold';
  };


  return (
    <div className="p-6 space-y-6">
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-2xl px-5 py-4 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="material-icons text-red-400">error_outline</span>
            <p className="font-semibold text-red-700 text-sm">{error}</p>
          </div>
          <button onClick={() => setError(null)} className="text-red-300 hover:text-red-500 border-0 bg-transparent cursor-pointer shrink-0">
            <span className="material-icons text-lg">close</span>
          </button>
        </div>
      )}
      {successMsg && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-2xl px-5 py-4 flex items-center gap-3">
          <span className="material-icons text-emerald-500">check_circle</span>
          <p className="text-sm font-semibold text-emerald-700">{successMsg}</p>
        </div>
      )}
      {isSyncing && (
        <div className="bg-blue-50 border border-blue-200 rounded-2xl px-5 py-3 flex items-center gap-3">
          <span className="material-icons text-blue-400 animate-spin text-xl">sync</span>
          <p className="text-sm font-semibold text-blue-700">กำลัง Sync ข้อมูล Sprint...</p>
        </div>
      )}
      {isLoading && (
        <div className="bg-white border border-gray-200 rounded-2xl px-5 py-8 flex flex-col items-center gap-3">
          <span className="material-icons text-4xl text-gray-300 animate-spin">refresh</span>
          <p className="text-sm text-gray-400">กำลังโหลดข้อมูล...</p>
        </div>
      )}
      <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm flex justify-between items-start gap-4 flex-wrap">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-gray-900">วางแผนและคำนวณงานประจำ Sprint</h1>
            {getSprintNumber(currentSprint?.name) && (
              <span className="text-lg font-bold text-emerald-600 bg-emerald-50 px-2.5 py-0.5 rounded-lg border border-emerald-100">
                #{getSprintNumber(currentSprint?.name)}
              </span>
            )}
            <span
              title={jiraConfigured ? 'เชื่อมต่อ Jira แล้ว' : 'ไม่ได้เชื่อมต่อ Jira'}
              className={`w-2.5 h-2.5 rounded-full shrink-0 ${jiraConfigured ? 'bg-emerald-500' : 'bg-red-400'}`}
            />
          </div>
          <div className="flex items-center gap-3 mt-1">
            <p className="text-sm text-gray-500">บันทึกวันลาและคำนวณค่า Story Points รายบุคคล</p>
            {currentSprint?.startDate && currentSprint?.endDate && (
              <span className="inline-flex items-center gap-1.5 text-xs font-medium text-gray-500 bg-gray-100 px-2.5 py-1 rounded-full">
                <span className="material-icons text-xs text-gray-400">calendar_today</span>
                {new Date(currentSprint.startDate).toLocaleDateString('th-TH', { day: 'numeric', month: 'short', year: 'numeric' })}
                {' – '}
                {new Date(currentSprint.endDate).toLocaleDateString('th-TH', { day: 'numeric', month: 'short', year: 'numeric' })}
              </span>
            )}
          </div>
        </div>
        <SprintSelector
          value={currentSprint?.name || ''}
          onChange={(name) => {
            const s = sprints.find(sp => sp.name === name);
            if (s) setSelectedSprintId(s.id);
          }}
          sprints={sprintOptions}
        />
      </div>

      <div className="bg-white rounded-2xl shadow border border-gray-200 overflow-hidden">
        <div className="px-4 py-2 border-b border-gray-100 flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2 bg-gray-50 rounded-lg px-3 py-1.5 border border-gray-200">
            <span className="material-icons text-gray-400 text-sm">search</span>
            <input
              type="text"
              placeholder="ค้นหาชื่อสมาชิก..."
              value={memberSearch}
              onChange={(e) => setMemberSearch(e.target.value)}
              className="flex-1 bg-transparent text-sm outline-none text-gray-700 placeholder-gray-400"
            />
            {memberSearch && (
              <button onClick={() => setMemberSearch('')} className="text-gray-400 hover:text-gray-600 cursor-pointer border-0 bg-transparent p-0">
                <span className="material-icons text-sm">close</span>
              </button>
            )}
          </div>
          <div className="flex flex-wrap items-center gap-3 text-xs text-gray-600">
            <span className="flex items-center gap-1"><span className="bg-gray-100 text-gray-700 px-1.5 rounded font-semibold">P</span> Present (ทำงาน)</span>
            <span className="flex items-center gap-1"><span className="bg-red-100 text-red-700 px-1.5 rounded font-semibold">L</span> Leave (ลา)</span>
            <span className="flex items-center gap-1"><span className="bg-amber-100 text-amber-700 px-1.5 rounded font-semibold">BL</span> Block Leave</span>
            <span className="flex items-center gap-1"><span className="bg-blue-100 text-blue-700 px-1.5 rounded font-semibold">TR</span> Training (อบรม)</span>
          </div>
        </div>
        <div className="overflow-x-auto overflow-y-auto max-h-[calc(100vh-20rem)]">
          <table className="w-full text-left border-collapse">
            <thead className="sticky top-0 z-10">
              <tr className="bg-gray-50 text-gray-600 text-xs font-semibold uppercase tracking-wider border-b border-gray-200">
                <th className="py-4 px-6 min-w-[150px]">รายชื่อในทีม</th>
                {dayLabels.map((label, i) => (
                  <th key={i} className="py-3 px-2 text-center w-12">
                    <div className="text-[10px] text-gray-400 font-medium">{label.dow}</div>
                    <div className="text-xs font-bold text-gray-700">{label.date}</div>
                  </th>
                ))}
                <th className="py-4 px-4 text-center min-w-[90px]">Reserve</th>
                <th className="py-4 px-4 text-center bg-gray-100 min-w-[110px]">Final ManDay</th>
                <th className="py-4 px-4 text-center bg-blue-50 text-blue-700 min-w-[110px]">Available points.</th>
                <th className="py-4 px-4 text-center bg-purple-50 text-purple-700 min-w-[110px]">Existing points.</th>
                <th className="py-4 px-4 text-center bg-amber-50 text-amber-800 min-w-[120px]">Acceptable points.</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 text-sm text-gray-700">
              {teamMembers.length === 0 && (
                <tr>
                  <td colSpan={20} className="py-16 text-center">
                    <span className="material-icons text-4xl text-gray-200 block mb-3">people_outline</span>
                    <p className="text-gray-400 font-medium text-sm">ยังไม่มีข้อมูลสมาชิกทีม</p>
                    <p className="text-gray-300 text-xs mt-1">เชื่อมต่อ API หรือเพิ่มสมาชิกในหน้าตั้งค่า</p>
                  </td>
                </tr>
              )}
              {teamMembers.filter(m => m.name.toLowerCase().includes(memberSearch.toLowerCase())).map((member) => {
                const capacity = capacityData.find(item => item.memberId === member.id) || {
                  dayStatus: Array(10).fill('1'),
                  reservePercent: 0,
                  existingPts: 0,
                  availablePts: 0,
                  acceptablePts: 0,
                  finalManDay: 0,
                };
                return (
                  <tr key={member.id} className="hover:bg-amber-50/30 transition">
                    <td className="py-4 px-6 font-medium text-gray-900">{member.name}</td>
                    {capacity.dayStatus.map((status, dayIndex) => (
                      <td key={dayIndex} className="py-3 px-1 text-center">
                        <select
                          title={status === 'P' || status === '1' ? 'Present (ทำงาน)' : status === 'L' ? 'Leave (ลา)' : status === 'BL' ? 'Business Leave (ภารกิจบริษัท)' : status === 'TR' ? 'Training (อบรม)' : ''}
                          className={getDaySelectClass(status)}
                          value={status === '1' ? 'P' : status}
                          onChange={(e) => handleDayStatusChange(member.id, dayIndex, e.target.value)}
                        >
                          <option value="P" title="Present (ทำงาน)">P</option>
                          <option value="L" title="Leave (ลา)">L</option>
                          <option value="BL" title="Business Leave (ภารกิจบริษัท)">BL</option>
                          <option value="TR" title="Training (อบรม)">TR</option>
                        </select>
                      </td>
                    ))}
                    <td className="py-3 px-4 text-center">
                      <div className="inline-flex items-center gap-1 border border-gray-200 rounded-xl bg-gray-50 px-2 py-1.5 w-16">
                        <input
                          type="number"
                          min="0"
                          max="100"
                          value={capacity.reservePercent === 0 ? '' : capacity.reservePercent}
                          placeholder="0"
                          onChange={(e) => handleReservePercentChange(member.id, e.target.value === '' ? 0 : e.target.value)}
                          className="w-8 text-center bg-transparent text-sm font-semibold text-gray-900 outline-none border-0 placeholder:text-gray-900 [-moz-appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                        />
                        <span className="text-xs text-gray-900">%</span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-center font-semibold bg-gray-50 text-gray-600">{capacity.finalManDay} วัน</td>
                    <td className="py-3 px-4 text-center bg-blue-50">
                      <EditableCell memberId={member.id} field="availablePts" value={capacity.availablePts} colorClass="text-blue-600" bgClass="bg-blue-50" />
                    </td>
                    <td className="py-3 px-4 text-center bg-purple-50">
                      <EditableCell memberId={member.id} field="existingPts" value={capacity.existingPts} colorClass="text-purple-600" bgClass="bg-purple-50" />
                    </td>
                    <td className={`py-3 px-4 text-center ${capacity.acceptablePts >= 0 ? 'bg-emerald-50' : 'bg-red-50'}`}>
                      <EditableCell memberId={member.id} field="acceptablePts" value={capacity.acceptablePts} colorClass={capacity.acceptablePts >= 0 ? 'text-emerald-600' : 'text-red-600'} bgClass={capacity.acceptablePts >= 0 ? 'bg-emerald-50' : 'bg-red-50'} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="p-4 bg-gray-50 border-t border-gray-200 flex justify-end">
          <button
            onClick={handleSave}
            disabled={isSaving || !selectedSprintId}
            className="bg-yellow-400 hover:bg-yellow-300 active:scale-95 disabled:opacity-60 text-slate-900 font-bold px-6 py-2.5 rounded-xl transition-all duration-150 shadow-md hover:shadow-lg flex items-center gap-2 cursor-pointer border-0"
          >
            <span className={`material-icons text-base ${isSaving ? 'animate-spin' : ''}`}>{isSaving ? 'refresh' : 'save'}</span>
            <span>{isSaving ? 'กำลังบันทึก...' : 'บันทึก'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default CapacityPlanning;
