import React, { useState } from 'react';

export default function ShareRoomButton({ roomId }) {
  const [showModal, setShowModal] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [copiedRoomId, setCopiedRoomId] = useState(false);

  const shareLink = `${window.location.origin}/scrum-poker/${roomId}`;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(shareLink);
      setCopiedUrl(true);
      setTimeout(() => setCopiedUrl(false), 500);
    } catch (err) {
      const textArea = document.createElement('textarea');
      textArea.value = shareLink;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopiedUrl(true);
      setTimeout(() => setCopiedUrl(false), 2000);
    }
  };

  const handleCopyRoomId = async () => {
    try {
      await navigator.clipboard.writeText(roomId);
      setCopiedRoomId(true);
      setTimeout(() => setCopiedRoomId(false), 500);
    } catch (err) {
      const textArea = document.createElement('textarea');
      textArea.value = roomId;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopiedRoomId(true);
      setTimeout(() => setCopiedRoomId(false), 2000);
    }
  };

  const handleEmailShare = () => {
    const subject = 'เชิญเข้าร่วม Scrum Poker';
    const body = `เชิญคุณเข้าร่วมห้อง Scrum Poker\n\nรหัสห้อง: ${roomId}\nลิงก์: ${shareLink}`;
    window.location.href = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  };

  return (
    <>
      <button
        onClick={() => setShowModal(true)}
        style={{
          backgroundColor: '#005C6E',
          color: '#FFFFFF',
          fontWeight: '700',
          padding: '10px 20px',
          borderRadius: '10px',
          boxShadow: '0 3px 10px rgba(0,92,110,0.25)',
          fontSize: '14px',
          cursor: 'pointer',
          border: '2px solid #005C6E',
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          transition: 'all 0.2s ease'
        }}
        onMouseEnter={(e) => {
          e.target.style.backgroundColor = '#004A5A';
          e.target.style.borderColor = '#004A5A';
          e.target.style.transform = 'translateY(-1px)';
          e.target.style.boxShadow = '0 5px 15px rgba(0,92,110,0.35)';
        }}
        onMouseLeave={(e) => {
          e.target.style.backgroundColor = '#005C6E';
          e.target.style.borderColor = '#005C6E';
          e.target.style.transform = 'translateY(0)';
          e.target.style.boxShadow = '0 3px 10px rgba(0,92,110,0.25)';
        }}
      >
        📤 แชร์ห้อง
      </button>

      {showModal && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0,0,0,0.7)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
          backdropFilter: 'blur(5px)'
        }}>
          <div style={{
            backgroundColor: 'white',
            borderRadius: '24px',
            padding: '48px',
            maxWidth: '500px',
            width: '90%',
            boxShadow: '0 25px 50px rgba(0,0,0,0.3)',
            position: 'relative'
          }}>
            <button
              onClick={() => setShowModal(false)}
              style={{
                position: 'absolute',
                top: '20px',
                right: '20px',
                background: 'none',
                border: 'none',
                fontSize: '28px',
                cursor: 'pointer',
                color: '#666',
                transition: 'all 0.3s'
              }}
              onMouseEnter={(e) => e.target.style.color = '#333'}
              onMouseLeave={(e) => e.target.style.color = '#666'}
            >
              ×
            </button>

            <h2 style={{
              fontSize: '28px',
              fontWeight: '800',
              color: '#1A1A1A',
              margin: '0 0 8px 0',
              textAlign: 'center'
            }}>
              แชร์ห้อง
            </h2>
            <p style={{
              fontSize: '16px',
              color: '#666',
              margin: '0 0 32px 0',
              textAlign: 'center'
            }}>
              แชร์รหัสห้องให้ทีมเข้าร่วม
            </p>

            <div style={{
              backgroundColor: '#F9FAFB',
              borderRadius: '16px',
              padding: '24px',
              marginBottom: '24px',
              textAlign: 'center'
            }}>
              <div style={{
                fontSize: '48px',
                fontWeight: '800',
                color: '#FFCC00',
                marginBottom: '8px',
                letterSpacing: '4px'
              }}>
                {roomId}
              </div>
              <p style={{
                fontSize: '14px',
                color: '#666',
                margin: 0
              }}>
                รหัสห้อง
              </p>
            </div>

            <div style={{
              backgroundColor: '#F9FAFB',
              borderRadius: '12px',
              padding: '16px',
              marginBottom: '24px',
              display: 'flex',
              gap: '12px',
              alignItems: 'center'
            }}>
              <input
                type="text"
                value={shareLink}
                readOnly
                style={{
                  flex: 1,
                  padding: '12px 16px',
                  borderRadius: '8px',
                  border: '2px solid #E5E7EB',
                  backgroundColor: '#FFFFFF',
                  color: '#1A1A1A',
                  fontSize: '14px',
                  outline: 'none'
                }}
              />
              <button
                onClick={handleCopy}
                style={{
                  padding: '12px 20px',
                  borderRadius: '8px',
                  backgroundColor: copiedUrl ? '#10B981' : '#FFCC00',
                  color: '#1A1A1A',
                  fontWeight: '700',
                  fontSize: '14px',
                  border: 'none',
                  cursor: 'pointer',
                  transition: 'all 0.3s',
                  whiteSpace: 'nowrap'
                }}
              >
                {copiedUrl ? '✅ คัดลอกแล้ว' : '📋 คัดลอก'}
              </button>
            </div>

            <div style={{
              display: 'flex',
              gap: '12px'
            }}>
              <button
                onClick={handleCopyRoomId}
                style={{
                  flex: 1,
                  padding: '16px 24px',
                  borderRadius: '12px',
                  backgroundColor: copiedRoomId ? '#10B981' : '#005C6E',
                  color: 'white',
                  fontWeight: '700',
                  fontSize: '16px',
                  border: 'none',
                  cursor: 'pointer',
                  transition: 'all 0.3s',
                  boxShadow: '0 4px 12px rgba(0,92,110,0.3)'
                }}
                onMouseEnter={(e) => {
                  if (!copiedRoomId) {
                    e.target.style.backgroundColor = '#004A5A';
                    e.target.style.transform = 'translateY(-2px)';
                  }
                }}
                onMouseLeave={(e) => {
                  if (!copiedRoomId) {
                    e.target.style.backgroundColor = '#005C6E';
                    e.target.style.transform = 'translateY(0)';
                  }
                }}
              >
                {copiedRoomId ? '✅ คัดลอกแล้ว' : '📋 คัดลอกรหัสห้อง'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
