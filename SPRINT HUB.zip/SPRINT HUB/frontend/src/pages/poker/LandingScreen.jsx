import React, { useState, useEffect } from 'react';

export default function LandingScreen({ onCreateRoom, onJoinRoom, initialJoinRoomId }) {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showJoinModal, setShowJoinModal] = useState(!!initialJoinRoomId);
  const [inputName, setInputName] = useState('');
  const [inputRoomId, setInputRoomId] = useState(initialJoinRoomId || '');
  const [hasAutoShown, setHasAutoShown] = useState(false);

  useEffect(() => {
    if (initialJoinRoomId && !hasAutoShown) {
      setShowJoinModal(true);
      setInputRoomId(initialJoinRoomId);
      setHasAutoShown(true);
    }
  }, [initialJoinRoomId, hasAutoShown]);

  const handleCreateSubmit = (e) => {
    e.preventDefault();
    if (!inputName) return alert('กรุณากรอกชื่อของคุณ');
    onCreateRoom(inputName);
    setShowCreateModal(false);
    setInputName('');
  };

  const handleJoinSubmit = (e) => {
    e.preventDefault();
    if (!inputName) return alert('กรุณากรอกชื่อของคุณ');
    if (!inputRoomId) return alert('กรุณากรอกรหัสห้อง');
    onJoinRoom(inputRoomId, inputName);
    setShowJoinModal(false);
    setInputName('');
    setInputRoomId('');
  };

  return (
    <div className="w-full min-h-full bg-gradient-to-br from-slate-900 via-teal-900 to-cyan-800 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute top-1/4 left-8 w-64 h-64 bg-yellow-400/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-1/4 right-8 w-80 h-80 bg-cyan-400/10 rounded-full blur-3xl pointer-events-none"></div>

      <main className="relative z-10 max-w-4xl mx-auto px-6 py-24">
        {/* Hero */}
        <div className="text-center flex flex-col items-center gap-6 mb-24">
          <h1 className="text-6xl font-black text-white leading-tight tracking-tight">
            <span className="text-yellow-400">Scrum</span> Poker
          </h1>
          <p className="text-xl text-white/80 font-medium max-w-lg">
            เครื่องมือประเมินงานแบบ Agile สำหรับทีม
          </p>
          <div className="flex gap-4 flex-wrap justify-center mt-4">
            <button
              onClick={() => setShowCreateModal(true)}
              className="bg-yellow-400 hover:bg-yellow-300 text-slate-900 font-black px-10 py-4 rounded-2xl text-lg shadow-lg shadow-yellow-400/30 hover:-translate-y-1 transition-all duration-200 cursor-pointer border-0"
            >
              🚀 สร้างห้องใหม่
            </button>
            <button
              onClick={() => setShowJoinModal(true)}
              className="bg-white/10 hover:bg-white/20 backdrop-blur-sm text-white font-bold px-10 py-4 rounded-2xl text-lg border-2 border-white/30 hover:border-yellow-400 hover:-translate-y-1 transition-all duration-200 cursor-pointer"
            >
              เข้าร่วมห้อง
            </button>
          </div>
        </div>

        {/* วิธีใช้งาน */}
        <div className="border-t border-white/15 pt-16">
          <h3 className="text-2xl font-bold text-white text-center mb-8">วิธีใช้งาน</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { emoji: '1️⃣', title: 'สร้างห้อง', desc: 'กดปุ่มสร้างห้องเพื่อรับรหัสห้อง', accent: 'from-yellow-400 to-yellow-300' },
              { emoji: '2️⃣', title: 'กรอกชื่อของคุณ', desc: 'ใส่ชื่อเพื่อให้ทีมรู้ว่าเป็นใคร', accent: 'from-cyan-400 to-teal-400' },
              { emoji: '3️⃣', title: 'แชร์รหัส', desc: 'ส่งรหัสห้องให้ทีมเข้าร่วม', accent: 'from-yellow-400 to-yellow-300' },
            ].map((step) => (
              <div key={step.title} className="bg-black/20 backdrop-blur-sm p-8 rounded-3xl border border-white/10 relative overflow-hidden hover:bg-black/30 transition">
                <div className={`absolute top-0 left-0 right-0 h-1 bg-gradient-to-r ${step.accent}`}></div>
                <div className="text-4xl mb-4">{step.emoji}</div>
                <h4 className="text-lg font-bold text-white mb-2">{step.title}</h4>
                <p className="text-white/60 text-sm leading-relaxed">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* Modal สร้างห้อง */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-12 max-w-md w-full shadow-2xl relative">
            <button
              onClick={() => setShowCreateModal(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-700 hover:bg-gray-100 p-1.5 rounded-xl cursor-pointer border-0 bg-transparent transition"
            >
              <span className="material-icons text-2xl">close</span>
            </button>
            <h2 className="text-2xl font-black text-gray-900 text-center mb-2">สร้างห้องใหม่</h2>
            <p className="text-gray-500 text-center mb-8">กรอกชื่อของคุณเพื่อเริ่มใช้งาน</p>
            <form onSubmit={handleCreateSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">ชื่อของคุณ</label>
                <input
                  type="text"
                  value={inputName}
                  onChange={(e) => setInputName(e.target.value)}
                  placeholder="กรอกชื่อของคุณ"
                  className="w-full px-5 py-4 rounded-xl border-2 border-gray-200 focus:border-yellow-400 focus:outline-none text-gray-900 font-medium transition"
                />
              </div>
              <button
                type="submit"
                className="w-full bg-yellow-400 hover:bg-yellow-300 text-slate-900 font-black py-4 rounded-xl text-lg shadow-lg shadow-yellow-400/30 hover:-translate-y-0.5 transition-all cursor-pointer border-0"
              >
                🚀 สร้างห้อง
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Modal เข้าร่วมห้อง */}
      {showJoinModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-12 max-w-md w-full shadow-2xl relative">
            <button
              onClick={() => setShowJoinModal(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-700 hover:bg-gray-100 p-1.5 rounded-xl cursor-pointer border-0 bg-transparent transition"
            >
              <span className="material-icons text-2xl">close</span>
            </button>
            <h2 className="text-2xl font-black text-gray-900 text-center mb-2">เข้าร่วมห้อง</h2>
            <p className="text-gray-500 text-center mb-8">กรอกรหัสห้องและชื่อของคุณ</p>
            <form onSubmit={handleJoinSubmit} className="space-y-5">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">รหัสห้อง</label>
                <input
                  type="text"
                  value={inputRoomId}
                  onChange={(e) => setInputRoomId(e.target.value)}
                  placeholder="กรอกรหัสห้อง"
                  className="w-full px-5 py-4 rounded-xl border-2 border-gray-200 focus:border-yellow-400 focus:outline-none text-gray-900 font-medium transition"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">ชื่อของคุณ</label>
                <input
                  type="text"
                  value={inputName}
                  onChange={(e) => setInputName(e.target.value)}
                  placeholder="กรอกชื่อของคุณ"
                  className="w-full px-5 py-4 rounded-xl border-2 border-gray-200 focus:border-yellow-400 focus:outline-none text-gray-900 font-medium transition"
                />
              </div>
              <button
                type="submit"
                className="w-full bg-yellow-400 hover:bg-yellow-300 text-slate-900 font-black py-4 rounded-xl text-lg shadow-lg shadow-yellow-400/30 hover:-translate-y-0.5 transition-all cursor-pointer border-0"
              >
                เข้าร่วมห้อง
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}