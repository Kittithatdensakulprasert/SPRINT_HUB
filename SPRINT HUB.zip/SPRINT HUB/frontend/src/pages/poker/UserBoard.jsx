import React from 'react';
import { KRUNGSRI_THEME } from '../../config';

export default function UserBoard({ users, roomStatus, myUserId }) {
  return (
    <div style={{ width: '100%', backgroundColor: 'white', borderRadius: '20px', boxShadow: '0 12px 28px rgba(15,23,42,0.07)', border: '1px solid rgba(0, 92, 110, 0.08)', overflow: 'hidden', transition: 'all 0.3s ease-out' }}>
      <table style={{ width: '100%', textAlign: 'left', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ background: 'linear-gradient(180deg, #F8FAFC 0%, #EEF6F7 100%)', color: '#48636B', fontSize: '12px', textTransform: 'uppercase', fontWeight: '800', letterSpacing: '0.05em', borderBottom: '1px solid rgba(0, 92, 110, 0.10)' }}>
            <th style={{ padding: '16px 24px' }}>รายชื่อสมาชิกในห้อง</th>
            <th style={{ padding: '16px 24px', textAlign: 'center', width: '150px' }}>Story Points</th>
          </tr>
        </thead>
        <tbody style={{ borderTop: '1px solid #F3F4F6' }}>
          {users.map(user => (
            <tr key={user.id} style={{ transition: 'all 0.3s ease-out', borderBottom: '1px solid #F3F4F6' }}>
              <td style={{ padding: '18px 24px', fontWeight: '700', color: '#102A31', fontSize: '15px' }}>
                <span style={{ display: 'inline-flex', alignItems: 'center', gap: '8px' }}>
                  {user.name}
                  {user.id === myUserId && (
                    <span style={{ background: 'linear-gradient(135deg, #FFCC00 0%, #FFF0A3 100%)', color: '#102A31', fontSize: '11px', fontWeight: '800', padding: '3px 8px', borderRadius: '9999px', border: '1px solid rgba(255,204,0,0.5)', boxShadow: '0 2px 6px rgba(255,204,0,0.24)' }}>
                      คุณ
                    </span>
                  )}
                </span>
              </td>
              <td style={{ padding: '18px 24px', textAlign: 'center' }}>
                {roomStatus === 'voting' ? (
                  user.voted
                    ? <span style={{ display: 'inline-block', backgroundColor: '#FEF3C7', color: '#92400E', fontSize: '13px', padding: '7px 14px', borderRadius: '9999px', fontWeight: '800' }}>โหวตแล้ว</span>
                    : <span style={{ display: 'inline-block', backgroundColor: '#F3F4F6', color: '#7B8794', fontSize: '13px', padding: '7px 14px', borderRadius: '9999px', fontWeight: '700' }}>รอโหวต</span>
                ) : (
                  <span style={{ display: 'inline-block', background: 'linear-gradient(135deg, #FFCC00 0%, #FFF0A3 100%)', color: '#102A31', fontWeight: '900', fontSize: '18px', padding: '10px 24px', borderRadius: '14px', boxShadow: '0 10px 20px rgba(255,204,0,0.24)', animation: 'flipIn 0.6s ease-out' }}>
                    {user.vote || '-'}
                  </span>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <style>{`
        @keyframes flipIn {
          0% {
            transform: rotateY(90deg);
            opacity: 0;
          }
          100% {
            transform: rotateY(0deg);
            opacity: 1;
          }
        }
      `}</style>
    </div>
  );
}
