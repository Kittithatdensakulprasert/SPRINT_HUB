import React from 'react';
import { KRUNGSRI_THEME } from '../../config';

export default function AnalyticsCard({ analytics }) {
  return (
    <div style={{ backgroundColor: 'white', color: '#1A1A1A', padding: '28px 32px', borderRadius: '16px', boxShadow: '0 8px 24px rgba(0,0,0,0.12)', border: '2px solid #FFCC00', animation: 'fadeInUp 0.5s ease-out' }}>
      <h3 style={{ fontSize: '13px', fontWeight: '800', color: '#FFCC00', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '16px' }}>📊 สรุปผลคะแนน</h3>
      <div style={{ display: 'flex', gap: '32px' }}>
        <div>
          <span style={{ fontSize: '13px', color: '#6B7280', display: 'block', marginBottom: '4px' }}>ค่าเฉลี่ย (Avg)</span>
          <span style={{ fontSize: '32px', fontWeight: '900', color: '#FFCC00' }}>{analytics.average}</span>
        </div>
        <div>
          <span style={{ fontSize: '13px', color: '#6B7280', display: 'block', marginBottom: '4px' }}>ฐานนิยม (Mode)</span>
          <span style={{ fontSize: '32px', fontWeight: '900', color: '#005C6E' }}>{analytics.mode}</span>
        </div>
      </div>
      <style>{`
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
}