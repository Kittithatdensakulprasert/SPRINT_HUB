import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import LandingScreen from './LandingScreen';
import UserBoard from './UserBoard';
import VotingDeck from './VotingDeck';
import ShareRoomButton from './ShareRoomButton';
import AnalyticsCard from './AnalyticsCard';
import websocketService from '../../services/websocketService';

const API_BASE = 'http://localhost:8080/api/rooms';
const STORAGE_KEY = 'scrum_poker_session';

const ScrumPoker = () => {
  const { roomId: urlRoomId } = useParams();
  const navigate = useNavigate();
  const [screen, setScreen] = useState(urlRoomId ? 'loading' : 'landing'); // 'landing' | 'loading' | 'room'
  const [roomData, setRoomData] = useState(null);
  const [myUserId, setMyUserId] = useState(null);
  const [myVote, setMyVote] = useState(null);
  const [error, setError] = useState(null);
  const [joinRoomId, setJoinRoomId] = useState(urlRoomId || null);
  const [showLeaveConfirm, setShowLeaveConfirm] = useState(false);
  const myUserIdRef = useRef(null);

  useEffect(() => {
    myUserIdRef.current = myUserId;
  }, [myUserId]);

  // ถ้า URL มี /scrum-poker/:roomId พยายาม rejoin อัตโนมัติ
  useEffect(() => {
    if (!urlRoomId) {
      setScreen('landing');
      setJoinRoomId(null);
      return;
    }
    const session = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
    if (session?.roomId === urlRoomId && session?.userId) {
      handleRejoin(urlRoomId, session.userId);
    } else {
      setScreen('landing');
      setJoinRoomId(urlRoomId);
    }
  }, [urlRoomId]);

  const handleRejoin = async (roomId, userId) => {
    try {
      setError(null);
      const res = await fetch(`${API_BASE}/rejoin`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ roomId, userId }),
      });
      if (!res.ok) throw new Error('ไม่พบห้องหรือ user นี้');
      const data = await res.json();
      setMyUserId(userId);
      myUserIdRef.current = userId;
      setRoomData(data);
      websocketService.connect(data.roomId, handleRoomUpdate);
      setScreen('room');
    } catch (e) {
      setJoinRoomId(roomId);
      setError('Session เดิมหมดอายุ กรุณากรอกชื่อใหม่');
    }
  };

  const handleRoomUpdate = (data) => {
    setRoomData(data);
    if (data.roomStatus === 'voting') {
      const me = data.users?.find(u => u.id === myUserIdRef.current);
      if (me) setMyVote(me.vote || null);
    }
  };

  const handleCreateRoom = async (name) => {
    try {
      setError(null);
      setJoinRoomId(null);
      const res = await fetch(`${API_BASE}/create`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userName: name }),
      });
      if (!res.ok) throw new Error('ไม่สามารถสร้างห้องได้');
      const data = await res.json();
      const me = data.users?.[0];
      setMyUserId(me?.id || null);
      myUserIdRef.current = me?.id || null;
      saveSession(data.roomId, me?.id, me?.name);
      updateRoomUrl(data.roomId);
      setRoomData(data);
      websocketService.connect(data.roomId, handleRoomUpdate);
      setScreen('room');
    } catch (e) {
      setError(e.message);
    }
  };

  const handleJoinRoom = async (roomId, name) => {
    try {
      setError(null);
      const res = await fetch(`${API_BASE}/join`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ roomId, userName: name }),
      });
      if (!res.ok) throw new Error('ไม่พบห้องหรือเข้าร่วมไม่ได้');
      const data = await res.json();
      const me = data.users?.find(u => u.name === name);
      setMyUserId(me?.id || null);
      myUserIdRef.current = me?.id || null;
      saveSession(data.roomId, me?.id, me?.name);
      updateRoomUrl(data.roomId);
      setRoomData(data);
      websocketService.connect(data.roomId, handleRoomUpdate);
      setScreen('room');
    } catch (e) {
      setError(e.message);
    }
  };

  const handleVote = (card) => {
    setMyVote(card);
    websocketService.vote(roomData.roomId, myUserId, card);
  };

  const handleReveal = () => {
    websocketService.revealCards(roomData.roomId);
  };

  const handleReset = () => {
    setMyVote(null);
    websocketService.resetVotes(roomData.roomId);
  };

  const handleLeave = () => {
    setShowLeaveConfirm(true);
  };

  const confirmLeave = async () => {
    if (roomData && myUserId) {
      await websocketService.leaveRoom(roomData.roomId, myUserId);
      websocketService.disconnect();
    }
    localStorage.removeItem(STORAGE_KEY);
    updateRoomUrl(null);
    setScreen('landing');
    setRoomData(null);
    setMyUserId(null);
    setMyVote(null);
    setJoinRoomId(null);
    setShowLeaveConfirm(false);
  };

  const saveSession = (roomId, userId, name) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ roomId, userId, name }));
  };

  const updateRoomUrl = (roomId) => {
    if (roomId) {
      navigate(`/scrum-poker/${roomId}`, { replace: true });
    } else {
      navigate('/scrum-poker', { replace: true });
    }
  };

  const getAnalytics = () => {
    if (!roomData || roomData.roomStatus !== 'revealed') return null;
    const votes = roomData.users?.map(u => u.vote).filter(v => v && !isNaN(v)).map(Number) || [];
    if (votes.length === 0) return null;
    const average = (votes.reduce((a, b) => a + b, 0) / votes.length).toFixed(1);
    const freq = votes.reduce((acc, v) => { acc[v] = (acc[v] || 0) + 1; return acc; }, {});
    const maxFreq = Math.max(...Object.values(freq));
    const modes = Object.keys(freq).filter(k => freq[k] === maxFreq);
    const mode = modes.length > 1 ? '-' : modes[0];
    return { average, mode };
  };

  if (screen === 'loading') {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <span className="material-icons text-4xl text-gray-300 animate-spin">refresh</span>
          <p className="text-sm text-gray-400">กำลังเข้าห้อง...</p>
        </div>
      </div>
    );
  }

  if (screen === 'landing') {
    return (
      <div className="h-full">
        {error && (
          <div className="fixed top-4 right-4 z-50 bg-red-100 border border-red-300 text-red-800 px-4 py-3 rounded-xl shadow text-sm font-medium">
            {error}
          </div>
        )}
        <LandingScreen onCreateRoom={handleCreateRoom} onJoinRoom={handleJoinRoom} initialJoinRoomId={joinRoomId} />
      </div>
    );
  }

  const analytics = getAnalytics();
  const users = roomData?.users || [];
  const roomStatus = roomData?.roomStatus || 'voting';
  const isRevealed = roomStatus === 'revealed';

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="bg-white rounded-2xl p-5 border border-gray-200 shadow-sm flex justify-between items-center">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-xl font-bold text-gray-900">Scrum Poker</h1>
            <span className="text-xs bg-teal-100 text-teal-800 font-semibold px-2.5 py-1 rounded-full border border-teal-200">
              ห้อง: {roomData?.roomId}
            </span>
            <span className={`text-xs font-semibold px-2.5 py-1 rounded-full border ${isRevealed ? 'bg-amber-100 text-amber-800 border-amber-200' : 'bg-emerald-100 text-emerald-800 border-emerald-200'}`}>
              {isRevealed ? 'เปิดการ์ดแล้ว' : 'กำลังโหวต'}
            </span>
          </div>
          <p className="text-sm text-gray-500 mt-1">{users.length} คนในห้อง</p>
        </div>
        <div className="flex items-center gap-3">
          <ShareRoomButton roomId={roomData?.roomId} />
          <button
            onClick={handleLeave}
            className="text-sm text-gray-500 hover:text-red-600 px-3 py-2 rounded-lg hover:bg-red-50 transition cursor-pointer border-0 bg-transparent"
          >
            ออกจากห้อง
          </button>
        </div>
      </div>

      {/* Analytics */}
      {analytics && (
        <AnalyticsCard analytics={analytics} />
      )}

      {/* User Board */}
      <UserBoard users={users} roomStatus={roomStatus} myUserId={myUserId} />

      {/* Voting Controls */}
      {!isRevealed ? (
        <div className="space-y-4">
          <VotingDeck myVote={myVote} onVote={handleVote} />
          <div className="flex justify-center">
            <button
              onClick={handleReveal}
              className="bg-yellow-400 hover:bg-yellow-300 text-slate-900 font-bold px-10 py-3 rounded-xl shadow transition cursor-pointer border-0"
            >
              เปิดการ์ด (Reveal)
            </button>
          </div>
        </div>
      ) : (
        <div className="flex justify-center">
          <button
            onClick={handleReset}
            className="bg-teal-600 hover:bg-teal-500 text-white font-bold px-10 py-3 rounded-xl shadow transition cursor-pointer border-0"
          >
            เริ่มโหวตใหม่
          </button>
        </div>
      )}

      {/* Leave Confirmation Modal */}
      {showLeaveConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-sm mx-4">
            <h3 className="text-lg font-bold text-gray-900 mb-2">ออกจากห้อง?</h3>
            <p className="text-sm text-gray-500 mb-6">
              คุณต้องการออกจากห้องนี้ใช่หรือไม่?
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowLeaveConfirm(false)}
                className="px-4 py-2 rounded-xl text-sm font-semibold text-gray-600 hover:bg-gray-100 transition cursor-pointer border-0 bg-transparent"
              >
                ยกเลิก
              </button>
              <button
                onClick={confirmLeave}
                className="px-4 py-2 rounded-xl text-sm font-semibold bg-red-500 hover:bg-red-600 text-white transition cursor-pointer border-0"
              >
                ออกจากห้อง
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ScrumPoker;
