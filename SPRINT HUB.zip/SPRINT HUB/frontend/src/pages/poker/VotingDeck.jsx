import { DESTRUCT_CARDS } from '../../config';

export default function VotingDeck({ myVote, onVote }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '22px', alignItems: 'center', width: '100%' }}>
      <h3 style={{ fontSize: '20px', fontWeight: '900', color: '#102A31', textAlign: 'center', margin: 0, letterSpacing: '-0.01em' }}>
        เลือกการ์ดเพื่อประเมิน
      </h3>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(80px, 1fr))', gap: '16px', width: '100%', maxWidth: '800px' }}>
        {DESTRUCT_CARDS.map(card => (
          <button
            key={card}
            onClick={() => onVote(card)}
            style={{
              height: '110px',
              borderRadius: '16px',
              fontWeight: '950',
              fontSize: '28px',
              transition: 'all 0.3s',
              border: '2px solid',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              background: 'linear-gradient(180deg, #FFFFFF 0%, #F8FAFC 100%)',
              boxShadow: '0 10px 22px rgba(15,23,42,0.08)',
              cursor: 'pointer',
              ...(myVote === card
                ? {
                    borderColor: '#FFCC00',
                    background: 'linear-gradient(135deg, #FFCC00 0%, #FFF0A3 100%)',
                    color: '#102A31',
                    transform: 'translateY(-8px) scale(1.05)',
                    boxShadow: '0 20px 34px rgba(255,204,0,0.28)'
                  }
                : {
                    borderColor: '#E5E7EB',
                    color: '#31505A'
                  }
              )
            }}
            onMouseEnter={(e) => {
              if (myVote !== card) {
                e.target.style.borderColor = '#FFCC00';
                e.target.style.color = '#005C6E';
                e.target.style.transform = 'translateY(-4px)';
                e.target.style.boxShadow = '0 16px 28px rgba(0,92,110,0.14)';
              }
            }}
            onMouseLeave={(e) => {
              if (myVote !== card) {
                e.target.style.borderColor = '#E5E7EB';
                e.target.style.color = '#31505A';
                e.target.style.transform = 'translateY(0)';
                e.target.style.boxShadow = '0 10px 22px rgba(15,23,42,0.08)';
              }
            }}
          >
            {card}
          </button>
        ))}
      </div>
    </div>
  );
}
