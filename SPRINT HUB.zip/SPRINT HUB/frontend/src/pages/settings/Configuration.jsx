import React, { useState, useEffect } from 'react';

const Configuration = () => {
  const [teamMembers, setTeamMembers] = useState([]);
  const [pointsPerDay, setPointsPerDay] = useState(1.4);
  const [showMultiplierInfo, setShowMultiplierInfo] = useState(false);

  useEffect(() => {
    // TODO: fetch from API
  }, []);

  const handleDeleteMember = (id) => {
    setTeamMembers(teamMembers.filter(member => member.id !== id));
  };

  const handleSaveConfiguration = () => {
    console.log('Saving configuration:', { pointsPerDay, teamMembers });
  };

  return (
    <div className="p-6 space-y-6">
      <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm">
        <h1 className="text-2xl font-bold text-gray-900">ตั้งค่าระบบส่วนกลาง</h1>
        <p className="text-sm text-gray-500 mt-2">จัดการรายชื่อในทีมและสูตรคำนวณคะแนน</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        {/* Team Management */}
        <div className="bg-white rounded-2xl shadow border border-gray-200 overflow-hidden lg:col-span-2">
          <div className="p-5 border-b border-gray-200 flex justify-between items-center bg-gray-50">
            <span className="font-semibold text-gray-900">รายชื่อสมาชิก</span>
            <button className="text-xs bg-yellow-400 hover:bg-yellow-300 active:scale-95 text-slate-900 font-bold px-3 py-1.5 rounded-lg transition-all duration-150 shadow hover:shadow-md flex items-center gap-1 cursor-pointer border-0">
              <span className="material-icons text-xs">add</span>
              <span>เพิ่มสมาชิกใหม่</span>
            </button>
          </div>
          <ul className="divide-y divide-gray-100">
            {teamMembers.length === 0 && (
              <li className="py-12 text-center">
                <span className="material-icons text-4xl text-gray-200 block mb-3">group_add</span>
                <p className="text-gray-400 font-medium text-sm">ยังไม่มีสมาชิกในทีม</p>
                <p className="text-gray-300 text-xs mt-1">กดปุ่ม "เพิ่มสมาชิกใหม่" เพื่อเริ่มต้น</p>
              </li>
            )}
            {teamMembers.map((member) => (
              <li key={member.id} className="p-4 flex justify-between items-center hover:bg-amber-50/30 transition">
                <div className="flex items-center gap-3">
                  <span className="material-icons text-gray-400">account_circle</span>
                  <div>
                    <span className="font-medium block text-gray-900">{member.name}</span>
                    <span className="text-xs text-slate-400">Jira ID: {member.jiraUsername}</span>
                  </div>
                </div>
                <button 
                  onClick={() => handleDeleteMember(member.id)}
                  className="text-gray-400 hover:text-red-500 p-1 rounded-lg hover:bg-red-50 transition cursor-pointer border-0 bg-transparent"
                  title="ลบออกจากทีม"
                >
                  <span className="material-icons text-sm">delete</span>
                </button>
              </li>
            ))}
          </ul>
        </div>

        {/* Point Calculation Settings */}
        <div className="bg-white rounded-2xl shadow border border-gray-200 p-6 space-y-4">
          <h2 className="font-semibold text-gray-900 border-b border-gray-100 pb-2 flex items-center gap-2">
            <span className="material-icons text-amber-500 text-sm">info</span>
            <span>เกณฑ์คะแนน Story Points อ้างอิง</span>
          </h2>
          <div className="flex items-center justify-between bg-gray-50 p-3 rounded-xl border border-gray-200">
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-slate-700">ตัวคูณแต้มต่อวัน (Multiplier)</span>
              <button
                onClick={() => setShowMultiplierInfo(true)}
                className="w-5 h-5 rounded-full bg-gray-200 hover:bg-blue-100 hover:text-blue-600 text-gray-500 text-[11px] font-bold flex items-center justify-center transition cursor-pointer border-0 shrink-0"
                title="ตัวคูณคืออะไร?"
              >
                ?
              </button>
            </div>
            <input
              type="number"
              value={pointsPerDay === 0 ? '' : pointsPerDay}
              placeholder="0"
              onChange={(e) => setPointsPerDay(e.target.value === '' ? 0 : parseFloat(e.target.value) || 0)}
              className="w-12 text-center border border-gray-200 rounded-lg p-1.5 font-bold text-sm bg-white outline-none [-moz-appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
            />
          </div>
          <div className="overflow-hidden border border-gray-200 rounded-xl">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="bg-gray-50 font-semibold text-gray-500 border-b border-gray-200">
                  <th className="p-2">Story Point</th>
                  <th className="p-2">ระยะเวลาที่ใช้จริง</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {[['0 point','แก้ตัวแปร/parameter'],['1 point','ครึ่งวัน หรือน้อยกว่านั้น'],['2 point','1 วัน หรือน้อยกว่านั้น'],['3 point','ประมาณ 1-2 วัน'],['5 point','3 วัน'],['8 point','5 วัน (ครึ่ง sprint)'],['13 point','ทั้ง sprint']].map(([pt, desc]) => (
                  <tr key={pt}>
                    <td className="p-2 font-bold text-blue-600">{pt}</td>
                    <td className="p-2 text-gray-500">{desc}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Save Button */}
      <div className="flex justify-end">
        <button
          onClick={handleSaveConfiguration}
          className="bg-yellow-400 hover:bg-yellow-300 active:scale-95 text-slate-900 font-bold px-6 py-2.5 rounded-xl transition-all duration-150 shadow-md hover:shadow-lg flex items-center gap-2 cursor-pointer border-0"
        >
          <span className="material-icons text-base">save</span>
          <span>บันทึกการตั้งค่า</span>
        </button>
      </div>
      {/* Multiplier Info Modal */}
      {showMultiplierInfo && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden border border-gray-100">
            <div className="px-6 py-4 flex justify-between items-center border-b border-gray-100">
              <div className="flex items-center gap-2">
                <span className="material-icons text-blue-500">calculate</span>
                <p className="font-bold text-gray-900">ตัวคูณ (Multiplier) คืออะไร?</p>
              </div>
              <button
                onClick={() => setShowMultiplierInfo(false)}
                className="text-gray-400 hover:text-gray-600 hover:bg-gray-100 p-1.5 rounded-lg transition cursor-pointer border-0 bg-transparent"
              >
                <span className="material-icons text-xl">close</span>
              </button>
            </div>
            <div className="p-6 space-y-4 text-sm text-gray-700">
              <div className="bg-blue-50 border border-blue-100 rounded-xl p-4">
                <p className="font-bold text-blue-800 mb-1">สูตรพื้นฐาน</p>
                <p className="font-mono text-blue-700 text-base">Available Pts = ManDay × Multiplier</p>
              </div>
              <div className="space-y-2">
                <p className="font-semibold text-gray-800">ค่าเริ่มต้น: <span className="text-blue-600">1 ManDay ≈ 1.4 Points</span></p>
              </div>
              <div className="border-t border-gray-100 pt-3 space-y-2">
                <p className="font-semibold text-gray-800">ปรับตัวคูณเมื่อไหร่?</p>
                <ul className="space-y-1.5 text-gray-500">
                  <li className="flex items-start gap-2"><span className="text-emerald-500 font-bold shrink-0">↑ เพิ่ม</span> ถ้าทีมมี Senior มาก ทำงานได้เร็ว</li>
                  <li className="flex items-start gap-2"><span className="text-red-400 font-bold shrink-0">↓ ลด</span> ถ้ามี overhead สูง เช่น มี meeting เยอะ หรือ Junior มาก</li>
                  <li className="flex items-start gap-2"><span className="text-amber-500 font-bold shrink-0">= คง</span> ถ้าทีมมี velocity เสถียรอยู่แล้ว</li>
                </ul>
              </div>
              <div className="bg-amber-50 border border-amber-100 rounded-xl p-3 text-xs text-amber-800">
                ค่าตัวคูณที่เปลี่ยนจะมีผลกับการคำนวณ Available Pts ใน Capacity Planning ทันที
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Configuration;
