import React, { useState, useEffect, useRef } from 'react';
import { teamMemberApi, configApi, jiraApi } from '../../services/api';

const isEnglishName = (name) => /^[A-Za-z]/.test(name);

const sortByName = (a, b) => {
  const aEng = isEnglishName(a.name);
  const bEng = isEnglishName(b.name);
  if (aEng !== bEng) return aEng ? -1 : 1;
  return a.name.localeCompare(b.name, aEng ? 'en' : 'th');
};

const Configuration = () => {
  const [teamMembers, setTeamMembers] = useState([]);
  const [pointsPerDay, setPointsPerDay] = useState(1.4);
  const [showMultiplierInfo, setShowMultiplierInfo] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingMember, setEditingMember] = useState(null);
  const [formData, setFormData] = useState({ name: '', jiraUsername: '', jiraAccountId: '', role: '' });
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [jiraConfigured, setJiraConfigured] = useState(false);
  const [error, setError] = useState(null);
  const [successMsg, setSuccessMsg] = useState(null);
  const [memberSearch, setMemberSearch] = useState('');
  const [memberToDelete, setMemberToDelete] = useState(null);
  const [isRoleDropdownOpen, setIsRoleDropdownOpen] = useState(false);
  const [selectedSprintOwnerIds, setSelectedSprintOwnerIds] = useState([]);
  const [sprintOwnersLoaded, setSprintOwnersLoaded] = useState(false);
  const [showSprintOwnerSelector, setShowSprintOwnerSelector] = useState(false);
  const [dragId, setDragId] = useState(null);
  const [dragOver, setDragOver] = useState(null);
  const roleDropdownRef = useRef(null);


  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (roleDropdownRef.current && !roleDropdownRef.current.contains(e.target)) {
        setIsRoleDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (!sprintOwnersLoaded) return;
    configApi.updateByKey('sprint_owner_ids', JSON.stringify(selectedSprintOwnerIds)).catch(() => {});
  }, [selectedSprintOwnerIds, sprintOwnersLoaded]);

  const loadData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const [members, config, jiraStatus, sprintOwnersConfig] = await Promise.all([
        teamMemberApi.getAll(),
        configApi.getByKey('points_per_day').catch(() => null),
        jiraApi.getStatus().catch(() => ({ configured: false })),
        configApi.getByKey('sprint_owner_ids').catch(() => null),
      ]);
      setTeamMembers([...members].sort(sortByName));
      if (config) setPointsPerDay(parseFloat(config.value));
      setJiraConfigured(jiraStatus.configured);
      setSelectedSprintOwnerIds(sprintOwnersConfig ? JSON.parse(sprintOwnersConfig.value || '[]') : []);
      setSprintOwnersLoaded(true);
    } catch (e) {
      setError('ไม่สามารถโหลดข้อมูลได้ ตรวจสอบการเชื่อมต่อ Backend');
    } finally {
      setIsLoading(false);
    }
  };

  const handleImportFromJira = async () => {
    setIsImporting(true);
    setError(null);
    try {
      const res = await jiraApi.importMembers();
      await loadData();
      showSuccess(`นำเข้าสมาชิกจาก Jira แล้ว ${res.imported} คน`);
    } catch (e) {
      setError('นำเข้าสมาชิกจาก Jira ไม่สำเร็จ');
    } finally {
      setIsImporting(false);
    }
  };

  const showSuccess = (msg) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(null), 3000);
  };

  const handleOpenAdd = (defaultRole = '') => {
    setEditingMember(null);
    setFormData({ name: '', jiraUsername: '', jiraAccountId: '', role: defaultRole });
    setShowAddModal(true);
  };

  const handleToggleSprintOwner = (id) => {
    setSelectedSprintOwnerIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const handleRemoveSprintOwner = (id) => {
    setSelectedSprintOwnerIds(prev => prev.filter(x => x !== id));
    showSuccess('ลบ Sprint Owner แล้ว');
  };

  const handleDragStart = (id) => { setDragId(id); setDragOver(null); };
  const handleDragEnd = () => { setDragId(null); setDragOver(null); };
  const handleDragOver = (e, id) => {
    e.preventDefault();
    const rect = e.currentTarget.getBoundingClientRect();
    const offset = e.clientY - rect.top;
    const position = offset < rect.height / 2 ? 'before' : 'after';
    setDragOver({ id, position });
  };
  const handleDrop = (e, targetId) => {
    e.preventDefault();
    if (!dragId || dragId === targetId) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const offset = e.clientY - rect.top;
    const position = offset < rect.height / 2 ? 'before' : 'after';
    setSelectedSprintOwnerIds(prev => {
      const ids = prev.filter(x => x !== dragId);
      const idx = ids.indexOf(targetId);
      const insertIdx = position === 'before' ? idx : idx + 1;
      ids.splice(insertIdx, 0, dragId);
      return ids;
    });
    setDragId(null);
    setDragOver(null);
  };

  const handleOpenEdit = (member) => {
    setEditingMember(member);
    setFormData({ name: member.name, jiraUsername: member.jiraUsername || '', jiraAccountId: member.jiraAccountId || '', role: member.role || '' });
    setShowAddModal(true);
  };

  const handleSubmitMember = async (e) => {
    e.preventDefault();
    if (!formData.name.trim()) return;
    try {
      if (editingMember) {
        const updated = await teamMemberApi.update(editingMember.id, formData);
        setTeamMembers(prev => [...prev.map(m => m.id === editingMember.id ? updated : m)].sort(sortByName));
        showSuccess('แก้ไขข้อมูลสมาชิกแล้ว');
      } else {
        const created = await teamMemberApi.create(formData);
        setTeamMembers(prev => [...prev, created].sort(sortByName));
        showSuccess('เพิ่มสมาชิกใหม่แล้ว');
      }
      setShowAddModal(false);
    } catch (e) {
      setError('บันทึกข้อมูลไม่สำเร็จ');
    }
  };

  const handleDeleteMember = (member) => {
    setMemberToDelete(member);
  };

  const confirmDeleteMember = async () => {
    if (!memberToDelete) return;
    try {
      await teamMemberApi.delete(memberToDelete.id);
      setTeamMembers(prev => prev.filter(m => m.id !== memberToDelete.id));
      showSuccess('ลบสมาชิกแล้ว');
    } catch (e) {
      setError('ลบข้อมูลไม่สำเร็จ');
    } finally {
      setMemberToDelete(null);
    }
  };

  const handleSaveConfiguration = async () => {
    setIsSaving(true);
    setError(null);
    try {
      await configApi.updateByKey('points_per_day', pointsPerDay);
      showSuccess('บันทึกการตั้งค่าแล้ว');
    } catch (e) {
      setError('บันทึกไม่สำเร็จ');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm">
        <h1 className="text-2xl font-bold text-gray-900">ตั้งค่าระบบส่วนกลาง</h1>
        <p className="text-sm text-gray-500 mt-2">จัดการรายชื่อในทีมและสูตรคำนวณคะแนน</p>
      </div>

      {/* Error Banner */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-2xl px-5 py-4 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="material-icons text-red-400">error_outline</span>
            <p className="text-sm font-semibold text-red-700">{error}</p>
          </div>
          <button onClick={() => setError(null)} className="text-red-300 hover:text-red-500 border-0 bg-transparent cursor-pointer">
            <span className="material-icons text-lg">close</span>
          </button>
        </div>
      )}

      {/* Success Banner */}
      {successMsg && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-2xl px-5 py-4 flex items-center gap-3">
          <span className="material-icons text-emerald-500">check_circle</span>
          <p className="text-sm font-semibold text-emerald-700">{successMsg}</p>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        {/* Team Management */}
        <div className="bg-white rounded-2xl shadow border border-gray-200 overflow-hidden lg:col-span-2">
          <div className="p-5 border-b border-gray-200 flex justify-between items-center bg-gray-50 flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-gray-900">รายชื่อสมาชิก</span>
              <span className="text-xs bg-gray-200 text-gray-600 px-2 py-0.5 rounded-full font-medium">{teamMembers.length} คน</span>
            </div>
            <div className="flex items-center gap-2">
              {jiraConfigured && (
                <button
                  onClick={handleImportFromJira}
                  disabled={isImporting}
                  className="text-xs bg-blue-500 hover:bg-blue-400 active:scale-95 disabled:opacity-60 text-white font-bold px-3 py-1.5 rounded-lg transition-all duration-150 shadow hover:shadow-md flex items-center gap-1 cursor-pointer border-0"
                >
                  <span className={`material-icons text-xs ${isImporting ? 'animate-spin' : ''}`}>{isImporting ? 'refresh' : 'download'}</span>
                  <span>{isImporting ? 'กำลังนำเข้า...' : 'Import จาก Jira'}</span>
                </button>
              )}
              <button
                onClick={handleOpenAdd}
                className="text-xs bg-yellow-400 hover:bg-yellow-300 active:scale-95 text-slate-900 font-bold px-3 py-1.5 rounded-lg transition-all duration-150 shadow hover:shadow-md flex items-center gap-1 cursor-pointer border-0"
              >
                <span className="material-icons text-xs">add</span>
                <span>เพิ่มสมาชิกใหม่</span>
              </button>
            </div>
          </div>

          <div className="px-4 py-2 border-b border-gray-100">
            <div className="flex items-center gap-2 bg-gray-50 rounded-lg px-3 py-1.5 border border-gray-200">
              <span className="material-icons text-gray-400 text-sm">search</span>
              <input
                type="text"
                placeholder="ค้นหาชื่อสมาชิก..."
                value={memberSearch}
                onChange={(e) => setMemberSearch(e.target.value)}
                className="flex-1 bg-transparent text-sm outline-none text-gray-700 placeholder-gray-400"
              />
              {memberSearch && (
                <button onClick={() => setMemberSearch('')} className="text-gray-400 hover:text-gray-600 cursor-pointer border-0 bg-transparent p-0">
                  <span className="material-icons text-sm">close</span>
                </button>
              )}
            </div>
          </div>

          {isLoading ? (
            <div className="py-12 flex flex-col items-center gap-3">
              <span className="material-icons text-4xl text-gray-300 animate-spin">refresh</span>
              <p className="text-sm text-gray-400">กำลังโหลด...</p>
            </div>
          ) : (
            <ul className="divide-y divide-gray-100">
              {teamMembers.length === 0 && (
                <li className="py-12 text-center">
                  <span className="material-icons text-4xl text-gray-200 block mb-3">group_add</span>
                  <p className="text-gray-400 font-medium text-sm">ยังไม่มีสมาชิกในทีม</p>
                  <p className="text-gray-300 text-xs mt-1">กดปุ่ม "เพิ่มสมาชิกใหม่" เพื่อเริ่มต้น</p>
                </li>
              )}
              {teamMembers.filter(m => m.name.toLowerCase().includes(memberSearch.toLowerCase())).map((member) => (
                <li key={member.id} className="p-4 flex justify-between items-center hover:bg-amber-50/30 transition">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-slate-700 text-white flex items-center justify-center text-xs font-bold shrink-0">
                      {member.name.split(' ').map(w => w[0]).slice(0, 2).join('')}
                    </div>
                    <div>
                      <span className="font-medium block text-gray-900">{member.name}</span>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs text-slate-400">{member.jiraUsername ? `Jira: ${member.jiraUsername}` : 'ยังไม่มี Jira Username'}</span>
                        {member.role && (
                          <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${member.role === 'Product Owner' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'}`}>
                            {member.role}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleOpenEdit(member)}
                      className="text-gray-400 hover:text-blue-500 p-1.5 rounded-lg hover:bg-blue-50 transition cursor-pointer border-0 bg-transparent"
                      title="แก้ไข"
                    >
                      <span className="material-icons text-sm">edit</span>
                    </button>
                    <button
                      onClick={() => handleDeleteMember(member)}
                      className="text-gray-400 hover:text-red-500 p-1.5 rounded-lg hover:bg-red-50 transition cursor-pointer border-0 bg-transparent"
                      title="ลบออกจากทีม"
                    >
                      <span className="material-icons text-sm">delete</span>
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="lg:col-span-1 space-y-6">
        {/* Point Calculation Settings */}
        <div className="bg-white rounded-2xl shadow border border-gray-200 p-6 space-y-4">
          <h2 className="font-semibold text-gray-900 border-b border-gray-100 pb-2 flex items-center gap-2">
            <span className="material-icons text-amber-500 text-sm">info</span>
            <span>เกณฑ์คะแนน Story Points อ้างอิง</span>
          </h2>
          <div className="flex items-center justify-between bg-gray-50 p-3 rounded-xl border border-gray-200">
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-slate-700">ตัวคูณแต้มต่อวัน (Multiplier)</span>
              <button
                onClick={() => setShowMultiplierInfo(true)}
                className="w-5 h-5 rounded-full bg-gray-200 hover:bg-blue-100 hover:text-blue-600 text-gray-500 text-[11px] font-bold flex items-center justify-center transition cursor-pointer border-0 shrink-0"
                title="ตัวคูณคืออะไร?"
              >
                ?
              </button>
            </div>
            <input
              type="number"
              value={pointsPerDay === 0 ? '' : pointsPerDay}
              placeholder="0"
              onChange={(e) => setPointsPerDay(e.target.value === '' ? 0 : parseFloat(e.target.value) || 0)}
              className="w-12 text-center border border-gray-200 rounded-lg p-1.5 font-bold text-sm bg-white outline-none [-moz-appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
            />
          </div>
          <div className="overflow-hidden border border-gray-200 rounded-xl">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="bg-gray-50 font-semibold text-gray-500 border-b border-gray-200">
                  <th className="p-2">Story Point</th>
                  <th className="p-2">ระยะเวลาที่ใช้จริง</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {[['0 point','แก้ตัวแปร/parameter'],['1 point','ครึ่งวัน หรือน้อยกว่านั้น'],['2 point','1 วัน หรือน้อยกว่านั้น'],['3 point','ประมาณ 1-2 วัน'],['5 point','3 วัน'],['8 point','5 วัน (ครึ่ง sprint)'],['13 point','ทั้ง sprint']].map(([pt, desc]) => (
                  <tr key={pt}>
                    <td className="p-2 font-bold text-blue-600">{pt}</td>
                    <td className="p-2 text-gray-500">{desc}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="flex justify-end pt-2">
            <button
              onClick={handleSaveConfiguration}
              disabled={isSaving}
              className="bg-yellow-400 hover:bg-yellow-300 active:scale-95 disabled:opacity-60 text-slate-900 font-bold px-6 py-2.5 rounded-xl transition-all duration-150 shadow-md hover:shadow-lg flex items-center gap-2 cursor-pointer border-0"
            >
              <span className={`material-icons text-base ${isSaving ? 'animate-spin' : ''}`}>{isSaving ? 'refresh' : 'save'}</span>
              <span>{isSaving ? 'กำลังบันทึก...' : 'บันทึกการตั้งค่า'}</span>
            </button>
          </div>
        </div>

        {/* Sprint Owner List */}
        <div className="bg-white rounded-2xl shadow border border-gray-200 p-6 space-y-3">
          <div className="flex items-center justify-between border-b border-gray-100 pb-2">
            <h2 className="font-semibold text-gray-900 flex items-center gap-2">
              <span className="material-icons text-purple-500 text-sm">assignment_ind</span>
              <span>รายชื่อ Sprint Owner</span>
            </h2>
            <button
              onClick={() => setShowSprintOwnerSelector(true)}
              className="text-xs bg-purple-500 hover:bg-purple-400 active:scale-95 text-white font-bold px-2 py-1 rounded-lg transition shadow flex items-center gap-1 cursor-pointer border-0"
            >
              <span className="material-icons text-xs">add</span>
              <span>เพิ่ม</span>
            </button>
          </div>
          {(() => {
            const selected = selectedSprintOwnerIds.map(id => teamMembers.find(m => m.id === id)).filter(Boolean);
            return selected.length === 0 ? (
              <p className="text-sm text-gray-400 text-center py-4">ยังไม่มี Sprint Owner</p>
            ) : (
              <ul className="space-y-2 max-h-64 overflow-y-auto pr-1">
                {selected.map((m, idx) => (
                  <li
                    key={m.id}
                    onDragOver={(e) => handleDragOver(e, m.id)}
                    onDragLeave={() => setDragOver(null)}
                    onDrop={(e) => handleDrop(e, m.id)}
                    className={`flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-gray-50 transition group ${dragId === m.id ? 'opacity-40' : ''} border-t-2 ${dragOver?.id === m.id && dragOver?.position === 'before' ? 'border-t-purple-400' : 'border-t-transparent'} border-b-2 ${dragOver?.id === m.id && dragOver?.position === 'after' ? 'border-b-purple-400' : 'border-b-transparent'}`}
                  >
                    <span className="w-6 h-6 rounded-full bg-purple-100 text-purple-700 flex items-center justify-center text-xs font-bold shrink-0">
                      {idx + 1}
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-gray-800 truncate">{m.name}</p>
                      {m.jiraUsername && <p className="text-xs text-gray-400 truncate">{m.jiraUsername}</p>}
                    </div>
                    <span
                      draggable
                      onDragStart={() => handleDragStart(m.id)}
                      onDragEnd={handleDragEnd}
                      className="text-gray-300 hover:text-purple-500 cursor-grab active:cursor-grabbing opacity-0 group-hover:opacity-100 transition"
                      title="ลากเพื่อสลับตำแหน่ง"
                    >
                      <span className="material-icons text-base">drag_handle</span>
                    </span>
                    <button
                      onClick={() => handleRemoveSprintOwner(m.id)}
                      className="opacity-0 group-hover:opacity-100 text-gray-400 hover:text-red-500 transition cursor-pointer border-0 bg-transparent p-1"
                      title="ลบ"
                    >
                      <span className="material-icons text-base">delete</span>
                    </button>
                  </li>
                ))}
              </ul>
            );
          })()}
        </div>
        </div>
      </div>

      {/* Add / Edit Member Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-gray-100">
            <div className="px-6 py-4 flex justify-between items-center border-b border-gray-100">
              <p className="font-bold text-gray-900">{editingMember ? 'แก้ไขข้อมูลสมาชิก' : 'เพิ่มสมาชิกใหม่'}</p>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-gray-400 hover:text-gray-600 hover:bg-gray-100 p-1.5 rounded-lg transition cursor-pointer border-0 bg-transparent"
              >
                <span className="material-icons text-xl">close</span>
              </button>
            </div>
            <form onSubmit={handleSubmitMember} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">ชื่อ-นามสกุล <span className="text-red-500">*</span></label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData(p => ({ ...p, name: e.target.value }))}
                  placeholder="เช่น สมชาย ใจดี"
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-yellow-400 focus:outline-none text-sm"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Jira Username</label>
                <input
                  type="text"
                  value={formData.jiraUsername}
                  onChange={(e) => setFormData(p => ({ ...p, jiraUsername: e.target.value }))}
                  placeholder="เช่น somchai.j"
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-yellow-400 focus:outline-none text-sm"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Jira Account ID</label>
                <input
                  type="text"
                  value={formData.jiraAccountId}
                  onChange={(e) => setFormData(p => ({ ...p, jiraAccountId: e.target.value }))}
                  placeholder="เช่น 6398abc123..."
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-yellow-400 focus:outline-none text-sm"
                />
              </div>
              <div className="relative w-48" ref={roleDropdownRef}>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Role <span className="text-red-500">*</span></label>
                <button
                  type="button"
                  onClick={() => setIsRoleDropdownOpen(o => !o)}
                  className="w-full flex items-center justify-between px-4 py-2.5 text-sm border border-gray-200 rounded-xl bg-white hover:bg-amber-50/50 focus:outline-none focus:ring-1 focus:ring-amber-300 focus:border-amber-300 transition"
                >
                  <span className="text-gray-700">{formData.role || 'ยังไม่ระบุ'}</span>
                  <span className={`material-icons text-gray-400 transition-transform ${isRoleDropdownOpen ? 'rotate-180' : ''}`}>expand_more</span>
                </button>
                {isRoleDropdownOpen && (
                  <div className="absolute z-10 left-0 right-0 mt-1 bg-white border border-gray-200 rounded-xl shadow-lg overflow-hidden">
                    {['', 'Developer', 'Product Owner'].map(role => {
                      const label = role || 'ยังไม่ระบุ';
                      return (
                        <div
                          key={label}
                          onClick={() => { setFormData(p => ({ ...p, role })); setIsRoleDropdownOpen(false); }}
                          className={`px-4 py-2.5 text-sm cursor-pointer transition hover:bg-amber-50 flex items-center justify-between ${formData.role === role ? 'bg-amber-50 text-amber-700 font-semibold' : 'text-gray-700'}`}
                        >
                          <span>{label}</span>
                          {formData.role === role && <span className="material-icons text-sm">check</span>}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-sm font-semibold text-gray-600 hover:bg-gray-100 transition cursor-pointer border-0 bg-transparent"
                >
                  ยกเลิก
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-sm font-bold bg-yellow-400 hover:bg-yellow-300 text-slate-900 transition cursor-pointer border-0 shadow"
                >
                  {editingMember ? 'บันทึกการแก้ไข' : 'เพิ่มสมาชิก'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {memberToDelete && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden border border-gray-100">
            <div className="px-6 py-4 flex items-center gap-3 border-b border-red-100 bg-red-50">
              <p className="font-bold text-gray-900">ยืนยันการลบสมาชิก</p>
            </div>
            <div className="p-6 space-y-4">
              <p className="text-sm text-gray-700">
                ต้องการลบ <span className="font-bold text-gray-900">{memberToDelete.name}</span> ออกจากทีมใช่หรือไม่?
              </p>
              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setMemberToDelete(null)}
                  className="px-4 py-2 rounded-xl text-sm font-semibold text-gray-600 hover:bg-gray-100 transition cursor-pointer border-0 bg-transparent"
                >
                  ยกเลิก
                </button>
                <button
                  type="button"
                  onClick={confirmDeleteMember}
                  className="px-5 py-2 rounded-xl text-sm font-bold bg-red-500 hover:bg-red-400 text-white transition cursor-pointer border-0 shadow"
                >
                  ลบสมาชิก
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Multiplier Info Modal */}
      {showMultiplierInfo && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden border border-gray-100">
            <div className="px-6 py-4 flex justify-between items-center border-b border-gray-100">
              <div className="flex items-center gap-2">
                <span className="material-icons text-blue-500">calculate</span>
                <p className="font-bold text-gray-900">ตัวคูณ (Multiplier) คืออะไร?</p>
              </div>
              <button
                onClick={() => setShowMultiplierInfo(false)}
                className="text-gray-400 hover:text-gray-600 hover:bg-gray-100 p-1.5 rounded-lg transition cursor-pointer border-0 bg-transparent"
              >
                <span className="material-icons text-xl">close</span>
              </button>
            </div>
            <div className="p-6 space-y-4 text-sm text-gray-700">
              <div className="bg-blue-50 border border-blue-100 rounded-xl p-4">
                <p className="font-bold text-blue-800 mb-1">สูตรพื้นฐาน</p>
                <p className="font-mono text-blue-700 text-base">Available Pts = ManDay × Multiplier</p>
              </div>
              <div className="border-t border-gray-100 pt-3 space-y-2">
                <p className="font-semibold text-gray-800">ปรับตัวคูณเมื่อไหร่?</p>
                <ul className="space-y-1.5 text-gray-500">
                  <li className="flex items-start gap-2"><span className="text-emerald-500 font-bold shrink-0">↑ เพิ่ม</span> ถ้าทีมมี Senior มาก ทำงานได้เร็ว</li>
                  <li className="flex items-start gap-2"><span className="text-red-400 font-bold shrink-0">↓ ลด</span> ถ้ามี overhead สูง เช่น มี meeting เยอะ หรือ Junior มาก</li>
                  <li className="flex items-start gap-2"><span className="text-amber-500 font-bold shrink-0">= คง</span> ถ้าทีมมี velocity เสถียรอยู่แล้ว</li>
                </ul>
              </div>
              <div className="bg-amber-50 border border-amber-100 rounded-xl p-3 text-xs text-amber-800">
                ค่าตัวคูณที่เปลี่ยนจะมีผลกับการคำนวณ Available Pts ใน Capacity Planning ทันที
              </div>
            </div>
          </div>
        </div>
      )}
      {showSprintOwnerSelector && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-gray-100">
            <div className="px-6 py-4 flex justify-between items-center border-b border-gray-100">
              <p className="font-bold text-gray-900 flex items-center gap-2">
                <span className="material-icons text-purple-500 text-sm">assignment_ind</span>
                เลือก Sprint Owner
              </p>
              <button
                onClick={() => setShowSprintOwnerSelector(false)}
                className="text-gray-400 hover:text-gray-600 hover:bg-gray-100 p-1.5 rounded-lg transition cursor-pointer border-0 bg-transparent"
              >
                <span className="material-icons text-xl">close</span>
              </button>
            </div>
            <div className="p-6 space-y-2 max-h-96 overflow-y-auto">
              {teamMembers.length === 0 ? (
                <p className="text-sm text-gray-400 text-center py-4">ยังไม่มีสมาชิกในทีม</p>
              ) : (
                teamMembers.map((m) => (
                  <label
                    key={m.id}
                    className="flex items-center gap-3 px-3 py-2 rounded-xl hover:bg-purple-50 cursor-pointer transition border border-transparent hover:border-purple-100"
                  >
                    <input
                      type="checkbox"
                      checked={selectedSprintOwnerIds.includes(m.id)}
                      onChange={() => handleToggleSprintOwner(m.id)}
                      className="w-4 h-4 accent-purple-500 cursor-pointer"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-gray-800 truncate">{m.name}</p>
                      {m.jiraUsername && <p className="text-xs text-gray-400 truncate">{m.jiraUsername}</p>}
                    </div>
                  </label>
                ))
              )}
            </div>
            <div className="px-6 py-4 border-t border-gray-100 flex justify-end">
              <button
                onClick={() => setShowSprintOwnerSelector(false)}
                className="bg-purple-500 hover:bg-purple-400 text-white font-bold px-5 py-2 rounded-xl transition cursor-pointer border-0 shadow"
              >
                บันทึก
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Configuration;
