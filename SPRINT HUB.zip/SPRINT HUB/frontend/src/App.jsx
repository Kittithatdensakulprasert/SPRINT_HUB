import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import CapacityPlanning from './pages/capacity/CapacityPlanning';
import SprintDashboard from './pages/dashboard/SprintDashboard';
import SprintResults from './pages/dashboard/SprintResults';
import ScrumPoker from './pages/poker/ScrumPoker';
import Configuration from './pages/settings/Configuration';

function App() {
  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<Navigate to="/capacity-planning" replace />} />
          <Route path="/capacity-planning" element={<CapacityPlanning />} />
          <Route path="/sprint-dashboard" element={<SprintDashboard />} />
          <Route path="/sprint-dashboard/:sprintId" element={<SprintResults />} />
          <Route path="/configuration" element={<Configuration />} />
          <Route path="/scrum-poker" element={<ScrumPoker />} />
          <Route path="/scrum-poker/:roomId" element={<ScrumPoker />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  );
}

export default App;
