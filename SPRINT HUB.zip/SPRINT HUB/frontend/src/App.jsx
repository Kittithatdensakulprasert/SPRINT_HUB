import { BrowserRouter, Routes, Route, Navigate, useParams } from 'react-router-dom';
import Layout from './components/Layout';
import CapacityPlanning from './pages/capacity/CapacityPlanning';
import SprintDashboard from './pages/dashboard/SprintDashboard';
import SprintResults from './pages/dashboard/SprintResults';
import SprintDistribution from './pages/dashboard/SprintDistribution';
import ScrumPoker from './pages/poker/ScrumPoker';
import Configuration from './pages/settings/Configuration';

const MemberDistributionRedirect = () => {
  const { sprintId } = useParams();
  return <Navigate to={`/sprint-dashboard/distribution/${sprintId}`} replace />;
};

function App() {
  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<Navigate to="/capacity-planning" replace />} />
          <Route path="/capacity-planning" element={<CapacityPlanning />} />
          <Route path="/sprint-dashboard" element={<SprintDashboard />} />
          <Route path="/sprint-dashboard/distribution/:sprintId" element={<SprintDistribution />} />
          <Route path="/sprint-dashboard/member-distribution/:sprintId" element={<MemberDistributionRedirect />} />
          <Route path="/sprint-dashboard/:sprintId" element={<SprintResults />} />
          <Route path="/configuration" element={<Configuration />} />
          <Route path="/scrum-poker" element={<ScrumPoker />} />
          <Route path="/scrum-poker/:roomId" element={<ScrumPoker />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  );
}

export default App;
