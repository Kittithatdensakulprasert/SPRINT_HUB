// config.js - Krungsri Scrum Poker Configuration
export const DESTRUCT_CARDS = ["1", "2", "3", "5", "8", "13", "21"];