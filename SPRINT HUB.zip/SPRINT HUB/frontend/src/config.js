// config.js - Krungsri Scrum Poker Configuration
export const DESTRUCT_CARDS = ["1", "2", "3", "5", "8", "13", "21"];

export const KRUNGSRI_THEME = {
  colors: {
    primary: '#FFCC00',   
    secondary: '#005C6E',  
    accent: '#00A3B1',     
    dark: '#1A1A1A',       
    light: '#F5F5F5',      
  }
};