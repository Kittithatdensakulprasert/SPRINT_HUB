import React from 'react';
import { useNavigate } from 'react-router-dom';

const STORAGE_KEY = 'scrum_poker_session';

const Sidebar = ({ currentPage, isSidebarOpen, setIsSidebarOpen }) => {
  const navigate = useNavigate();
  const menuItems = [
    { id: 'capacity-planning', label: 'วางแผนประจำ Sprint', icon: 'calendar_today', path: '/capacity-planning' },
    { id: 'sprint-dashboard', label: 'แดชบอร์ดสรุปผล', icon: 'dashboard', path: '/sprint-dashboard' },
    { id: 'scrum-poker', label: 'Scrum Poker', icon: 'groups', path: '/scrum-poker' },
    { id: 'configuration', label: 'ตั้งค่าระบบส่วนกลาง', icon: 'settings', path: '/configuration' },
  ];

  const handleNavigate = (item) => {
    if (item.id === 'scrum-poker') {
      const session = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
      if (session?.roomId) {
        navigate(`/scrum-poker/${session.roomId}`);
        return;
      }
    }
    navigate(item.path);
  };

  return (
    <aside
      className={`bg-slate-900 text-white flex flex-col justify-between z-20 shadow-xl shrink-0 transition-all duration-300 overflow-hidden ${
        isSidebarOpen ? 'w-64' : 'w-16'
      }`}
    >
      <div>
        {/* Header */}
        <div className={`flex items-center border-b border-slate-800 h-14 ${
          isSidebarOpen ? 'px-4 justify-between' : 'justify-center'
        }`}>
          {isSidebarOpen && (
            <div className="flex items-center gap-2 px-2 overflow-hidden">
              <span className="material-icons text-yellow-400 shrink-0">equalizer</span>
              <span className="font-bold tracking-wider text-sm whitespace-nowrap">SPRINT HUB</span>
            </div>
          )}
          <button
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-2 hover:bg-slate-800 rounded-xl transition text-slate-400 hover:text-white border-0 cursor-pointer bg-transparent shrink-0"
            title={isSidebarOpen ? 'ย่อเมนู' : 'ขยายเมนู'}
          >
            <span className="material-icons">{isSidebarOpen ? 'menu_open' : 'menu'}</span>
          </button>
        </div>

        {/* Nav */}
        <nav className={`p-2 flex flex-col gap-1 mt-2`}>
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleNavigate(item)}
              title={!isSidebarOpen ? item.label : ''}
              className={`flex items-center rounded-xl font-semibold border-0 cursor-pointer transition-all duration-150 hover:scale-[1.03] active:scale-95 ${
                isSidebarOpen ? 'gap-3 px-4 py-3' : 'justify-center p-3'
              } ${
                item.id === currentPage
                  ? 'bg-yellow-400 text-slate-900'
                  : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <span className="material-icons text-xl shrink-0">{item.icon}</span>
              {isSidebarOpen && <span className="whitespace-nowrap overflow-hidden">{item.label}</span>}
            </button>
          ))}
        </nav>
      </div>

      {isSidebarOpen && (
        <div className="p-4 border-t border-slate-800 text-xs text-slate-600 text-center">
          SPRINT HUB
        </div>
      )}
    </aside>
  );
};

export default Sidebar;
