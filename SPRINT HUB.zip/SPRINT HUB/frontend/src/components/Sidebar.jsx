import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { jiraApi } from '../services/api';

const STORAGE_KEY = 'scrum_poker_session';

const Sidebar = ({ currentPage, isSidebarOpen, setIsSidebarOpen }) => {
  const navigate = useNavigate();
  const [syncState, setSyncState] = useState('idle'); // 'idle' | 'syncing' | 'done' | 'no-updates' | 'error'
  const [progress, setProgress] = useState(0);
  const doneTimerRef = useRef(null);

  useEffect(() => {
    const onDone = (e) => {
      clearTimeout(doneTimerRef.current);
      const success = e?.detail?.success !== false;
      setSyncState(success ? (e?.detail?.skipped ? 'no-updates' : 'done') : 'error');
      doneTimerRef.current = setTimeout(() => setSyncState('idle'), 3000);
    };
    window.addEventListener('jira-sync-done', onDone);
    return () => {
      window.removeEventListener('jira-sync-done', onDone);
      clearTimeout(doneTimerRef.current);
    };
  }, []);

  // แถบ progress ซ้ายไปขวา
  useEffect(() => {
    let interval = null;
    if (syncState === 'syncing') {
      setProgress(0);
      interval = setInterval(() => {
        setProgress((prev) => Math.min(prev + 1, 90));
      }, 120);
    } else if (syncState === 'done' || syncState === 'no-updates' || syncState === 'error') {
      setProgress(100);
    } else {
      setProgress(0);
    }
    return () => clearInterval(interval);
  }, [syncState]);

  const handleForceSync = async () => {
    if (syncState === 'syncing') return;
    setSyncState('syncing');
    try {
      const result = await jiraApi.syncAll();
      window.dispatchEvent(new CustomEvent('jira-sync-done', {
        detail: { success: result?.partial !== true, skipped: result?.skipped === true },
      }));
    } catch {
      window.dispatchEvent(new CustomEvent('jira-sync-done', { detail: { success: false } }));
    }
  };

  const isSyncing = syncState === 'syncing';
  const menuItems = [
    { id: 'capacity-planning', label: 'วางแผนประจำ Sprint', icon: 'calendar_today', path: '/capacity-planning' },
    { id: 'sprint-dashboard', label: 'แดชบอร์ดสรุปผล', icon: 'dashboard', path: '/sprint-dashboard' },
    { id: 'scrum-poker', label: 'Scrum Poker', icon: 'groups', path: '/scrum-poker' },
    { id: 'configuration', label: 'ตั้งค่าระบบส่วนกลาง', icon: 'settings', path: '/configuration' },
  ];

  const handleNavigate = (item) => {
    if (item.id === 'scrum-poker') {
      const session = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
      if (session?.roomId) {
        navigate(`/scrum-poker/${session.roomId}`);
        return;
      }
    }
    navigate(item.path);
  };

  return (
    <aside
      className={`no-print bg-slate-900 text-white flex flex-col justify-between z-20 shadow-xl shrink-0 transition-all duration-300 overflow-hidden ${
        isSidebarOpen ? 'w-64' : 'w-16'
      }`}
    >
      <div>
        {/* Header */}
        <div className={`flex items-center border-b border-slate-800 h-14 ${
          isSidebarOpen ? 'px-4 justify-between' : 'justify-center'
        }`}>
          {isSidebarOpen && (
            <div className="flex items-center gap-2 px-2 overflow-hidden">
              <span className="material-icons text-yellow-400 shrink-0">equalizer</span>
              <span className="font-bold tracking-wider text-sm whitespace-nowrap">SPRINT HUB</span>
            </div>
          )}
          <button
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-2 hover:bg-slate-800 rounded-xl transition text-slate-400 hover:text-white border-0 cursor-pointer bg-transparent shrink-0"
            title={isSidebarOpen ? 'ย่อเมนู' : 'ขยายเมนู'}
          >
            <span className="material-icons">{isSidebarOpen ? 'menu_open' : 'menu'}</span>
          </button>
        </div>

        {/* Nav */}
        <nav className={`p-2 flex flex-col gap-1 mt-2`}>
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleNavigate(item)}
              title={!isSidebarOpen ? item.label : ''}
              className={`flex items-center rounded-xl font-semibold border-0 cursor-pointer transition-all duration-150 hover:scale-[1.03] active:scale-95 ${
                isSidebarOpen ? 'gap-3 px-4 py-3' : 'justify-center p-3'
              } ${
                item.id === currentPage
                  ? 'bg-yellow-400 text-slate-900'
                  : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <span className="material-icons text-xl shrink-0">{item.icon}</span>
              {isSidebarOpen && <span className="whitespace-nowrap overflow-hidden">{item.label}</span>}
            </button>
          ))}
        </nav>
      </div>

      <div className={`p-3 border-t border-slate-800 flex flex-col gap-2`}>
        <button
          onClick={handleForceSync}
          disabled={isSyncing}
          title={!isSidebarOpen ? 'Sync ข้อมูล' : ''}
          className={`flex items-center rounded-xl font-semibold border-0 cursor-pointer transition-all duration-200 ${
            isSidebarOpen ? 'gap-3 px-4 py-2.5' : 'justify-center p-3'
          } ${
            isSyncing
              ? 'bg-slate-700 text-slate-400 cursor-not-allowed'
              : syncState === 'done'
                ? 'bg-emerald-700 text-emerald-200'
                : syncState === 'no-updates'
                  ? 'bg-slate-700 text-slate-300'
                : syncState === 'error'
                  ? 'bg-red-800 text-red-200'
                  : 'bg-slate-800 text-slate-300 hover:bg-emerald-600 hover:text-white active:scale-95'
          }`}
        >
          <span className={`material-icons text-xl shrink-0 ${isSyncing ? 'animate-spin' : ''}`}>
            {syncState === 'done' ? 'check_circle' : syncState === 'no-updates' ? 'info_outline' : syncState === 'error' ? 'error_outline' : 'sync'}
          </span>
          {isSidebarOpen && (
            <span className="whitespace-nowrap overflow-hidden text-sm">
              {isSyncing ? 'กำลัง Sync...' : syncState === 'done' ? 'อัปเดตข้อมูลแล้ว ✓' : syncState === 'no-updates' ? 'ไม่มีข้อมูลใหม่ใน Jira' : syncState === 'error' ? 'Sync ไม่สำเร็จ' : 'Sync ข้อมูล'}
            </span>
          )}
        </button>
        {(syncState !== 'idle') && (
          <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden mt-2">
            <div
              className={`h-full rounded-full transition-all duration-150 ${
                syncState === 'error' ? 'bg-red-500' : 'bg-emerald-500'
              }`}
              style={{ width: `${progress}%` }}
            />
          </div>
        )}
        {isSidebarOpen && (
          <div className="text-xs text-slate-600 text-center py-1">SPRINT HUB</div>
        )}
      </div>
    </aside>
  );
};

export default Sidebar;
