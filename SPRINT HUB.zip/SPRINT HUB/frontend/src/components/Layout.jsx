import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import Sidebar from './Sidebar';

const Layout = ({ children }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const location = useLocation();

  const getCurrentPage = () => {
    const path = location.pathname;
    if (path.startsWith('/capacity-planning')) return 'capacity-planning';
    if (path.startsWith('/sprint-dashboard')) return 'sprint-dashboard';
    if (path.startsWith('/scrum-poker')) return 'scrum-poker';
    if (path.startsWith('/configuration')) return 'configuration';
    return 'capacity-planning';
  };

  return (
    <div id="layout-root" className="bg-gray-50 text-gray-800 h-screen overflow-hidden flex">
      <Sidebar
        currentPage={getCurrentPage()}
        isSidebarOpen={isSidebarOpen}
        setIsSidebarOpen={setIsSidebarOpen}
      />

      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        <div className="flex-1 overflow-y-auto bg-gray-50">
          {children}
        </div>
      </main>
    </div>
  );
};

export default Layout;
