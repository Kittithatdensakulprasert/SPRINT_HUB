import React, { useState, useRef, useEffect } from 'react';

const SprintSelector = ({ value, onChange, sprints }) => {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const activeSprint = sprints.find(s => s.name === value) || sprints[0];

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-3 bg-white border border-gray-200 hover:border-yellow-400 rounded-2xl px-4 py-2.5 shadow-sm transition group cursor-pointer"
      >
        <div className="text-left">
          <p className="text-xs text-gray-400 font-medium leading-none mb-1.5">Sprint ที่เลือก</p>
          <p className="text-sm font-bold text-slate-800 leading-none">{activeSprint?.name}</p>
        </div>
        <span className={`material-icons text-gray-400 text-base transition-transform ${open ? 'rotate-180' : ''}`}>
          expand_more
        </span>
      </button>

      {open && (
        <div className="absolute right-0 top-full mt-2 w-72 bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden z-50">
          {sprints.map((sprint) => (
            <button
              key={sprint.name}
              onClick={() => { onChange(sprint.name); setOpen(false); }}
              className={`w-full flex items-center justify-between px-4 py-3 text-left hover:bg-amber-50 transition border-0 cursor-pointer ${
                sprint.name === value ? 'bg-amber-50' : 'bg-white'
              }`}
            >
              <div>
                <p className={`text-sm font-semibold ${sprint.name === value ? 'text-amber-700' : 'text-gray-800'}`}>
                  {sprint.name}
                </p>
                {sprint.dates && (
                  <p className="text-xs text-gray-400 mt-0.5">{sprint.dates}</p>
                )}
              </div>
              {sprint.name === value && (
                <span className="material-icons text-amber-500 text-base">check_circle</span>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default SprintSelector;
