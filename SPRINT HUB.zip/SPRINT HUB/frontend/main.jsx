import React from 'react';
import ReactDOM from 'react-dom/client';
import './src/index.css';
import App from './src/App.jsx';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
