-- Create database if not exists
CREATE DATABASE IF NOT EXISTS scrum_poker;
USE scrum_poker;

-- ============================================
-- Scrum Poker Tables (Existing)
-- ============================================

-- Create Rooms table
CREATE TABLE IF NOT EXISTS rooms (
    room_id VARCHAR(255) PRIMARY KEY,
    room_status VARCHAR(50) NOT NULL DEFAULT 'voting',
    final_average DECIMAL(10, 2),
    final_mode VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create Room_Members table
CREATE TABLE IF NOT EXISTS room_members (
    user_id VARCHAR(255) PRIMARY KEY,
    room_id VARCHAR(255) NOT NULL,
    user_name VARCHAR(255) NOT NULL,
    vote_value VARCHAR(50),
    is_voted BOOLEAN DEFAULT FALSE,
    is_online BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (room_id) REFERENCES rooms(room_id) ON DELETE CASCADE
);

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_room_members_room_id ON room_members(room_id);

-- ============================================
-- Capacity Planning & Sprint Dashboard Tables (New)
-- ============================================

-- Create Sprints table
CREATE TABLE IF NOT EXISTS sprints (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'planning',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create Team Members table
CREATE TABLE IF NOT EXISTS team_members (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    jira_username VARCHAR(255),
    jira_account_id VARCHAR(255),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create Capacity Planning table
CREATE TABLE IF NOT EXISTS capacity_planning (
    id SERIAL PRIMARY KEY,
    sprint_id INTEGER NOT NULL,
    member_id INTEGER NOT NULL,
    leave_days INTEGER DEFAULT 0,
    reserve_percent DECIMAL(5, 2) DEFAULT 0,
    existing_pts DECIMAL(10, 2) DEFAULT 0,
    available_pts DECIMAL(10, 2) DEFAULT 0,
    acceptable_pts DECIMAL(10, 2) DEFAULT 0,
    final_man_day DECIMAL(10, 2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (sprint_id) REFERENCES sprints(id) ON DELETE CASCADE,
    FOREIGN KEY (member_id) REFERENCES team_members(id) ON DELETE CASCADE
);

-- Create Sprint Results table
CREATE TABLE IF NOT EXISTS sprint_results (
    id SERIAL PRIMARY KEY,
    sprint_id INTEGER NOT NULL,
    member_id INTEGER NOT NULL,
    target_pts DECIMAL(10, 2) DEFAULT 0,
    done_pts DECIMAL(10, 2) DEFAULT 0,
    remaining_pts DECIMAL(10, 2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (sprint_id) REFERENCES sprints(id) ON DELETE CASCADE,
    FOREIGN KEY (member_id) REFERENCES team_members(id) ON DELETE CASCADE
);

-- Create Configuration table
CREATE TABLE IF NOT EXISTS configuration (
    id SERIAL PRIMARY KEY,
    key VARCHAR(255) NOT NULL UNIQUE,
    value TEXT NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create indexes for faster queries
CREATE INDEX IF NOT EXISTS idx_capacity_planning_sprint_id ON capacity_planning(sprint_id);
CREATE INDEX IF NOT EXISTS idx_capacity_planning_member_id ON capacity_planning(member_id);
CREATE INDEX IF NOT EXISTS idx_sprint_results_sprint_id ON sprint_results(sprint_id);
CREATE INDEX IF NOT EXISTS idx_sprint_results_member_id ON sprint_results(member_id);
CREATE INDEX IF NOT EXISTS idx_sprints_status ON sprints(status);
CREATE INDEX IF NOT EXISTS idx_team_members_is_active ON team_members(is_active);

-- Insert default configuration values
INSERT INTO configuration (key, value, description) VALUES
('points_per_day', '2', 'ตัวคูณ Point ต่อวันสำหรับคำนวณ AVAILABLE PTS')
ON CONFLICT (key) DO NOTHING;
