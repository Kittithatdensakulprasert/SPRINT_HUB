package com.krungsri.scrum_poker.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * MemberIssueDistributionEntity
 * เก็บข้อมูลการกระจายงานตามคนใน sprint
 * แต่ละ row = 1 คน × 1 issue type × 1 system ใน sprint หนึ่ง
 */
@Entity
@Table(name = "member_issue_distributions",
    uniqueConstraints = @UniqueConstraint(columnNames = {"sprint_id", "member_account_id", "issue_type", "system_name"}))
public class MemberIssueDistributionEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "sprint_id", nullable = false)
    private Long sprintId;

    // Jira account id ของ member เช่น 557058:... ใช้สำหรับ query live ต่อ
    @Column(name = "member_account_id", nullable = false, length = 200)
    private String memberAccountId;

    // ชื่อ member สำหรับแสดงผล
    @Column(name = "member_name", nullable = false, length = 200)
    private String memberName;

    // ชื่อ issue type จาก Jira หลัง normalize (Functional/Defect) หรือ raw (Task/Story/Bug)
    @Column(name = "issue_type", nullable = false, length = 100)
    private String issueType;

    // ชื่อ system ที่ parse จาก [xxx] ใน title
    @Column(name = "system_name", length = 100)
    private String systemName;

    // จำนวน issues ทั้งหมด
    @Column(name = "total_count")
    private int totalCount = 0;

    // จำนวน issues ที่ done แล้ว
    @Column(name = "done_count")
    private int doneCount = 0;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getSprintId() { return sprintId; }
    public void setSprintId(Long sprintId) { this.sprintId = sprintId; }

    public String getMemberAccountId() { return memberAccountId; }
    public void setMemberAccountId(String memberAccountId) { this.memberAccountId = memberAccountId; }

    public String getMemberName() { return memberName; }
    public void setMemberName(String memberName) { this.memberName = memberName; }

    public String getIssueType() { return issueType; }
    public void setIssueType(String issueType) { this.issueType = issueType; }

    public String getSystemName() { return systemName; }
    public void setSystemName(String systemName) { this.systemName = systemName; }

    public int getTotalCount() { return totalCount; }
    public void setTotalCount(int totalCount) { this.totalCount = totalCount; }

    public int getDoneCount() { return doneCount; }
    public void setDoneCount(int doneCount) { this.doneCount = doneCount; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}
