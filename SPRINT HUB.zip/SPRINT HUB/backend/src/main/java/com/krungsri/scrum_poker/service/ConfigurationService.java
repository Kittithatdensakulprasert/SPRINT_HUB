package com.krungsri.scrum_poker.service;

import com.krungsri.scrum_poker.entity.ConfigurationEntity;
import com.krungsri.scrum_poker.repository.ConfigurationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class ConfigurationService {

    @Autowired
    private ConfigurationRepository configurationRepository;

    public List<ConfigurationEntity> getAllConfigurations() {
        return configurationRepository.findAll();
    }

    public Optional<ConfigurationEntity> getConfigurationById(Long id) {
        return configurationRepository.findById(id);
    }

    public Optional<ConfigurationEntity> getConfigurationByKey(String key) {
        return configurationRepository.findByKey(key);
    }

    public String getConfigurationValue(String key) {
        Optional<ConfigurationEntity> configOpt = configurationRepository.findByKey(key);
        return configOpt.map(ConfigurationEntity::getValue).orElse(null);
    }

    public ConfigurationEntity createConfiguration(String key, String value, String description) {
        ConfigurationEntity config = new ConfigurationEntity();
        config.setKey(key);
        config.setValue(value);
        config.setDescription(description);
        return configurationRepository.save(config);
    }

    public ConfigurationEntity updateConfiguration(Long id, String key, String value, String description) {
        Optional<ConfigurationEntity> configOpt = configurationRepository.findById(id);
        if (configOpt.isPresent()) {
            ConfigurationEntity config = configOpt.get();
            if (key != null) config.setKey(key);
            if (value != null) config.setValue(value);
            if (description != null) config.setDescription(description);
            return configurationRepository.save(config);
        }
        return null;
    }

    public ConfigurationEntity updateConfigurationByKey(String key, String value) {
        Optional<ConfigurationEntity> configOpt = configurationRepository.findByKey(key);
        if (configOpt.isPresent()) {
            ConfigurationEntity config = configOpt.get();
            config.setValue(value);
            return configurationRepository.save(config);
        }
        return null;
    }

    public boolean deleteConfiguration(Long id) {
        if (configurationRepository.existsById(id)) {
            configurationRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
