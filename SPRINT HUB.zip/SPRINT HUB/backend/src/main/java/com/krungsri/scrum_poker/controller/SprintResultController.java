package com.krungsri.scrum_poker.controller;

import com.krungsri.scrum_poker.entity.SprintResultEntity;
import com.krungsri.scrum_poker.service.SprintResultService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/sprint-results")
@CrossOrigin(origins = "*")
public class SprintResultController {

    @Autowired
    private SprintResultService sprintResultService;

    @GetMapping
    public ResponseEntity<List<SprintResultEntity>> getAll() {
        return ResponseEntity.ok(sprintResultService.getAllSprintResults());
    }

    @GetMapping("/sprint/{sprintId}")
    public ResponseEntity<List<SprintResultEntity>> getBySprintId(@PathVariable Long sprintId) {
        return ResponseEntity.ok(sprintResultService.getSprintResultsBySprintId(sprintId));
    }

    @GetMapping("/member/{memberId}")
    public ResponseEntity<List<SprintResultEntity>> getByMemberId(@PathVariable Long memberId) {
        return ResponseEntity.ok(sprintResultService.getSprintResultsByMemberId(memberId));
    }

    @GetMapping("/sprint/{sprintId}/member/{memberId}")
    public ResponseEntity<SprintResultEntity> getBySprintAndMember(
            @PathVariable Long sprintId, @PathVariable Long memberId) {
        return sprintResultService.getSprintResultBySprintAndMember(sprintId, memberId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<SprintResultEntity> createSprintResult(@RequestBody Map<String, Object> request) {
        Long sprintId = Long.valueOf(request.get("sprintId").toString());
        Long memberId = Long.valueOf(request.get("memberId").toString());
        BigDecimal targetPts = request.get("targetPts") != null
                ? new BigDecimal(request.get("targetPts").toString()) : BigDecimal.ZERO;
        BigDecimal donePts = request.get("donePts") != null
                ? new BigDecimal(request.get("donePts").toString()) : BigDecimal.ZERO;
        BigDecimal remainingPts = request.get("remainingPts") != null
                ? new BigDecimal(request.get("remainingPts").toString()) : BigDecimal.ZERO;
        SprintResultEntity result = sprintResultService.createSprintResult(sprintId, memberId, targetPts, donePts, remainingPts);
        return ResponseEntity.ok(result);
    }

    @PostMapping("/batch")
    public ResponseEntity<List<SprintResultEntity>> batchCreateOrUpdate(@RequestBody Map<String, Object> request) {
        Long sprintId = Long.valueOf(request.get("sprintId").toString());

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> members = (List<Map<String, Object>>) request.get("members");

        List<SprintResultEntity> results = members.stream().map(m -> {
            Long memberId = Long.valueOf(m.get("memberId").toString());
            BigDecimal targetPts = m.get("targetPts") != null ? new BigDecimal(m.get("targetPts").toString()) : BigDecimal.ZERO;
            BigDecimal donePts = m.get("donePts") != null ? new BigDecimal(m.get("donePts").toString()) : BigDecimal.ZERO;
            BigDecimal remainingPts = m.get("remainingPts") != null ? new BigDecimal(m.get("remainingPts").toString()) : BigDecimal.ZERO;

            return sprintResultService.getSprintResultBySprintAndMember(sprintId, memberId)
                    .map(existing -> sprintResultService.updateSprintResult(existing.getId(), targetPts, donePts, remainingPts))
                    .orElseGet(() -> sprintResultService.createSprintResult(sprintId, memberId, targetPts, donePts, remainingPts));
        }).toList();

        return ResponseEntity.ok(results);
    }

    @PutMapping("/{id}")
    public ResponseEntity<SprintResultEntity> updateSprintResult(
            @PathVariable Long id, @RequestBody Map<String, Object> request) {
        BigDecimal targetPts = request.get("targetPts") != null
                ? new BigDecimal(request.get("targetPts").toString()) : null;
        BigDecimal donePts = request.get("donePts") != null
                ? new BigDecimal(request.get("donePts").toString()) : null;
        BigDecimal remainingPts = request.get("remainingPts") != null
                ? new BigDecimal(request.get("remainingPts").toString()) : null;
        SprintResultEntity result = sprintResultService.updateSprintResult(id, targetPts, donePts, remainingPts);
        if (result == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(result);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSprintResult(@PathVariable Long id) {
        if (!sprintResultService.deleteSprintResult(id)) return ResponseEntity.notFound().build();
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/sprint/{sprintId}")
    public ResponseEntity<Void> deleteBySprintId(@PathVariable Long sprintId) {
        sprintResultService.deleteSprintResultBySprintId(sprintId);
        return ResponseEntity.noContent().build();
    }
}
