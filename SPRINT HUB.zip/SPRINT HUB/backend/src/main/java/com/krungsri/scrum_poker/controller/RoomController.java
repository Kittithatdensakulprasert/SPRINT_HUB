package com.krungsri.scrum_poker.controller;

import com.krungsri.scrum_poker.model.Room;
import com.krungsri.scrum_poker.service.RoomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/rooms")
@CrossOrigin(origins = "*")
public class RoomController {

    @Autowired
    private RoomService roomService;

    @PostMapping("/create")
    public ResponseEntity<Room> createRoom(@RequestBody Map<String, String> request) {
        String userName = request.get("userName");
        Room room = roomService.createRoom(userName);
        return ResponseEntity.ok(room);
    }

    @PostMapping("/join")
    public ResponseEntity<?> joinRoom(@RequestBody Map<String, String> request) {
        String roomId = request.get("roomId");
        String userName = request.get("userName");
        Room room = roomService.joinRoom(roomId, userName);
        if (room == null) {
            return ResponseEntity.badRequest().body("Room not found");
        }
        return ResponseEntity.ok(room);
    }

    @GetMapping("/{roomId}")
    public ResponseEntity<Room> getRoom(@PathVariable String roomId) {
        Room room = roomService.getRoom(roomId);
        if (room == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(room);
    }

    @PostMapping("/leave")
    public ResponseEntity<Void> leaveRoom(@RequestBody Map<String, String> request) {
        String roomId = request.get("roomId");
        String userId = request.get("userId");
        roomService.leaveRoom(roomId, userId);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/rejoin")
    public ResponseEntity<?> rejoinRoom(@RequestBody Map<String, String> request) {
        String roomId = request.get("roomId");
        String userId = request.get("userId");
        Room room = roomService.rejoinRoom(roomId, userId);
        if (room == null) {
            return ResponseEntity.badRequest().body("Room or user not found");
        }
        return ResponseEntity.ok(room);
    }
}
