package com.krungsri.scrum_poker.controller;

import com.krungsri.scrum_poker.entity.CapacityPlanningEntity;
import com.krungsri.scrum_poker.service.CapacityPlanningService;
import com.krungsri.scrum_poker.service.ConfigurationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/capacity")
@CrossOrigin(origins = "*")
public class CapacityPlanningController {

    @Autowired
    private CapacityPlanningService capacityPlanningService;

    @Autowired
    private ConfigurationService configurationService;

    @GetMapping("/sprint/{sprintId}")
    public ResponseEntity<List<CapacityPlanningEntity>> getBySprintId(@PathVariable Long sprintId) {
        return ResponseEntity.ok(capacityPlanningService.getCapacityPlanningBySprintId(sprintId));
    }

    @GetMapping("/member/{memberId}")
    public ResponseEntity<List<CapacityPlanningEntity>> getByMemberId(@PathVariable Long memberId) {
        return ResponseEntity.ok(capacityPlanningService.getCapacityPlanningByMemberId(memberId));
    }

    @GetMapping("/sprint/{sprintId}/member/{memberId}")
    public ResponseEntity<CapacityPlanningEntity> getBySprintAndMember(
            @PathVariable Long sprintId, @PathVariable Long memberId) {
        return capacityPlanningService.getCapacityPlanningBySprintAndMember(sprintId, memberId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/calculate")
    public ResponseEntity<CapacityPlanningEntity> calculate(@RequestBody Map<String, Object> request) {
        Long sprintId = Long.valueOf(request.get("sprintId").toString());
        Long memberId = Long.valueOf(request.get("memberId").toString());
        Integer leaveDays = request.get("leaveDays") != null ? Integer.valueOf(request.get("leaveDays").toString()) : 0;
        BigDecimal reservePercent = request.get("reservePercent") != null
                ? new BigDecimal(request.get("reservePercent").toString()) : BigDecimal.ZERO;
        BigDecimal existingPts = request.get("existingPts") != null
                ? new BigDecimal(request.get("existingPts").toString()) : BigDecimal.ZERO;

        String multiplierStr = configurationService.getConfigurationValue("points_per_day");
        BigDecimal pointsPerDay = multiplierStr != null ? new BigDecimal(multiplierStr) : BigDecimal.valueOf(2);

        CapacityPlanningEntity result = capacityPlanningService.calculateCapacity(
                sprintId, memberId, leaveDays, reservePercent, existingPts, pointsPerDay);
        return ResponseEntity.ok(result);
    }

    @PostMapping("/batch-calculate")
    public ResponseEntity<List<CapacityPlanningEntity>> batchCalculate(@RequestBody Map<String, Object> request) {
        Long sprintId = Long.valueOf(request.get("sprintId").toString());
        String multiplierStr = configurationService.getConfigurationValue("points_per_day");
        BigDecimal pointsPerDay = multiplierStr != null ? new BigDecimal(multiplierStr) : BigDecimal.valueOf(2);

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> members = (List<Map<String, Object>>) request.get("members");

        List<CapacityPlanningEntity> results = members.stream().map(m -> {
            Long memberId = Long.valueOf(m.get("memberId").toString());
            Integer leaveDays = m.get("leaveDays") != null ? Integer.valueOf(m.get("leaveDays").toString()) : 0;
            BigDecimal reservePercent = m.get("reservePercent") != null
                    ? new BigDecimal(m.get("reservePercent").toString()) : BigDecimal.ZERO;
            BigDecimal existingPts = m.get("existingPts") != null
                    ? new BigDecimal(m.get("existingPts").toString()) : BigDecimal.ZERO;
            return capacityPlanningService.calculateCapacity(sprintId, memberId, leaveDays, reservePercent, existingPts, pointsPerDay);
        }).toList();

        return ResponseEntity.ok(results);
    }

    @PutMapping("/{id}")
    public ResponseEntity<CapacityPlanningEntity> updateCapacityPlanning(
            @PathVariable Long id, @RequestBody Map<String, Object> request) {
        Integer leaveDays = request.get("leaveDays") != null ? Integer.valueOf(request.get("leaveDays").toString()) : null;
        BigDecimal reservePercent = request.get("reservePercent") != null
                ? new BigDecimal(request.get("reservePercent").toString()) : null;
        BigDecimal existingPts = request.get("existingPts") != null
                ? new BigDecimal(request.get("existingPts").toString()) : null;
        BigDecimal availablePts = request.get("availablePts") != null
                ? new BigDecimal(request.get("availablePts").toString()) : null;
        BigDecimal acceptablePts = request.get("acceptablePts") != null
                ? new BigDecimal(request.get("acceptablePts").toString()) : null;
        BigDecimal finalManDay = request.get("finalManDay") != null
                ? new BigDecimal(request.get("finalManDay").toString()) : null;

        CapacityPlanningEntity result = capacityPlanningService.updateCapacityPlanning(
                id, leaveDays, reservePercent, existingPts, availablePts, acceptablePts, finalManDay);
        if (result == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(result);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCapacityPlanning(@PathVariable Long id) {
        if (!capacityPlanningService.deleteCapacityPlanning(id)) return ResponseEntity.notFound().build();
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/sprint/{sprintId}")
    public ResponseEntity<Void> deleteBySprintId(@PathVariable Long sprintId) {
        capacityPlanningService.deleteCapacityPlanningBySprintId(sprintId);
        return ResponseEntity.noContent().build();
    }
}
