package com.krungsri.scrum_poker.model;

import java.util.ArrayList;
import java.util.List;

public class Room {
    private String roomId;
    private String roomStatus; // 'voting' or 'revealed'
    private List<User> users;
    
    public Room() {
        this.users = new ArrayList<>();
    }
    
    public Room(String roomId) {
        this.roomId = roomId;
        this.roomStatus = "voting";
        this.users = new ArrayList<>();
    }
    
    public Room(String roomId, String roomStatus, List<User> users) {
        this.roomId = roomId;
        this.roomStatus = roomStatus;
        this.users = users;
    }
    
    public String getRoomId() {
        return roomId;
    }
    
    public void setRoomId(String roomId) {
        this.roomId = roomId;
    }
    
    public String getRoomStatus() {
        return roomStatus;
    }
    
    public void setRoomStatus(String roomStatus) {
        this.roomStatus = roomStatus;
    }
    
    public List<User> getUsers() {
        return users;
    }
    
    public void setUsers(List<User> users) {
        this.users = users;
    }
}
