package com.krungsri.scrum_poker.controller;

import com.krungsri.scrum_poker.entity.ConfigurationEntity;
import com.krungsri.scrum_poker.service.ConfigurationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/configuration")
@CrossOrigin(origins = "*")
public class ConfigurationController {

    @Autowired
    private ConfigurationService configurationService;

    @GetMapping
    public ResponseEntity<List<ConfigurationEntity>> getAllConfigurations() {
        return ResponseEntity.ok(configurationService.getAllConfigurations());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ConfigurationEntity> getConfigurationById(@PathVariable Long id) {
        return configurationService.getConfigurationById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/key/{key}")
    public ResponseEntity<ConfigurationEntity> getConfigurationByKey(@PathVariable String key) {
        return configurationService.getConfigurationByKey(key)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<ConfigurationEntity> createConfiguration(@RequestBody Map<String, String> request) {
        String key = request.get("key");
        String value = request.get("value");
        String description = request.get("description");
        ConfigurationEntity config = configurationService.createConfiguration(key, value, description);
        return ResponseEntity.ok(config);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ConfigurationEntity> updateConfiguration(
            @PathVariable Long id, @RequestBody Map<String, String> request) {
        String key = request.get("key");
        String value = request.get("value");
        String description = request.get("description");
        ConfigurationEntity config = configurationService.updateConfiguration(id, key, value, description);
        if (config == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(config);
    }

    @PutMapping("/key/{key}")
    public ResponseEntity<ConfigurationEntity> updateConfigurationByKey(
            @PathVariable String key, @RequestBody Map<String, String> request) {
        String value = request.get("value");
        ConfigurationEntity config = configurationService.updateConfigurationByKey(key, value);
        if (config == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(config);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteConfiguration(@PathVariable Long id) {
        if (!configurationService.deleteConfiguration(id)) return ResponseEntity.notFound().build();
        return ResponseEntity.noContent().build();
    }
}
