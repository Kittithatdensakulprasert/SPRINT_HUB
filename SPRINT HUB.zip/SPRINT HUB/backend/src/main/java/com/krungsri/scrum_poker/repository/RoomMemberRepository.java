package com.krungsri.scrum_poker.repository;

import com.krungsri.scrum_poker.entity.RoomMemberEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface RoomMemberRepository extends JpaRepository<RoomMemberEntity, String> {
    List<RoomMemberEntity> findByRoomId(String roomId);
    Optional<RoomMemberEntity> findByUserId(String userId);
    void deleteByRoomId(String roomId);
}
