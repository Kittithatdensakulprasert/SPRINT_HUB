package com.krungsri.scrum_poker.controller;

import com.krungsri.scrum_poker.service.RoomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Controller;

import java.util.Map;

@Controller
public class WebSocketController {

    @Autowired
    private RoomService roomService;

    @MessageMapping("/vote")
    public void handleVote(@Payload Map<String, String> payload) {
        String roomId = payload.get("roomId");
        String userId = payload.get("userId");
        String vote = payload.get("vote");
        roomService.vote(roomId, userId, vote);
    }

    @MessageMapping("/reveal")
    public void handleReveal(@Payload Map<String, String> payload) {
        String roomId = payload.get("roomId");
        roomService.revealCards(roomId);
    }

    @MessageMapping("/reset")
    public void handleReset(@Payload Map<String, String> payload) {
        String roomId = payload.get("roomId");
        roomService.resetVotes(roomId);
    }
}
