package com.krungsri.scrum_poker.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * IssueDistributionEntity
 * เก็บข้อมูลการกระจายตัวของ issues ใน sprint แต่ละ sprint
 * แต่ละ row = 1 คู่ (issueType x system) ใน sprint หนึ่ง
 * เช่น sprint=42, issueType=Bug, system=BMM, count=5
 */
@Entity
@Table(name = "issue_distributions",
    uniqueConstraints = @UniqueConstraint(columnNames = {"sprint_id", "issue_type", "system_name"}))
public class IssueDistributionEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "sprint_id", nullable = false)
    private Long sprintId;

    // ชื่อ issue type จาก Jira เช่น Bug, Story, Task
    @Column(name = "issue_type", nullable = false, length = 100)
    private String issueType;

    // ชื่อ system ที่ parse จาก [xxx] ใน title เช่น BMM, QR, EPM
    @Column(name = "system_name", length = 100)
    private String systemName;

    // จำนวน issues ทั้งหมด (รวม done + in progress)
    @Column(name = "total_count")
    private int totalCount = 0;

    // จำนวน issues ที่ done แล้ว
    @Column(name = "done_count")
    private int doneCount = 0;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getSprintId() { return sprintId; }
    public void setSprintId(Long sprintId) { this.sprintId = sprintId; }

    public String getIssueType() { return issueType; }
    public void setIssueType(String issueType) { this.issueType = issueType; }

    public String getSystemName() { return systemName; }
    public void setSystemName(String systemName) { this.systemName = systemName; }

    public int getTotalCount() { return totalCount; }
    public void setTotalCount(int totalCount) { this.totalCount = totalCount; }

    public int getDoneCount() { return doneCount; }
    public void setDoneCount(int doneCount) { this.doneCount = doneCount; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}
