package com.krungsri.scrum_poker.controller;

/**
 * JiraController
 * REST API endpoints ทั้งหมดที่เกี่ยวข้องกับ Jira integration
 *
 * Base path: /api/jira
 *
 * Endpoints สำคัญ:
 * - GET  /api/jira/status                       → ตรวจสอบว่า Jira พร้อมใช้งานหรือไม่
 * - POST /api/jira/config                       → บันทึก Jira config (domain, email, boardId, projectKey)
 * - POST /api/jira/sync/sprints                 → sync sprint list จาก Jira มา DB
 * - POST /api/jira/sync/existing-points/{id}    → ดึง existing points ของ sprint จาก Jira
 * - POST /api/jira/sync/sprint-results/{id}     → sync sprint results ของ sprint จาก Jira
 * - POST /api/jira/sync/sprint-results/all      → sync sprint results ทุก sprint
 * - GET  /api/jira/classify/{sprintId}          → แยก issues ของ sprint เป็น new/existing (debug)
 * - GET  /api/jira/sprint-details/{sprintId}/member/{memberId} → รายละเอียด issue ของคนนั้นใน sprint
 * - GET  /api/jira/members                      → รายชื่อ assignable users จาก Jira
 * - POST /api/jira/import/members               → import สมาชิกจาก Jira มา DB
 *
 * ทุก endpoint (ยกเว้น status) จะตรวจสอบ isJiraConfigured() ก่อน ถ้าไม่พร้อมจะคืน 400
 * ส่วนใหญ่เรียก JiraService แล้วคืนผลลัพธ์เป็น JSON
 */

import com.krungsri.scrum_poker.entity.CapacityPlanningEntity;
import com.krungsri.scrum_poker.entity.ConfigurationEntity;
import com.krungsri.scrum_poker.entity.IssueDistributionEntity;
import com.krungsri.scrum_poker.entity.SprintEntity;
import com.krungsri.scrum_poker.entity.SprintResultEntity;
import com.krungsri.scrum_poker.entity.TeamMemberEntity;
import com.krungsri.scrum_poker.service.ConfigurationService;
import com.krungsri.scrum_poker.service.JiraService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/jira")
@CrossOrigin(origins = "*")
public class JiraController {

    private static final Logger log = LoggerFactory.getLogger(JiraController.class);

    @Autowired
    private JiraService jiraService;

    @Autowired
    private ConfigurationService configurationService;

    @GetMapping("/status")
    public ResponseEntity<Map<String, Object>> getJiraStatus() {
        boolean configured = jiraService.isJiraConfigured();
        Map<String, Object> resp = new java.util.LinkedHashMap<>();
        resp.put("configured", configured);
        resp.put("message", configured ? "Jira พร้อมใช้งาน" : "กรุณาตั้งค่า Jira ก่อน (domain, email, token, boardId, projectKey)");
        resp.put("domain", jiraService.getJiraDomain());
        return ResponseEntity.ok(resp);
    }

    @PostMapping("/config")
    public ResponseEntity<Map<String, String>> saveJiraConfig(@RequestBody Map<String, String> request) {
        String[] keys = {"jira_domain", "jira_email", "jira_board_id", "jira_project_key"};
        String[] fields = {"domain", "email", "boardId", "projectKey"};

        for (int i = 0; i < keys.length; i++) {
            String value = request.get(fields[i]);
            if (value != null && !value.isBlank()) {
                ConfigurationEntity existing = configurationService.getConfigurationByKey(keys[i]).orElse(null);
                if (existing != null) {
                    configurationService.updateConfiguration(existing.getId(), keys[i], value, existing.getDescription());
                } else {
                    configurationService.createConfiguration(keys[i], value, "Jira config: " + keys[i]);
                }
            }
        }
        return ResponseEntity.ok(Map.of("message", "บันทึก Jira config แล้ว"));
    }

    @PostMapping("/sync/sprints")
    public ResponseEntity<?> syncSprints() {
        if (!jiraService.isJiraConfigured()) {
            return ResponseEntity.badRequest().body(Map.of("error", "กรุณาตั้งค่า Jira ก่อน"));
        }
        try {
            List<SprintEntity> synced = jiraService.syncSprints();
            return ResponseEntity.ok(Map.of("synced", synced.size(), "sprints", synced));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/sync/existing-points/{sprintId}")
    public ResponseEntity<?> syncExistingPoints(@PathVariable Long sprintId) {
        if (!jiraService.isJiraConfigured()) {
            return ResponseEntity.badRequest().body(Map.of("error", "กรุณาตั้งค่า Jira ก่อน"));
        }
        try {
            List<CapacityPlanningEntity> results = jiraService.syncExistingPoints(sprintId);
            return ResponseEntity.ok(Map.of("synced", results.size(), "data", results));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/members")
    public ResponseEntity<?> getJiraMembers() {
        if (!jiraService.isJiraConfigured()) {
            return ResponseEntity.badRequest().body(Map.of("error", "กรุณาตั้งค่า Jira ก่อน"));
        }
        try {
            List<Map<String, String>> members = jiraService.getJiraBoardMembers();
            return ResponseEntity.ok(members);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/import/members")
    public ResponseEntity<?> importMembers() {
        if (!jiraService.isJiraConfigured()) {
            return ResponseEntity.badRequest().body(Map.of("error", "กรุณาตั้งค่า Jira ก่อน"));
        }
        try {
            List<TeamMemberEntity> imported = jiraService.importMembersFromJira();
            return ResponseEntity.ok(Map.of("imported", imported.size(), "members", imported));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/sync/sprint-results/{sprintId}")
    public ResponseEntity<?> syncSprintResults(@PathVariable Long sprintId) {
        if (!jiraService.isJiraConfigured()) {
            return ResponseEntity.badRequest().body(Map.of("error", "กรุณาตั้งค่า Jira ก่อน"));
        }
        try {
            List<SprintResultEntity> results = jiraService.syncSprintResults(sprintId);
            return ResponseEntity.ok(Map.of("synced", results.size(), "data", results));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/sync/sprint-results/all")
    public ResponseEntity<?> syncAllSprintResults() {
        if (!jiraService.isJiraConfigured()) {
            return ResponseEntity.badRequest().body(Map.of("error", "กรุณาตั้งค่า Jira ก่อน"));
        }
        try {
            Map<String, Object> result = jiraService.syncAllSprintResults();
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/sync/sprint-results/active-future")
    public ResponseEntity<?> syncActiveFutureSprintResults() {
        if (!jiraService.isJiraConfigured()) {
            return ResponseEntity.badRequest().body(Map.of("error", "กรุณาตั้งค่า Jira ก่อน"));
        }
        try {
            Map<String, Object> result = jiraService.syncActiveFutureSprintResults();
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/classify/{sprintId}")
    public ResponseEntity<?> classifySprintIssues(@PathVariable Long sprintId) {
        if (!jiraService.isJiraConfigured()) {
            return ResponseEntity.badRequest().body(Map.of("error", "กรุณาตั้งค่า Jira ก่อน"));
        }
        try {
            return ResponseEntity.ok(jiraService.classifySprintIssues(sprintId));
        } catch (Exception e) {
            log.error("classifySprintIssues error: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError().body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/sprint-details/{sprintId}/member/{memberId}")
    public ResponseEntity<?> getMemberSprintDetails(@PathVariable Long sprintId, @PathVariable Long memberId) {
        if (!jiraService.isJiraConfigured()) {
            return ResponseEntity.badRequest().body(Map.of("error", "กรุณาตั้งค่า Jira ก่อน"));
        }
        try {
            java.util.Map<String, Object> details = jiraService.getMemberSprintDetails(sprintId, memberId);
            return ResponseEntity.ok(details);
        } catch (Exception e) {
            log.error("getMemberSprintDetails error: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError().body(Map.of("error", e.getMessage()));
        }
    }

    // --- Distribution endpoints ---

    /** sync issue distribution ของ sprint จาก Jira แล้วบันทึกลง DB */
    @PostMapping("/sync/distribution/{sprintId}")
    public ResponseEntity<?> syncDistribution(@PathVariable Long sprintId) {
        if (!jiraService.isJiraConfigured()) {
            return ResponseEntity.badRequest().body(Map.of("error", "กรุณาตั้งค่า Jira ก่อน"));
        }
        try {
            List<IssueDistributionEntity> result = jiraService.syncIssueDistribution(sprintId);
            return ResponseEntity.ok(Map.of("synced", result.size(), "data", result));
        } catch (Exception e) {
            log.error("syncDistribution error: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError().body(Map.of("error", e.getMessage()));
        }
    }

    /** sync issue distribution ของทุก sprint พร้อมกัน */
    @PostMapping("/sync/distribution/all")
    public ResponseEntity<?> syncAllDistribution() {
        if (!jiraService.isJiraConfigured()) {
            return ResponseEntity.badRequest().body(Map.of("error", "กรุณาตั้งค่า Jira ก่อน"));
        }
        try {
            java.util.Map<String, Object> result = jiraService.syncAllDistribution();
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            log.error("syncAllDistribution error: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError().body(Map.of("error", e.getMessage()));
        }
    }

    /** ดึงข้อมูล distribution ของ sprint จาก DB (ไม่ sync ใหม่) */
    @GetMapping("/distribution/{sprintId}")
    public ResponseEntity<?> getDistribution(@PathVariable Long sprintId) {
        try {
            List<IssueDistributionEntity> data = jiraService.getDistribution(sprintId);
            return ResponseEntity.ok(data);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of("error", e.getMessage()));
        }
    }

    /** ดึง issues ของ system ใน sprint จาก Jira แบบ live */
    @GetMapping("/distribution/{sprintId}/system/{systemName}")
    public ResponseEntity<?> getSystemIssues(@PathVariable Long sprintId, @PathVariable String systemName) {
        if (!jiraService.isJiraConfigured()) {
            return ResponseEntity.badRequest().body(Map.of("error", "กรุณาตั้งค่า Jira ก่อน"));
        }
        try {
            java.util.Map<String, Object> result = jiraService.getSystemIssues(sprintId, systemName);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            log.error("getSystemIssues error: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError().body(Map.of("error", e.getMessage()));
        }
    }

    /** ดึงข้อมูล distribution ตามคนใน sprint จาก DB (ไม่ sync ใหม่) */
    @GetMapping("/distribution/{sprintId}/members")
    public ResponseEntity<?> getMemberDistribution(@PathVariable Long sprintId) {
        try {
            var data = jiraService.getMemberDistribution(sprintId);
            return ResponseEntity.ok(data);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of("error", e.getMessage()));
        }
    }

    /** ดึง issues ของ member คนเดียวใน sprint จาก Jira แบบ live */
    @GetMapping("/distribution/{sprintId}/member/{accountId}/issues")
    public ResponseEntity<?> getMemberIssues(@PathVariable Long sprintId, @PathVariable String accountId) {
        if (!jiraService.isJiraConfigured()) {
            return ResponseEntity.badRequest().body(Map.of("error", "กรุณาตั้งค่า Jira ก่อน"));
        }
        try {
            java.util.Map<String, Object> result = jiraService.getMemberIssues(sprintId, accountId);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            log.error("getMemberIssues error: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError().body(Map.of("error", e.getMessage()));
        }
    }

    /** ดึงข้อมูล distribution หลาย sprint สำหรับ trend view */
    @GetMapping("/distribution/trend")
    public ResponseEntity<?> getDistributionTrend(@org.springframework.web.bind.annotation.RequestParam List<Long> sprintIds) {
        try {
            List<IssueDistributionEntity> data = jiraService.getDistributionForSprints(sprintIds);
            return ResponseEntity.ok(data);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/sync/all")
    public ResponseEntity<?> syncAll() {
        if (!jiraService.isJiraConfigured()) {
            return ResponseEntity.badRequest().body(Map.of("error", "กรุณาตั้งค่า Jira ก่อน"));
        }
        try {
            Map<String, Object> result = jiraService.syncAll();
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            log.error("syncAll error: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError().body(Map.of("error", e.getMessage()));
        }
    }
}
