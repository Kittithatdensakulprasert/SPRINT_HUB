package com.krungsri.scrum_poker.controller;

import com.krungsri.scrum_poker.entity.CapacityPlanningEntity;
import com.krungsri.scrum_poker.entity.ConfigurationEntity;
import com.krungsri.scrum_poker.entity.SprintEntity;
import com.krungsri.scrum_poker.entity.SprintResultEntity;
import com.krungsri.scrum_poker.service.ConfigurationService;
import com.krungsri.scrum_poker.service.JiraService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/jira")
@CrossOrigin(origins = "*")
public class JiraController {

    @Autowired
    private JiraService jiraService;

    @Autowired
    private ConfigurationService configurationService;

    // ===================================================================
    // GET /api/jira/status
    // ตรวจสอบว่า Jira config ครบหรือยัง
    // ===================================================================
    @GetMapping("/status")
    public ResponseEntity<Map<String, Object>> getJiraStatus() {
        boolean configured = jiraService.isJiraConfigured();
        return ResponseEntity.ok(Map.of(
                "configured", configured,
                "message", configured ? "Jira พร้อมใช้งาน" : "กรุณาตั้งค่า Jira ก่อน (domain, email, token, boardId, projectKey)"
        ));
    }

    // ===================================================================
    // POST /api/jira/config
    // บันทึก Jira config (domain, email, boardId, projectKey)
    // ⚠️  TOKEN: ไม่รับ apiToken ที่นี่แล้ว — token อ่านจาก env JIRA_API_TOKEN เท่านั้น
    // ===================================================================
    @PostMapping("/config")
    public ResponseEntity<Map<String, String>> saveJiraConfig(@RequestBody Map<String, String> request) {
        String[] keys = {"jira_domain", "jira_email", "jira_board_id", "jira_project_key"};
        String[] fields = {"domain", "email", "boardId", "projectKey"};

        for (int i = 0; i < keys.length; i++) {
            String value = request.get(fields[i]);
            if (value != null && !value.isBlank()) {
                ConfigurationEntity existing = configurationService.getConfigurationByKey(keys[i]).orElse(null);
                if (existing != null) {
                    configurationService.updateConfiguration(existing.getId(), keys[i], value, existing.getDescription());
                } else {
                    configurationService.createConfiguration(keys[i], value, "Jira config: " + keys[i]);
                }
            }
        }
        return ResponseEntity.ok(Map.of("message", "บันทึก Jira config แล้ว"));
    }

    // ===================================================================
    // POST /api/jira/sync/sprints
    // ดึง Sprint list จาก Jira Board → sync เข้า DB
    // ⚠️  TOKEN: ต้องตั้งค่า jira_api_token, jira_domain, jira_board_id ก่อน
    // ===================================================================
    @PostMapping("/sync/sprints")
    public ResponseEntity<?> syncSprints() {
        if (!jiraService.isJiraConfigured()) {
            return ResponseEntity.badRequest().body(Map.of("error", "กรุณาตั้งค่า Jira ก่อน"));
        }
        try {
            List<SprintEntity> synced = jiraService.syncSprints();
            return ResponseEntity.ok(Map.of("synced", synced.size(), "sprints", synced));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of("error", e.getMessage()));
        }
    }

    // ===================================================================
    // POST /api/jira/sync/existing-points/{sprintId}
    // ดึงงานค้างของแต่ละคนใน Sprint นี้ → บันทึก existing_pts ใน capacity_planning
    // ⚠️  TOKEN: ต้องตั้งค่า jira_api_token, jira_project_key ก่อน
    // ===================================================================
    @PostMapping("/sync/existing-points/{sprintId}")
    public ResponseEntity<?> syncExistingPoints(@PathVariable Long sprintId) {
        if (!jiraService.isJiraConfigured()) {
            return ResponseEntity.badRequest().body(Map.of("error", "กรุณาตั้งค่า Jira ก่อน"));
        }
        try {
            List<CapacityPlanningEntity> results = jiraService.syncExistingPoints(sprintId);
            return ResponseEntity.ok(Map.of("synced", results.size(), "data", results));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of("error", e.getMessage()));
        }
    }

    // ===================================================================
    // POST /api/jira/sync/sprint-results/{sprintId}
    // ดึงผลงานเสร็จ/ค้างของแต่ละคน → บันทึกใน sprint_results
    // ⚠️  TOKEN: ต้องตั้งค่า jira_api_token, jira_project_key ก่อน
    // ===================================================================
    @PostMapping("/sync/sprint-results/{sprintId}")
    public ResponseEntity<?> syncSprintResults(@PathVariable Long sprintId) {
        if (!jiraService.isJiraConfigured()) {
            return ResponseEntity.badRequest().body(Map.of("error", "กรุณาตั้งค่า Jira ก่อน"));
        }
        try {
            List<SprintResultEntity> results = jiraService.syncSprintResults(sprintId);
            return ResponseEntity.ok(Map.of("synced", results.size(), "data", results));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of("error", e.getMessage()));
        }
    }
}
