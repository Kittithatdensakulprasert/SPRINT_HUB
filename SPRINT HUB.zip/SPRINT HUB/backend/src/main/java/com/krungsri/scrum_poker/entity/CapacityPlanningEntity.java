package com.krungsri.scrum_poker.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "capacity_planning")
public class CapacityPlanningEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "sprint_id", nullable = false)
    private Long sprintId;

    @Column(name = "member_id", nullable = false)
    private Long memberId;

    @Column(name = "leave_days")
    private Integer leaveDays = 0;

    @Column(name = "day_status", length = 50)
    private String dayStatus = "1,1,1,1,1,1,1,1,1,1";

    @Column(name = "reserve_percent", precision = 5, scale = 2)
    private BigDecimal reservePercent = BigDecimal.ZERO;

    @Column(name = "existing_pts", precision = 10, scale = 2)
    private BigDecimal existingPts = BigDecimal.ZERO;

    @Column(name = "available_pts", precision = 10, scale = 2)
    private BigDecimal availablePts = BigDecimal.ZERO;

    @Column(name = "acceptable_pts", precision = 10, scale = 2)
    private BigDecimal acceptablePts = BigDecimal.ZERO;

    @Column(name = "final_man_day", precision = 10, scale = 2)
    private BigDecimal finalManDay = BigDecimal.ZERO;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getSprintId() {
        return sprintId;
    }

    public void setSprintId(Long sprintId) {
        this.sprintId = sprintId;
    }

    public Long getMemberId() {
        return memberId;
    }

    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }

    public Integer getLeaveDays() {
        return leaveDays;
    }

    public void setLeaveDays(Integer leaveDays) {
        this.leaveDays = leaveDays;
    }

    public String getDayStatus() {
        return dayStatus;
    }

    public void setDayStatus(String dayStatus) {
        this.dayStatus = dayStatus;
    }

    public BigDecimal getReservePercent() {
        return reservePercent;
    }

    public void setReservePercent(BigDecimal reservePercent) {
        this.reservePercent = reservePercent;
    }

    public BigDecimal getExistingPts() {
        return existingPts;
    }

    public void setExistingPts(BigDecimal existingPts) {
        this.existingPts = existingPts;
    }

    public BigDecimal getAvailablePts() {
        return availablePts;
    }

    public void setAvailablePts(BigDecimal availablePts) {
        this.availablePts = availablePts;
    }

    public BigDecimal getAcceptablePts() {
        return acceptablePts;
    }

    public void setAcceptablePts(BigDecimal acceptablePts) {
        this.acceptablePts = acceptablePts;
    }

    public BigDecimal getFinalManDay() {
        return finalManDay;
    }

    public void setFinalManDay(BigDecimal finalManDay) {
        this.finalManDay = finalManDay;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
}
