package com.krungsri.scrum_poker.repository;

import com.krungsri.scrum_poker.entity.SprintEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SprintRepository extends JpaRepository<SprintEntity, Long> {
    List<SprintEntity> findByStatus(String status);
    Optional<SprintEntity> findByName(String name);
    List<SprintEntity> findAllByOrderByStartDateDesc();
}
