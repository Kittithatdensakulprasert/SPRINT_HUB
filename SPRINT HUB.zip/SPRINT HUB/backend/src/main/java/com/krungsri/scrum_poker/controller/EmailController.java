package com.krungsri.scrum_poker.controller;

import com.krungsri.scrum_poker.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/email")
public class EmailController {

    @Autowired
    private EmailService emailService;

    @GetMapping("/status")
    public ResponseEntity<Map<String, Object>> getStatus() {
        return ResponseEntity.ok(Map.of("configured", emailService.isConfigured()));
    }

    @PostMapping("/send-report")
    public ResponseEntity<Map<String, Object>> sendReport(@RequestBody SendReportRequest req) {
        try {
            if (req.getRecipients() == null || req.getRecipients().isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of("success", false, "message", "กรุณาระบุผู้รับอีเมล"));
            }

            String subject = req.getSubject() != null ? req.getSubject() : "สรุปผล Sprint";
            String body = buildEmailBody(req.getSprintName(), req.getBodyText());
            String filename = "sprint-report-" + (req.getSprintName() != null ? req.getSprintName().replaceAll("[^a-zA-Z0-9]", "-") : "report") + ".pdf";

            emailService.sendSprintReportEmail(req.getRecipients(), subject, body, req.getPdfBase64(), filename);

            return ResponseEntity.ok(Map.of("success", true, "message", "ส่งอีเมลสำเร็จ"));
        } catch (Exception e) {
            return ResponseEntity.status(500).body(Map.of("success", false, "message", "ส่งอีเมลไม่สำเร็จ: " + e.getMessage()));
        }
    }

    private String buildEmailBody(String sprintName, String bodyText) {
        String content = bodyText != null ? bodyText : "กรุณาดูรายละเอียดสรุปผล Sprint ในไฟล์แนบ";
        return """
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 24px;">
              <div style="background: linear-gradient(135deg, #6366f1, #8b5cf6); padding: 24px; border-radius: 12px; color: white; margin-bottom: 24px;">
                <h2 style="margin: 0 0 8px 0; font-size: 20px;">📊 Sprint Hub</h2>
                <h3 style="margin: 0; font-size: 16px; opacity: 0.9;">%s</h3>
              </div>
              <p style="color: #374151; line-height: 1.6;">%s</p>
              <p style="color: #6b7280; font-size: 14px; margin-top: 24px;">ไฟล์สรุปผล Sprint แนบมาพร้อมกับอีเมลนี้</p>
              <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 24px 0;" />
              <p style="color: #9ca3af; font-size: 12px;">ส่งโดย Sprint Hub — BAY Agile Team Management</p>
            </div>
            """.formatted(sprintName != null ? sprintName : "สรุปผล Sprint", content);
    }

    public static class SendReportRequest {
        private List<String> recipients;
        private String subject;
        private String sprintName;
        private String bodyText;
        private String pdfBase64;

        public List<String> getRecipients() { return recipients; }
        public void setRecipients(List<String> recipients) { this.recipients = recipients; }
        public String getSubject() { return subject; }
        public void setSubject(String subject) { this.subject = subject; }
        public String getSprintName() { return sprintName; }
        public void setSprintName(String sprintName) { this.sprintName = sprintName; }
        public String getBodyText() { return bodyText; }
        public void setBodyText(String bodyText) { this.bodyText = bodyText; }
        public String getPdfBase64() { return pdfBase64; }
        public void setPdfBase64(String pdfBase64) { this.pdfBase64 = pdfBase64; }
    }
}
