package com.krungsri.scrum_poker.model;

public class User {
    private String id;
    private String name;
    private String vote;
    private boolean voted;

    public User() {
    }

    public User(String id, String name, String vote, boolean voted) {
        this.id = id;
        this.name = name;
        this.vote = vote;
        this.voted = voted;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVote() {
        return vote;
    }

    public void setVote(String vote) {
        this.vote = vote;
    }

    public boolean isVoted() {
        return voted;
    }

    public void setVoted(boolean voted) {
        this.voted = voted;
    }
}
