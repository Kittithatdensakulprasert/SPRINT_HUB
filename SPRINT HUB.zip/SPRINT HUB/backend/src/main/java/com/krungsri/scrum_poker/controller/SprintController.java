package com.krungsri.scrum_poker.controller;

import com.krungsri.scrum_poker.entity.SprintEntity;
import com.krungsri.scrum_poker.service.SprintService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/sprints")
@CrossOrigin(origins = "*")
public class SprintController {

    @Autowired
    private SprintService sprintService;

    @GetMapping
    public ResponseEntity<List<SprintEntity>> getAllSprints() {
        return ResponseEntity.ok(sprintService.getAllSprints());
    }

    @GetMapping("/{id}")
    public ResponseEntity<SprintEntity> getSprintById(@PathVariable Long id) {
        return sprintService.getSprintById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<List<SprintEntity>> getSprintsByStatus(@PathVariable String status) {
        return ResponseEntity.ok(sprintService.getSprintsByStatus(status));
    }

    @PostMapping
    public ResponseEntity<SprintEntity> createSprint(@RequestBody Map<String, String> request) {
        String name = request.get("name");
        LocalDate startDate = LocalDate.parse(request.get("startDate"));
        LocalDate endDate = LocalDate.parse(request.get("endDate"));
        String status = request.getOrDefault("status", "planning");
        SprintEntity sprint = sprintService.createSprint(name, startDate, endDate, status);
        return ResponseEntity.ok(sprint);
    }

    @PutMapping("/{id}")
    public ResponseEntity<SprintEntity> updateSprint(@PathVariable Long id, @RequestBody Map<String, String> request) {
        String name = request.get("name");
        LocalDate startDate = request.get("startDate") != null ? LocalDate.parse(request.get("startDate")) : null;
        LocalDate endDate = request.get("endDate") != null ? LocalDate.parse(request.get("endDate")) : null;
        String status = request.get("status");
        SprintEntity sprint = sprintService.updateSprint(id, name, startDate, endDate, status);
        if (sprint == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(sprint);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSprint(@PathVariable Long id) {
        if (!sprintService.deleteSprint(id)) return ResponseEntity.notFound().build();
        return ResponseEntity.noContent().build();
    }
}
