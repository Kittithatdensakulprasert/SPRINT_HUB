package com.krungsri.scrum_poker.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "sprint_results")
public class SprintResultEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "sprint_id", nullable = false)
    private Long sprintId;

    @Column(name = "member_id", nullable = false)
    private Long memberId;

    @Column(name = "target_pts", precision = 10, scale = 2)
    private BigDecimal targetPts = BigDecimal.ZERO;

    @Column(name = "done_pts", precision = 10, scale = 2)
    private BigDecimal donePts = BigDecimal.ZERO;

    @Column(name = "remaining_pts", precision = 10, scale = 2)
    private BigDecimal remainingPts = BigDecimal.ZERO;

    @Column(name = "existing_pts", precision = 10, scale = 2)
    private BigDecimal existingPts = BigDecimal.ZERO;

    @Column(name = "new_pts", precision = 10, scale = 2)
    private BigDecimal newPts = BigDecimal.ZERO;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getSprintId() {
        return sprintId;
    }

    public void setSprintId(Long sprintId) {
        this.sprintId = sprintId;
    }

    public Long getMemberId() {
        return memberId;
    }

    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }

    public BigDecimal getTargetPts() {
        return targetPts;
    }

    public void setTargetPts(BigDecimal targetPts) {
        this.targetPts = targetPts;
    }

    public BigDecimal getDonePts() {
        return donePts;
    }

    public void setDonePts(BigDecimal donePts) {
        this.donePts = donePts;
    }

    public BigDecimal getRemainingPts() {
        return remainingPts;
    }

    public void setRemainingPts(BigDecimal remainingPts) {
        this.remainingPts = remainingPts;
    }

    public BigDecimal getExistingPts() {
        return existingPts;
    }

    public void setExistingPts(BigDecimal existingPts) {
        this.existingPts = existingPts;
    }

    public BigDecimal getNewPts() {
        return newPts;
    }

    public void setNewPts(BigDecimal newPts) {
        this.newPts = newPts;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
}
