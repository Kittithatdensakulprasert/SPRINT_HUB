package com.krungsri.scrum_poker.repository;

import com.krungsri.scrum_poker.entity.TeamMemberEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TeamMemberRepository extends JpaRepository<TeamMemberEntity, Long> {
    List<TeamMemberEntity> findByIsActiveOrderByNameAsc(Boolean isActive);
    Optional<TeamMemberEntity> findByJiraUsername(String jiraUsername);
    Optional<TeamMemberEntity> findByJiraAccountId(String jiraAccountId);
    List<TeamMemberEntity> findAllByOrderByNameAsc();
}
