package com.krungsri.scrum_poker.service;

import com.krungsri.scrum_poker.entity.RoomEntity;
import com.krungsri.scrum_poker.entity.RoomMemberEntity;
import com.krungsri.scrum_poker.model.Room;
import com.krungsri.scrum_poker.model.User;
import com.krungsri.scrum_poker.repository.RoomMemberRepository;
import com.krungsri.scrum_poker.repository.RoomRepository;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class RoomService {
    private final RoomRepository roomRepository;
    private final RoomMemberRepository roomMemberRepository;
    private final SimpMessagingTemplate messagingTemplate;

    public RoomService(RoomRepository roomRepository, RoomMemberRepository roomMemberRepository, SimpMessagingTemplate messagingTemplate) {
        this.roomRepository = roomRepository;
        this.roomMemberRepository = roomMemberRepository;
        this.messagingTemplate = messagingTemplate;
    }

    @Transactional
    public Room createRoom(String userName) {
        String roomId = String.format("%05d", (int)(Math.random() * 900000) + 100000);

        // Create room entity
        RoomEntity roomEntity = new RoomEntity();
        roomEntity.setRoomId(roomId);
        roomEntity.setRoomStatus("voting");
        roomEntity.setFinalAverage(null);
        roomEntity.setFinalMode(null);
        roomRepository.save(roomEntity);

        // Create user entity
        String userId = UUID.randomUUID().toString();
        RoomMemberEntity userEntity = new RoomMemberEntity();
        userEntity.setUserId(userId);
        userEntity.setRoomId(roomId);
        userEntity.setUserName(userName);
        userEntity.setVoteValue(null);
        userEntity.setIsVoted(false);
        userEntity.setIsOnline(true);
        roomMemberRepository.save(userEntity);

        Room room = convertToRoom(roomEntity, List.of(userEntity));
        broadcastRoomUpdate(roomId);
        return room;
    }

    @Transactional
    public Room joinRoom(String roomId, String userName) {
        RoomEntity roomEntity = roomRepository.findByRoomId(roomId).orElse(null);
        if (roomEntity == null) {
            return null;
        }

        String userId = UUID.randomUUID().toString();
        RoomMemberEntity userEntity = new RoomMemberEntity();
        userEntity.setUserId(userId);
        userEntity.setRoomId(roomId);
        userEntity.setUserName(userName);
        userEntity.setVoteValue(null);
        userEntity.setIsVoted(false);
        userEntity.setIsOnline(true);
        roomMemberRepository.save(userEntity);

        List<RoomMemberEntity> members = roomMemberRepository.findByRoomId(roomId);
        Room room = convertToRoom(roomEntity, members);
        broadcastRoomUpdate(roomId);
        return room;
    }

    public Room getRoom(String roomId) {
        RoomEntity roomEntity = roomRepository.findByRoomId(roomId).orElse(null);
        if (roomEntity == null) {
            return null;
        }
        List<RoomMemberEntity> members = roomMemberRepository.findByRoomId(roomId);
        return convertToRoom(roomEntity, members);
    }

    @Transactional
    public void vote(String roomId, String userId, String vote) {
        RoomMemberEntity userEntity = roomMemberRepository.findByUserId(userId).orElse(null);
        if (userEntity != null && userEntity.getRoomId().equals(roomId)) {
            userEntity.setVoteValue(vote);
            userEntity.setIsVoted(true);
            roomMemberRepository.save(userEntity);
            broadcastRoomUpdate(roomId);
        }
    }

    @Transactional
    public void revealCards(String roomId) {
        RoomEntity roomEntity = roomRepository.findByRoomId(roomId).orElse(null);
        if (roomEntity != null) {
            roomEntity.setRoomStatus("revealed");
            roomRepository.save(roomEntity);
            broadcastRoomUpdate(roomId);
        }
    }

    @Transactional
    public void resetVotes(String roomId) {
        RoomEntity roomEntity = roomRepository.findByRoomId(roomId).orElse(null);
        if (roomEntity != null) {
            roomEntity.setRoomStatus("voting");
            roomEntity.setFinalAverage(null);
            roomEntity.setFinalMode(null);
            roomRepository.save(roomEntity);

            List<RoomMemberEntity> members = roomMemberRepository.findByRoomId(roomId);
            for (RoomMemberEntity member : members) {
                member.setVoteValue(null);
                member.setIsVoted(false);
                roomMemberRepository.save(member);
            }
            broadcastRoomUpdate(roomId);
        }
    }

    @Transactional
    public Room rejoinRoom(String roomId, String userId) {
        RoomEntity roomEntity = roomRepository.findByRoomId(roomId).orElse(null);
        if (roomEntity == null) {
            return null;
        }
        RoomMemberEntity userEntity = roomMemberRepository.findByUserId(userId).orElse(null);
        if (userEntity == null || !userEntity.getRoomId().equals(roomId)) {
            return null;
        }
        userEntity.setIsOnline(true);
        roomMemberRepository.save(userEntity);

        List<RoomMemberEntity> members = roomMemberRepository.findByRoomId(roomId);
        Room room = convertToRoom(roomEntity, members);
        broadcastRoomUpdate(roomId);
        return room;
    }

    @Transactional
    public void leaveRoom(String roomId, String userId) {
        RoomMemberEntity userEntity = roomMemberRepository.findByUserId(userId).orElse(null);
        if (userEntity != null && userEntity.getRoomId().equals(roomId)) {
            userEntity.setIsOnline(false);
            roomMemberRepository.save(userEntity);

            // Check if there are any online users in the room
            List<RoomMemberEntity> members = roomMemberRepository.findByRoomId(roomId);
            boolean hasOnlineUsers = members.stream().anyMatch(m -> m.getIsOnline());

            // If no online users, delete the room
            if (!hasOnlineUsers) {
                roomMemberRepository.deleteByRoomId(roomId);
                roomRepository.deleteByRoomId(roomId);
            } else {
                broadcastRoomUpdate(roomId);
            }
        }
    }

    private void broadcastRoomUpdate(String roomId) {
        Room room = getRoom(roomId);
        if (room != null) {
            messagingTemplate.convertAndSend("/topic/room/" + roomId, room);
        }
    }

    private Room convertToRoom(RoomEntity roomEntity, List<RoomMemberEntity> members) {
        Room room = new Room();
        room.setRoomId(roomEntity.getRoomId());
        room.setRoomStatus(roomEntity.getRoomStatus());
        room.setUsers(members.stream()
            .filter(m -> m.getIsOnline() != null && m.getIsOnline())
            .sorted((m1, m2) -> m1.getCreatedAt().compareTo(m2.getCreatedAt()))
            .map(member -> {
                User user = new User();
                user.setId(member.getUserId());
                user.setName(member.getUserName());
                user.setVote(member.getVoteValue());
                user.setVoted(Boolean.TRUE.equals(member.getIsVoted()));
                return user;
            })
            .collect(Collectors.toList()));
        return room;
    }
}
