package com.krungsri.scrum_poker.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.krungsri.scrum_poker.entity.CapacityPlanningEntity;
import com.krungsri.scrum_poker.entity.SprintEntity;
import com.krungsri.scrum_poker.entity.SprintResultEntity;
import com.krungsri.scrum_poker.entity.TeamMemberEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

@Service
public class JiraService {

    @Value("${jira.api.token:}")
    private String jiraApiToken;

    @Value("${jira.email:}")
    private String jiraEmail;

    @Value("${jira.domain:}")
    private String jiraDomain;

    @Value("${jira.board-id:}")
    private String jiraBoardId;

    @Value("${jira.project-key:}")
    private String jiraProjectKey;

    @Autowired
    private SprintService sprintService;

    @Autowired
    private TeamMemberService teamMemberService;

    @Autowired
    private CapacityPlanningService capacityPlanningService;

    @Autowired
    private SprintResultService sprintResultService;

    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .build();
    private final ObjectMapper objectMapper = new ObjectMapper();

    private String buildAuthHeader() {
        String credentials = jiraEmail + ":" + jiraApiToken;
        return "Basic " + Base64.getEncoder().encodeToString(credentials.getBytes());
    }

    private JsonNode callJiraApi(String url) throws Exception {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .timeout(Duration.ofSeconds(30))
                .header("Authorization", buildAuthHeader())
                .header("Accept", "application/json")
                .GET()
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 200) {
            throw new RuntimeException("Jira API error " + response.statusCode() + ": " + response.body());
        }
        return objectMapper.readTree(response.body());
    }

    private JsonNode callJiraApiPost(String url, String jsonBody) throws Exception {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .timeout(Duration.ofSeconds(30))
                .header("Authorization", buildAuthHeader())
                .header("Accept", "application/json")
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 200) {
            throw new RuntimeException("Jira API error " + response.statusCode() + ": " + response.body());
        }
        return objectMapper.readTree(response.body());
    }

    private String escapeJql(String value) {
        if (value == null) return "";
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private List<JsonNode> searchJqlAllPages(String jql, String[] fields) throws Exception {
        List<JsonNode> allIssues = new ArrayList<>();
        String url = jiraDomain + "/rest/api/3/search/jql";
        String nextPageToken = null;

        do {
            java.util.Map<String, Object> body = new java.util.HashMap<>();
            body.put("jql", jql);
            body.put("fields", java.util.Arrays.asList(fields));
            body.put("maxResults", 100);
            if (nextPageToken != null && !nextPageToken.isEmpty()) {
                body.put("nextPageToken", nextPageToken);
            }
            JsonNode root = callJiraApiPost(url, objectMapper.writeValueAsString(body));
            JsonNode issues = root.get("issues");
            if (issues != null && issues.isArray()) {
                issues.forEach(allIssues::add);
            }
            boolean isLast = root.path("isLast").asBoolean(true);
            nextPageToken = isLast ? null : root.path("nextPageToken").asText(null);
            if (nextPageToken != null && nextPageToken.isEmpty()) nextPageToken = null;
        } while (nextPageToken != null);

        return allIssues;
    }

    public List<SprintEntity> syncSprints() throws Exception {
        List<JsonNode> allSprints = new ArrayList<>();
        int startAt = 0;
        int maxResults = 50;
        boolean isLast = false;

        while (!isLast) {
            String url = jiraDomain + "/rest/agile/1.0/board/" + jiraBoardId
                    + "/sprint?state=active,closed,future&maxResults=" + maxResults + "&startAt=" + startAt;
            JsonNode root = callJiraApi(url);
            JsonNode values = root.get("values");
            if (values == null || !values.isArray() || values.size() == 0) break;
            for (JsonNode s : values) allSprints.add(s);
            isLast = root.path("isLast").asBoolean(true);
            startAt += values.size();
        }

        List<SprintEntity> synced = new ArrayList<>();
        for (JsonNode s : allSprints) {
            String name = s.get("name").asText();
            String state = s.get("state").asText();
            if (!name.matches(jiraProjectKey + " Sprint \\d{4,}.*")) continue;
            LocalDate startDate = s.has("startDate") && !s.get("startDate").isNull()
                    ? LocalDate.parse(s.get("startDate").asText().substring(0, 10)) : LocalDate.now();
            LocalDate endDate = s.has("endDate") && !s.get("endDate").isNull()
                    ? LocalDate.parse(s.get("endDate").asText().substring(0, 10)) : LocalDate.now().plusDays(14);

            Optional<SprintEntity> existing = sprintService.getSprintByName(name);
            SprintEntity sprint;
            if (existing.isPresent()) {
                sprint = sprintService.updateSprint(existing.get().getId(), name, startDate, endDate, state);
            } else {
                sprint = sprintService.createSprint(name, startDate, endDate, state);
            }
            synced.add(sprint);
        }
        return synced;
    }

    public List<CapacityPlanningEntity> syncExistingPoints(Long sprintId) throws Exception {
        List<SprintEntity> closedSprints = sprintService.getSprintsByStatus("closed");
        if (closedSprints.isEmpty()) {
            return new ArrayList<>();
        }
        closedSprints.sort((a, b) -> {
            if (a.getEndDate() == null) return 1;
            if (b.getEndDate() == null) return -1;
            return b.getEndDate().compareTo(a.getEndDate());
        });
        SprintEntity prevSprint = closedSprints.get(0);

        String jql = "project=" + jiraProjectKey + " AND sprint=\"" + escapeJql(prevSprint.getName()) + "\" AND statusCategory != Done AND issueType not in subTaskIssueTypes() AND issueType != Epic";
        List<JsonNode> issues = searchJqlAllPages(jql, new String[]{"assignee", "customfield_10117", "customfield_10513"});

        List<CapacityPlanningEntity> results = new ArrayList<>();
        BigDecimal pointsPerDay = BigDecimal.valueOf(2);

        {
            java.util.Map<String, BigDecimal> pointsByAccountId = new java.util.HashMap<>();
            for (JsonNode issue : issues) {
                JsonNode assignee = issue.path("fields").path("assignee");
                if (assignee.isNull() || assignee.isMissingNode()) continue;
                String accountId = assignee.path("accountId").asText();
                JsonNode spNode = issue.path("fields").path("customfield_10117");
                if (spNode.isNull() || spNode.isMissingNode()) spNode = issue.path("fields").path("customfield_10513");
                BigDecimal pts = spNode.isNull() || spNode.isMissingNode()
                        ? BigDecimal.ZERO : BigDecimal.valueOf(spNode.asDouble());
                pointsByAccountId.merge(accountId, pts, BigDecimal::add);
            }

            for (java.util.Map.Entry<String, BigDecimal> entry : pointsByAccountId.entrySet()) {
                teamMemberService.getTeamMemberByJiraAccountId(entry.getKey()).ifPresent(member -> {
                    try {
                        CapacityPlanningEntity cp = capacityPlanningService.calculateCapacity(
                                sprintId, member.getId(), 0, null, BigDecimal.ZERO, entry.getValue(), pointsPerDay);
                        results.add(cp);
                    } catch (Exception ignored) {}
                });
            }
        }
        return results;
    }

    public List<SprintResultEntity> syncSprintResults(Long sprintId) throws Exception {
        SprintEntity sprint = sprintService.getSprintById(sprintId)
                .orElseThrow(() -> new RuntimeException("Sprint not found: " + sprintId));

        String jql = "project=" + jiraProjectKey + " AND sprint=\"" + escapeJql(sprint.getName()) + "\" AND issueType not in subTaskIssueTypes() AND issueType != Epic";
        List<JsonNode> issues = searchJqlAllPages(jql, new String[]{"assignee", "status"});

        java.util.Map<String, BigDecimal> doneByAccountId = new java.util.HashMap<>();
        java.util.Map<String, BigDecimal> remainingByAccountId = new java.util.HashMap<>();

        {
            for (JsonNode issue : issues) {
                JsonNode assignee = issue.path("fields").path("assignee");
                if (assignee.isNull() || assignee.isMissingNode()) continue;
                String accountId = assignee.path("accountId").asText();
                String statusCategory = issue.path("fields").path("status").path("statusCategory").path("key").asText();

                if ("done".equalsIgnoreCase(statusCategory)) {
                    doneByAccountId.merge(accountId, BigDecimal.ONE, BigDecimal::add);
                } else {
                    remainingByAccountId.merge(accountId, BigDecimal.ONE, BigDecimal::add);
                }
            }
        }

        List<SprintResultEntity> results = new ArrayList<>();
        java.util.Set<String> allAccountIds = new java.util.HashSet<>();
        allAccountIds.addAll(doneByAccountId.keySet());
        allAccountIds.addAll(remainingByAccountId.keySet());

        for (String accountId : allAccountIds) {
            teamMemberService.getTeamMemberByJiraAccountId(accountId).ifPresent(member -> {
                BigDecimal done = doneByAccountId.getOrDefault(accountId, BigDecimal.ZERO);
                BigDecimal remaining = remainingByAccountId.getOrDefault(accountId, BigDecimal.ZERO);
                BigDecimal target = done.add(remaining);

                SprintResultEntity result = sprintResultService.getSprintResultBySprintAndMember(sprintId, member.getId())
                        .map(existing -> sprintResultService.updateSprintResult(existing.getId(), target, done, remaining))
                        .orElseGet(() -> sprintResultService.createSprintResult(sprintId, member.getId(), target, done, remaining));
                results.add(result);
            });
        }
        return results;
    }

    public java.util.Map<String, Object> syncAllSprintResults() throws Exception {
        List<SprintEntity> sprints = sprintService.getAllSprints();
        int syncedSprints = 0;
        int totalResults = 0;
        List<String> errors = new ArrayList<>();

        for (SprintEntity sprint : sprints) {
            try {
                List<SprintResultEntity> results = syncSprintResults(sprint.getId());
                if (!results.isEmpty()) {
                    syncedSprints++;
                    totalResults += results.size();
                }
            } catch (Exception e) {
                errors.add(sprint.getName() + ": " + e.getMessage());
            }
        }

        return java.util.Map.of(
                "syncedSprints", syncedSprints,
                "totalResults", totalResults,
                "errors", errors
        );
    }

    public List<java.util.Map<String, String>> getJiraBoardMembers() throws Exception {
        String url = jiraDomain + "/rest/api/3/user/assignable/multiProjectSearch?projectKeys=" + jiraProjectKey + "&maxResults=100";
        JsonNode root = callJiraApi(url);

        java.util.Map<String, java.util.Map<String, String>> seen = new java.util.LinkedHashMap<>();
        if (root.isArray()) {
            for (JsonNode u : root) {
                String accountId = u.path("accountId").asText();
                String displayName = u.path("displayName").asText();
                String email = u.path("emailAddress").asText("");
                if (accountId.isBlank() || displayName.isBlank()) continue;
                seen.put(accountId, java.util.Map.of(
                    "accountId", accountId,
                    "displayName", displayName,
                    "email", email
                ));
            }
        }
        return new ArrayList<>(seen.values());
    }

    public List<com.krungsri.scrum_poker.entity.TeamMemberEntity> importMembersFromJira() throws Exception {
        String jql = "project=" + jiraProjectKey + " AND sprint in openSprints() AND assignee is not EMPTY";
        List<JsonNode> issues = searchJqlAllPages(jql, new String[]{"assignee"});

        java.util.Map<String, java.util.Map<String, String>> seen = new java.util.LinkedHashMap<>();
        for (JsonNode issue : issues) {
            JsonNode assignee = issue.path("fields").path("assignee");
            if (assignee.isNull() || assignee.isMissingNode()) continue;
            String accountId = assignee.path("accountId").asText();
            String displayName = assignee.path("displayName").asText();
            String email = assignee.path("emailAddress").asText("");
            if (accountId.isBlank() || displayName.isBlank()) continue;
            seen.putIfAbsent(accountId, java.util.Map.of(
                "accountId", accountId, "displayName", displayName, "email", email));
        }

        List<com.krungsri.scrum_poker.entity.TeamMemberEntity> imported = new ArrayList<>();
        for (java.util.Map<String, String> m : seen.values()) {
            String accountId = m.get("accountId");
            String name = m.get("displayName");
            String email = m.get("email");
            String username = email.isBlank() ? name : email.split("@")[0];
            Optional<com.krungsri.scrum_poker.entity.TeamMemberEntity> existing =
                teamMemberService.getTeamMemberByJiraAccountId(accountId);
            if (existing.isEmpty()) {
                imported.add(teamMemberService.createTeamMember(name, username, accountId));
            }
        }
        return imported;
    }

    public java.util.Map<String, Object> getMemberSprintDetails(Long sprintId, Long memberId) throws Exception {
        SprintEntity sprint = sprintService.getSprintById(sprintId)
                .orElseThrow(() -> new RuntimeException("Sprint not found: " + sprintId));
        TeamMemberEntity member = teamMemberService.getTeamMemberById(memberId)
                .orElseThrow(() -> new RuntimeException("Member not found: " + memberId));

        String jql = "project=" + jiraProjectKey
                + " AND sprint=\"" + escapeJql(sprint.getName()) + "\""
                + " AND assignee=\"" + escapeJql(member.getJiraAccountId()) + "\""
                + " AND issueType not in subTaskIssueTypes() AND issueType != Epic";
        List<JsonNode> issues = searchJqlAllPages(jql, new String[]{"summary", "status", "customfield_10117", "customfield_10513"});

        java.util.List<java.util.Map<String, Object>> done = new ArrayList<>();
        java.util.List<java.util.Map<String, Object>> remaining = new ArrayList<>();

        for (JsonNode issue : issues) {
            String key = issue.path("key").asText();
            String summary = issue.path("fields").path("summary").asText();
            String statusCategory = issue.path("fields").path("status").path("statusCategory").path("key").asText();
            JsonNode spNode = issue.path("fields").path("customfield_10117");
            if (spNode.isNull() || spNode.isMissingNode()) spNode = issue.path("fields").path("customfield_10513");
            BigDecimal pts = spNode.isNull() || spNode.isMissingNode()
                    ? BigDecimal.ZERO : BigDecimal.valueOf(spNode.asDouble());

            java.util.Map<String, Object> task = new java.util.HashMap<>();
            task.put("id", key);
            task.put("title", summary);
            task.put("points", pts);
            task.put("status", statusCategory);

            if ("done".equalsIgnoreCase(statusCategory)) {
                done.add(task);
            } else {
                remaining.add(task);
            }
        }

        java.util.Map<String, Object> result = new java.util.HashMap<>();
        result.put("memberId", memberId);
        result.put("memberName", member.getName());
        result.put("sprintId", sprintId);
        result.put("sprintName", sprint.getName());
        result.put("completedTasks", done);
        result.put("remainingTasks", remaining);
        return result;
    }

    public boolean isJiraConfigured() {
        return jiraDomain != null && !jiraDomain.isBlank()
                && jiraEmail != null && !jiraEmail.isBlank()
                && jiraApiToken != null && !jiraApiToken.isBlank()
                && jiraBoardId != null && !jiraBoardId.isBlank()
                && jiraProjectKey != null && !jiraProjectKey.isBlank();
    }
}
