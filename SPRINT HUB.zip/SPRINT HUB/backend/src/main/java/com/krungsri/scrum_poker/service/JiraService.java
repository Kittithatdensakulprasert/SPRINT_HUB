package com.krungsri.scrum_poker.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.krungsri.scrum_poker.entity.CapacityPlanningEntity;
import com.krungsri.scrum_poker.entity.SprintEntity;
import com.krungsri.scrum_poker.entity.SprintResultEntity;
import com.krungsri.scrum_poker.entity.TeamMemberEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.math.BigDecimal;
import java.net.InetSocketAddress;
import java.net.ProxySelector;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

@Service
public class JiraService {

    private static final DateTimeFormatter JIRA_DATE_TIME = new DateTimeFormatterBuilder()
            .appendPattern("yyyy-MM-dd'T'HH:mm:ss")
            .appendFraction(ChronoField.NANO_OF_SECOND, 0, 9, true)
            .appendOffset("+HHMM", "Z")
            .toFormatter();

    @Value("${jira.api.token:}")
    private String jiraApiToken;

    @Value("${jira.email:}")
    private String jiraEmail;

    @Value("${jira.domain:}")
    private String jiraDomain;

    @Value("${jira.board-id:}")
    private String jiraBoardId;

    @Value("${jira.project-key:}")
    private String jiraProjectKey;

    @Value("${jira.proxy.host:}")
    private String proxyHost;

    @Value("${jira.proxy.port:0}")
    private int proxyPort;

    @Autowired
    private SprintService sprintService;

    @Autowired
    private TeamMemberService teamMemberService;

    @Autowired
    private CapacityPlanningService capacityPlanningService;

    @Autowired
    private SprintResultService sprintResultService;

    private HttpClient httpClient;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @PostConstruct
    public void initHttpClient() {
        try {
            SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(null, new TrustManager[]{new X509TrustManager() {
                public void checkClientTrusted(X509Certificate[] chain, String authType) {}
                public void checkServerTrusted(X509Certificate[] chain, String authType) {}
                public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
            }}, null);
            HttpClient.Builder builder = HttpClient.newBuilder()
                    .connectTimeout(Duration.ofSeconds(10))
                    .sslContext(sslContext);
            if (proxyHost != null && !proxyHost.isBlank() && proxyPort > 0 && isProxyReachable(proxyHost, proxyPort)) {
                builder.proxy(ProxySelector.of(new InetSocketAddress(proxyHost, proxyPort)));
                org.slf4j.LoggerFactory.getLogger(JiraService.class).info("Using proxy: {}:{}", proxyHost, proxyPort);
            } else {
                builder.proxy(ProxySelector.getDefault());
                org.slf4j.LoggerFactory.getLogger(JiraService.class).info("Direct connection (no proxy)");
            }
            httpClient = builder.build();
        } catch (Exception e) {
            throw new RuntimeException("Failed to init HttpClient", e);
        }
    }

    private boolean isProxyReachable(String host, int port) {
        try (java.net.Socket socket = new java.net.Socket()) {
            socket.connect(new java.net.InetSocketAddress(host, port), 2000);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private String buildAuthHeader() {
        String credentials = jiraEmail + ":" + jiraApiToken;
        return "Basic " + Base64.getEncoder().encodeToString(credentials.getBytes());
    }

    private JsonNode callJiraApi(String url) throws Exception {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .timeout(Duration.ofSeconds(30))
                .header("Authorization", buildAuthHeader())
                .header("Accept", "application/json")
                .GET()
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 200) {
            throw new RuntimeException("Jira API error " + response.statusCode() + ": " + response.body());
        }
        return objectMapper.readTree(response.body());
    }

    private JsonNode callJiraApiPost(String url, String jsonBody) throws Exception {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .timeout(Duration.ofSeconds(30))
                .header("Authorization", buildAuthHeader())
                .header("Accept", "application/json")
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 200) {
            throw new RuntimeException("Jira API error " + response.statusCode() + ": " + response.body());
        }
        return objectMapper.readTree(response.body());
    }

    private String escapeJql(String value) {
        if (value == null) return "";
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private List<JsonNode> searchJqlAllPages(String jql, String[] fields) throws Exception {
        List<JsonNode> allIssues = new ArrayList<>();
        String url = jiraDomain + "/rest/api/3/search/jql";
        String nextPageToken = null;

        do {
            java.util.Map<String, Object> body = new java.util.HashMap<>();
            body.put("jql", jql);
            body.put("fields", java.util.Arrays.asList(fields));
            body.put("maxResults", 100);
            body.put("expand", "changelog");
            if (nextPageToken != null && !nextPageToken.isEmpty()) {
                body.put("nextPageToken", nextPageToken);
            }
            JsonNode root = callJiraApiPost(url, objectMapper.writeValueAsString(body));
            JsonNode issues = root.get("issues");
            if (issues != null && issues.isArray()) {
                issues.forEach(allIssues::add);
            }
            boolean isLast = root.path("isLast").asBoolean(true);
            nextPageToken = isLast ? null : root.path("nextPageToken").asText(null);
            if (nextPageToken != null && nextPageToken.isEmpty()) nextPageToken = null;
        } while (nextPageToken != null);

        return allIssues;
    }

    public List<SprintEntity> syncSprints() throws Exception {
        List<JsonNode> allSprints = new ArrayList<>();
        int startAt = 0;
        int maxResults = 50;
        boolean isLast = false;

        while (!isLast) {
            String url = jiraDomain + "/rest/agile/1.0/board/" + jiraBoardId
                    + "/sprint?state=active,closed,future&maxResults=" + maxResults + "&startAt=" + startAt;
            JsonNode root = callJiraApi(url);
            JsonNode values = root.get("values");
            if (values == null || !values.isArray() || values.size() == 0) break;
            for (JsonNode s : values) allSprints.add(s);
            isLast = root.path("isLast").asBoolean(true);
            startAt += values.size();
        }

        List<SprintEntity> synced = new ArrayList<>();
        for (JsonNode s : allSprints) {
            String name = s.get("name").asText();
            String state = s.get("state").asText();
            if (!name.matches(jiraProjectKey + " Sprint \\d{4,}.*")) continue;
            LocalDate startDate = s.has("startDate") && !s.get("startDate").isNull()
                    ? LocalDate.parse(s.get("startDate").asText().substring(0, 10)) : LocalDate.now();
            LocalDate endDate = s.has("endDate") && !s.get("endDate").isNull()
                    ? LocalDate.parse(s.get("endDate").asText().substring(0, 10)) : LocalDate.now().plusDays(14);

            Optional<SprintEntity> existing = sprintService.getSprintByName(name);
            SprintEntity sprint;
            if (existing.isPresent()) {
                sprint = sprintService.updateSprint(existing.get().getId(), name, startDate, endDate, state);
            } else {
                sprint = sprintService.createSprint(name, startDate, endDate, state);
            }
            synced.add(sprint);
        }
        return synced;
    }

    public List<CapacityPlanningEntity> syncExistingPoints(Long sprintId) throws Exception {
        List<SprintEntity> closedSprints = sprintService.getSprintsByStatus("closed");
        if (closedSprints.isEmpty()) {
            return new ArrayList<>();
        }
        closedSprints.sort((a, b) -> {
            if (a.getEndDate() == null) return 1;
            if (b.getEndDate() == null) return -1;
            return b.getEndDate().compareTo(a.getEndDate());
        });
        SprintEntity prevSprint = closedSprints.get(0);

        String jql = "project=" + jiraProjectKey + " AND sprint=\"" + escapeJql(prevSprint.getName()) + "\" AND statusCategory != Done AND issueType not in subTaskIssueTypes() AND issueType != Epic";
        List<JsonNode> issues = searchJqlAllPages(jql, new String[]{"assignee", "customfield_10117", "customfield_10513"});

        List<CapacityPlanningEntity> results = new ArrayList<>();
        BigDecimal pointsPerDay = BigDecimal.valueOf(2);

        {
            java.util.Map<String, BigDecimal> pointsByAccountId = new java.util.HashMap<>();
            for (JsonNode issue : issues) {
                JsonNode assignee = issue.path("fields").path("assignee");
                if (assignee.isNull() || assignee.isMissingNode()) continue;
                String accountId = assignee.path("accountId").asText();
                JsonNode spNode = issue.path("fields").path("customfield_10117");
                if (spNode.isNull() || spNode.isMissingNode()) spNode = issue.path("fields").path("customfield_10513");
                BigDecimal pts = spNode.isNull() || spNode.isMissingNode()
                        ? BigDecimal.ZERO : BigDecimal.valueOf(spNode.asDouble());
                pointsByAccountId.merge(accountId, pts, BigDecimal::add);
            }

            for (java.util.Map.Entry<String, BigDecimal> entry : pointsByAccountId.entrySet()) {
                teamMemberService.getTeamMemberByJiraAccountId(entry.getKey()).ifPresent(member -> {
                    try {
                        CapacityPlanningEntity cp = capacityPlanningService.calculateCapacity(
                                sprintId, member.getId(), 0, null, BigDecimal.ZERO, entry.getValue(), pointsPerDay);
                        results.add(cp);
                    } catch (Exception ignored) {}
                });
            }
        }
        return results;
    }

    private double getStoryPoints(JsonNode issue) {
        JsonNode sp = issue.path("fields").path("customfield_10117");
        if (!sp.isNull() && !sp.isMissingNode() && sp.isNumber()) return sp.asDouble();
        sp = issue.path("fields").path("customfield_10513");
        if (!sp.isNull() && !sp.isMissingNode() && sp.isNumber()) return sp.asDouble();
        return 0.0;
    }

    public List<SprintResultEntity> syncSprintResults(Long sprintId) throws Exception {
        SprintEntity sprint = sprintService.getSprintById(sprintId)
                .orElseThrow(() -> new RuntimeException("Sprint not found: " + sprintId));

        LocalDate sprintStartDate = sprint.getStartDate();
        String jql = "project=" + jiraProjectKey + " AND sprint=\"" + escapeJql(sprint.getName()) + "\" AND issueType not in subTaskIssueTypes() AND issueType != Epic";
        List<JsonNode> issues = searchJqlAllPages(jql, new String[]{"assignee", "status", "created", "sprint", "customfield_10117", "customfield_10513"});

        Long jiraSprintId = null;
        OffsetDateTime sprintStartDateTime = null;
        try {
            java.util.Map<String, Object> sprintInfo = fetchJiraSprintInfoFromBoard(sprint.getName());
            if (sprintInfo != null) {
                jiraSprintId = (Long) sprintInfo.get("id");
                sprintStartDateTime = parseJiraSprintStartDateTime((String) sprintInfo.get("startDate"));
            }
        } catch (Exception e) {
            org.slf4j.LoggerFactory.getLogger(JiraService.class).warn(
                    "Board sprint API failed for {}, falling back to issue field: {}", sprint.getName(), e.getMessage());
            jiraSprintId = findJiraSprintId(sprint.getName(), issues);
        }
        org.slf4j.LoggerFactory.getLogger(JiraService.class).info(
                "Syncing sprint {}: found {} issues, startDate={}, startDateTime={}, Jira sprint id={}",
                sprint.getName(), issues.size(), sprintStartDate, sprintStartDateTime, jiraSprintId);

        java.util.Map<String, BigDecimal> doneByAccountId = new java.util.HashMap<>();
        java.util.Map<String, BigDecimal> remainingByAccountId = new java.util.HashMap<>();
        java.util.Map<String, BigDecimal> existingByAccountId = new java.util.HashMap<>();
        java.util.Map<String, BigDecimal> newByAccountId = new java.util.HashMap<>();

        int newCount = 0;
        int existingCount = 0;
        for (JsonNode issue : issues) {
            JsonNode assignee = issue.path("fields").path("assignee");
            if (assignee.isNull() || assignee.isMissingNode()) continue;
            String accountId = assignee.path("accountId").asText();
            String statusCategory = issue.path("fields").path("status").path("statusCategory").path("key").asText();
            String issueKey = issue.path("key").asText(issue.path("id").asText());

            JsonNode changelog = issue.path("changelog");
            if (!changelog.isObject() || !changelog.has("histories")) {
                try {
                    changelog = fetchIssueChangelog(issue.path("id").asText(), issueKey);
                    org.slf4j.LoggerFactory.getLogger(JiraService.class).info(
                            "Fetched changelog for {}: {} histories", issueKey, changelog.isArray() ? changelog.size() : 0);
                } catch (Exception e) {
                    org.slf4j.LoggerFactory.getLogger(JiraService.class).warn(
                            "Could not fetch changelog for issue {}: {}", issueKey, e.getMessage());
                }
            } else {
                org.slf4j.LoggerFactory.getLogger(JiraService.class).info(
                        "Bulk changelog for {}: {} histories", issueKey, changelog.path("histories").size());
            }
            double storyPoints = getStoryPoints(issue);
            boolean hasSprintAddedDate = findSprintAdditionDate(changelog, sprint.getName(), jiraSprintId) != null;
            boolean isNew = hasSprintAddedDate && storyPoints > 0
                    && isIssueAddedAfterSprintStart(changelog, null, jiraSprintId, sprint.getName(), sprintStartDate, sprintStartDateTime);
            if (isNew) newCount++; else existingCount++;

            if ("done".equalsIgnoreCase(statusCategory)) {
                doneByAccountId.merge(accountId, BigDecimal.ONE, BigDecimal::add);
            } else {
                remainingByAccountId.merge(accountId, BigDecimal.ONE, BigDecimal::add);
            }
            if (isNew) {
                newByAccountId.merge(accountId, BigDecimal.ONE, BigDecimal::add);
            } else {
                existingByAccountId.merge(accountId, BigDecimal.ONE, BigDecimal::add);
            }
        }
        org.slf4j.LoggerFactory.getLogger(JiraService.class).info(
                "Sprint {} classification: existing={}, new={}", sprint.getName(), existingCount, newCount);

        List<SprintResultEntity> results = new ArrayList<>();
        java.util.Set<String> allAccountIds = new java.util.HashSet<>();
        allAccountIds.addAll(doneByAccountId.keySet());
        allAccountIds.addAll(remainingByAccountId.keySet());

        for (String accountId : allAccountIds) {
            teamMemberService.getTeamMemberByJiraAccountId(accountId).ifPresent(member -> {
                BigDecimal done = doneByAccountId.getOrDefault(accountId, BigDecimal.ZERO);
                BigDecimal remaining = remainingByAccountId.getOrDefault(accountId, BigDecimal.ZERO);
                BigDecimal target = done.add(remaining);
                BigDecimal existing = existingByAccountId.getOrDefault(accountId, BigDecimal.ZERO);
                BigDecimal newPts = newByAccountId.getOrDefault(accountId, BigDecimal.ZERO);

                SprintResultEntity result = sprintResultService.getSprintResultBySprintAndMember(sprintId, member.getId())
                        .map(oldResult -> sprintResultService.updateSprintResult(oldResult.getId(), target, done, remaining, existing, newPts))
                        .orElseGet(() -> sprintResultService.createSprintResult(sprintId, member.getId(), target, done, remaining, existing, newPts));
                results.add(result);
            });
        }
        return results;
    }

    private java.util.Map<String, Object> fetchJiraSprintInfoFromBoard(String sprintName) throws Exception {
        if (jiraBoardId == null || jiraBoardId.isBlank()) return null;
        int startAt = 0;
        int maxResults = 50;
        while (true) {
            String url = jiraDomain + "/rest/agile/1.0/board/" + jiraBoardId
                    + "/sprint?maxResults=" + maxResults + "&startAt=" + startAt;
            JsonNode root = callJiraApi(url);
            JsonNode values = root.path("values");
            if (values.isArray()) {
                for (JsonNode s : values) {
                    if (sprintName.equals(s.path("name").asText(null))) {
                        java.util.Map<String, Object> info = new java.util.HashMap<>();
                        info.put("id", s.has("id") ? s.get("id").asLong() : null);
                        info.put("startDate", s.path("startDate").asText(null));
                        return info;
                    }
                }
            }
            boolean isLast = root.path("isLast").asBoolean(true);
            if (isLast || !values.isArray() || values.size() == 0) break;
            startAt += values.size();
        }
        return null;
    }

    private Long findJiraSprintId(String sprintName, List<JsonNode> issues) {
        for (JsonNode issue : issues) {
            JsonNode sprints = issue.path("fields").path("sprint");
            if (sprints.isArray()) {
                for (JsonNode s : sprints) {
                    if (sprintName.equals(s.path("name").asText(null))) {
                        return s.has("id") ? s.get("id").asLong() : null;
                    }
                }
            } else if (!sprints.isMissingNode() && !sprints.isNull()) {
                if (sprintName.equals(sprints.path("name").asText(null))) {
                    return sprints.has("id") ? sprints.get("id").asLong() : null;
                }
            }
        }
        return null;
    }

    private JsonNode fetchIssueChangelog(String issueId, String issueKey) throws Exception {
        if (issueId != null && !issueId.isBlank()) {
            try {
                String url = jiraDomain + "/rest/api/3/issue/" + issueId + "/changelog";
                return callJiraApi(url).path("histories");
            } catch (Exception e) {
                org.slf4j.LoggerFactory.getLogger(JiraService.class).warn(
                        "Changelog fetch by id failed for {}, trying key: {}", issueId, e.getMessage());
            }
        }
        String url = jiraDomain + "/rest/api/3/issue/" + issueKey + "/changelog";
        return callJiraApi(url).path("histories");
    }

    private boolean isIssueAddedAfterSprintStart(JsonNode changelog, String createdStr, Long jiraSprintId, String sprintName, LocalDate sprintStartDate, OffsetDateTime sprintStartDateTime) {
        if (sprintStartDate == null && sprintStartDateTime == null) return false;

        String sprintAddedDate = findSprintAdditionDate(changelog, sprintName, jiraSprintId);
        if (sprintAddedDate != null && !sprintAddedDate.isBlank()) {
            try {
                OffsetDateTime addedDateTime = OffsetDateTime.parse(sprintAddedDate, JIRA_DATE_TIME);
                if (sprintStartDateTime != null) {
                    boolean isNew = addedDateTime.isAfter(sprintStartDateTime);
                    org.slf4j.LoggerFactory.getLogger(JiraService.class).info(
                            "Issue added to sprint {} at {} ({} start) -> new={}",
                            sprintName, addedDateTime, sprintStartDateTime, isNew);
                    return isNew;
                }
                LocalDate changedDate = addedDateTime.toLocalDate();
                boolean isNew = !changedDate.isBefore(sprintStartDate);
                org.slf4j.LoggerFactory.getLogger(JiraService.class).info(
                        "Issue added to sprint {} on {} ({} start) -> new={}",
                        sprintName, changedDate, sprintStartDate, isNew);
                return isNew;
            } catch (Exception e) {
                org.slf4j.LoggerFactory.getLogger(JiraService.class).warn(
                        "Failed to parse sprintAddedDate '{}': {}", sprintAddedDate, e.getMessage());
                // fall through to created date fallback
            }
        }

        // Fallback: treat as new if the issue was created after the sprint started.
        if (createdStr == null || createdStr.isBlank()) return false;
        try {
            OffsetDateTime createdDateTime = OffsetDateTime.parse(createdStr, JIRA_DATE_TIME);
            if (sprintStartDateTime != null) {
                boolean isNew = createdDateTime.isAfter(sprintStartDateTime);
                org.slf4j.LoggerFactory.getLogger(JiraService.class).info(
                        "Issue created {} ({} start) -> fallback new={}", createdDateTime, sprintStartDateTime, isNew);
                return isNew;
            }
            LocalDate createdDate = createdDateTime.toLocalDate();
            boolean isNew = !createdDate.isBefore(sprintStartDate);
            org.slf4j.LoggerFactory.getLogger(JiraService.class).info(
                    "Issue created {} ({} start) -> fallback new={}", createdDate, sprintStartDate, isNew);
            return isNew;
        } catch (Exception e) {
            org.slf4j.LoggerFactory.getLogger(JiraService.class).warn(
                    "Failed to parse createdStr '{}': {}", createdStr, e.getMessage());
            return false;
        }
    }

    private OffsetDateTime parseJiraSprintStartDateTime(String dateStr) {
        if (dateStr == null || dateStr.isBlank()) return null;
        try {
            return OffsetDateTime.parse(dateStr, JIRA_DATE_TIME);
        } catch (Exception e) {
            try {
                return LocalDate.parse(dateStr).atStartOfDay(ZoneOffset.UTC).toOffsetDateTime();
            } catch (Exception e2) {
                org.slf4j.LoggerFactory.getLogger(JiraService.class).warn(
                        "Failed to parse sprint startDate '{}': {}", dateStr, e2.getMessage());
                return null;
            }
        }
    }

    public java.util.Map<String, Object> syncAllSprintResults() throws Exception {
        List<SprintEntity> sprints = sprintService.getAllSprints();
        int syncedSprints = 0;
        int totalResults = 0;
        List<String> errors = new ArrayList<>();

        for (SprintEntity sprint : sprints) {
            try {
                List<SprintResultEntity> results = syncSprintResults(sprint.getId());
                if (!results.isEmpty()) {
                    syncedSprints++;
                    totalResults += results.size();
                }
            } catch (Exception e) {
                errors.add(sprint.getName() + ": " + e.getMessage());
            }
        }

        return java.util.Map.of(
                "syncedSprints", syncedSprints,
                "totalResults", totalResults,
                "errors", errors
        );
    }

    private String findSprintAdditionDate(JsonNode changelog, String sprintName, Long jiraSprintId) {
        if (changelog == null || changelog.isMissingNode() || changelog.isNull()) return null;
        String sprintNameLower = sprintName != null ? sprintName.toLowerCase() : null;
        JsonNode histories = changelog.isArray() ? changelog : changelog.path("histories");
        if (!histories.isArray()) return null;
        for (JsonNode history : histories) {
            JsonNode items = history.path("items");
            if (!items.isArray()) continue;
            for (JsonNode item : items) {
                String fieldName = item.path("field").asText("");
                String fieldId = item.path("fieldId").asText("");
                if (!"Sprint".equalsIgnoreCase(fieldName) && !fieldId.toLowerCase().contains("sprint")) continue;
                String toValue = item.path("to").asText("");
                String fromValue = item.path("from").asText("");
                String toString = item.path("toString").asText("");
                String fromString = item.path("fromString").asText("");
                String sprintIdStr = jiraSprintId != null ? String.valueOf(jiraSprintId) : null;
                boolean inTo = sprintIdStr != null && java.util.Arrays.stream(toValue.split(","))
                        .map(String::trim).anyMatch(id -> id.equals(sprintIdStr));
                boolean inFrom = sprintIdStr != null && java.util.Arrays.stream(fromValue.split(","))
                        .map(String::trim).anyMatch(id -> id.equals(sprintIdStr));
                boolean matchesId = inTo && !inFrom;
                boolean inToName = sprintNameLower != null && java.util.Arrays.stream(toString.split(","))
                        .map(String::trim).map(String::toLowerCase).anyMatch(name -> name.equals(sprintNameLower));
                boolean inFromName = sprintNameLower != null && java.util.Arrays.stream(fromString.split(","))
                        .map(String::trim).map(String::toLowerCase).anyMatch(name -> name.equals(sprintNameLower));
                boolean matchesName = inToName && !inFromName;
                if (matchesId || matchesName) {
                    return history.path("created").asText(null);
                }
            }
        }
        return null;
    }

    public List<java.util.Map<String, String>> getJiraBoardMembers() throws Exception {
        String url = jiraDomain + "/rest/api/3/user/assignable/multiProjectSearch?projectKeys=" + jiraProjectKey + "&maxResults=100";
        JsonNode root = callJiraApi(url);

        java.util.Map<String, java.util.Map<String, String>> seen = new java.util.LinkedHashMap<>();
        if (root.isArray()) {
            for (JsonNode u : root) {
                String accountId = u.path("accountId").asText();
                String displayName = u.path("displayName").asText();
                String email = u.path("emailAddress").asText("");
                if (accountId.isBlank() || displayName.isBlank()) continue;
                seen.put(accountId, java.util.Map.of(
                    "accountId", accountId,
                    "displayName", displayName,
                    "email", email
                ));
            }
        }
        return new ArrayList<>(seen.values());
    }

    public List<com.krungsri.scrum_poker.entity.TeamMemberEntity> importMembersFromJira() throws Exception {
        String jql = "project=" + jiraProjectKey + " AND sprint in openSprints() AND assignee is not EMPTY";
        List<JsonNode> issues = searchJqlAllPages(jql, new String[]{"assignee"});

        java.util.Map<String, java.util.Map<String, String>> seen = new java.util.LinkedHashMap<>();
        for (JsonNode issue : issues) {
            JsonNode assignee = issue.path("fields").path("assignee");
            if (assignee.isNull() || assignee.isMissingNode()) continue;
            String accountId = assignee.path("accountId").asText();
            String displayName = assignee.path("displayName").asText();
            String email = assignee.path("emailAddress").asText("");
            if (accountId.isBlank() || displayName.isBlank()) continue;
            seen.putIfAbsent(accountId, java.util.Map.of(
                "accountId", accountId, "displayName", displayName, "email", email));
        }

        List<com.krungsri.scrum_poker.entity.TeamMemberEntity> imported = new ArrayList<>();
        for (java.util.Map<String, String> m : seen.values()) {
            String accountId = m.get("accountId");
            String name = m.get("displayName");
            String email = m.get("email");
            String username = email.isBlank() ? name : email.split("@")[0];
            Optional<com.krungsri.scrum_poker.entity.TeamMemberEntity> existing =
                teamMemberService.getTeamMemberByJiraAccountId(accountId);
            if (existing.isEmpty()) {
                imported.add(teamMemberService.createTeamMember(name, username, accountId));
            }
        }
        return imported;
    }

    public java.util.Map<String, Object> getMemberSprintDetails(Long sprintId, Long memberId) throws Exception {
        SprintEntity sprint = sprintService.getSprintById(sprintId)
                .orElseThrow(() -> new RuntimeException("Sprint not found: " + sprintId));
        TeamMemberEntity member = teamMemberService.getTeamMemberById(memberId)
                .orElseThrow(() -> new RuntimeException("Member not found: " + memberId));

        String jql = "project=" + jiraProjectKey
                + " AND sprint=\"" + escapeJql(sprint.getName()) + "\""
                + " AND assignee=\"" + escapeJql(member.getJiraAccountId()) + "\""
                + " AND issueType not in subTaskIssueTypes() AND issueType != Epic";
        List<JsonNode> issues = searchJqlAllPages(jql, new String[]{"summary", "status", "customfield_10117", "customfield_10513"});

        java.util.List<java.util.Map<String, Object>> done = new ArrayList<>();
        java.util.List<java.util.Map<String, Object>> remaining = new ArrayList<>();

        for (JsonNode issue : issues) {
            String key = issue.path("key").asText();
            String summary = issue.path("fields").path("summary").asText();
            String statusCategory = issue.path("fields").path("status").path("statusCategory").path("key").asText();
            JsonNode spNode = issue.path("fields").path("customfield_10117");
            if (spNode.isNull() || spNode.isMissingNode()) spNode = issue.path("fields").path("customfield_10513");
            BigDecimal pts = spNode.isNull() || spNode.isMissingNode()
                    ? BigDecimal.ZERO : BigDecimal.valueOf(spNode.asDouble());

            java.util.Map<String, Object> task = new java.util.HashMap<>();
            task.put("id", key);
            task.put("title", summary);
            task.put("points", pts);
            task.put("status", statusCategory);

            if ("done".equalsIgnoreCase(statusCategory)) {
                done.add(task);
            } else {
                remaining.add(task);
            }
        }

        java.util.Map<String, Object> result = new java.util.HashMap<>();
        result.put("memberId", memberId);
        result.put("memberName", member.getName());
        result.put("sprintId", sprintId);
        result.put("sprintName", sprint.getName());
        result.put("completedTasks", done);
        result.put("remainingTasks", remaining);
        return result;
    }

    public boolean isJiraConfigured() {
        return jiraDomain != null && !jiraDomain.isBlank()
                && jiraEmail != null && !jiraEmail.isBlank()
                && jiraApiToken != null && !jiraApiToken.isBlank()
                && jiraBoardId != null && !jiraBoardId.isBlank()
                && jiraProjectKey != null && !jiraProjectKey.isBlank();
    }
}
