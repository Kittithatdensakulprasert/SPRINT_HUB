package com.krungsri.scrum_poker.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.krungsri.scrum_poker.entity.CapacityPlanningEntity;
import com.krungsri.scrum_poker.entity.SprintEntity;
import com.krungsri.scrum_poker.entity.SprintResultEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

@Service
public class JiraService {

    // ⚠️  TOKEN: อ่านจาก environment variable ผ่าน application.properties
    //     ตั้งค่าด้วย: export JIRA_API_TOKEN=xxx  ก่อน run backend
    @Value("${jira.api.token:}")
    private String jiraApiToken;

    @Value("${jira.email:}")
    private String jiraEmail;

    @Value("${jira.domain:}")
    private String jiraDomain;

    @Value("${jira.board-id:}")
    private String jiraBoardId;

    @Value("${jira.project-key:}")
    private String jiraProjectKey;

    @Autowired
    private SprintService sprintService;

    @Autowired
    private TeamMemberService teamMemberService;

    @Autowired
    private CapacityPlanningService capacityPlanningService;

    @Autowired
    private SprintResultService sprintResultService;

    private final HttpClient httpClient = HttpClient.newHttpClient();
    private final ObjectMapper objectMapper = new ObjectMapper();

    public boolean isConfigured() {
        return jiraApiToken != null && !jiraApiToken.isBlank()
            && jiraEmail != null && !jiraEmail.isBlank()
            && jiraDomain != null && !jiraDomain.isBlank()
            && jiraBoardId != null && !jiraBoardId.isBlank();
    }

    // Basic Auth header: Base64(email:token)
    private String buildAuthHeader() {
        String credentials = jiraEmail + ":" + jiraApiToken;
        return "Basic " + Base64.getEncoder().encodeToString(credentials.getBytes());
    }

    private JsonNode callJiraApi(String url) throws Exception {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Authorization", buildAuthHeader())
                .header("Accept", "application/json")
                .GET()
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 200) {
            throw new RuntimeException("Jira API error " + response.statusCode() + ": " + response.body());
        }
        return objectMapper.readTree(response.body());
    }

    // ===================================================================
    // 1. Sync Sprints จาก Jira Board → บันทึกลง DB
    // ===================================================================
    public List<SprintEntity> syncSprints() throws Exception {
        // ⚠️  TOKEN: ต้องตั้งค่า JIRA_API_TOKEN, JIRA_DOMAIN, JIRA_BOARD_ID ใน env ก่อน
        String url = jiraDomain + "/rest/agile/1.0/board/" + jiraBoardId + "/sprint?state=active,closed,future&maxResults=20";
        JsonNode root = callJiraApi(url);
        JsonNode values = root.get("values");

        List<SprintEntity> synced = new ArrayList<>();
        if (values != null && values.isArray()) {
            for (JsonNode s : values) {
                String name = s.get("name").asText();
                String state = s.get("state").asText();
                LocalDate startDate = s.has("startDate") && !s.get("startDate").isNull()
                        ? LocalDate.parse(s.get("startDate").asText().substring(0, 10)) : LocalDate.now();
                LocalDate endDate = s.has("endDate") && !s.get("endDate").isNull()
                        ? LocalDate.parse(s.get("endDate").asText().substring(0, 10)) : LocalDate.now().plusDays(14);

                Optional<SprintEntity> existing = sprintService.getSprintByName(name);
                SprintEntity sprint;
                if (existing.isPresent()) {
                    sprint = sprintService.updateSprint(existing.get().getId(), name, startDate, endDate, state);
                } else {
                    sprint = sprintService.createSprint(name, startDate, endDate, state);
                }
                synced.add(sprint);
            }
        }
        return synced;
    }

    // ===================================================================
    // 2. Sync Existing Points (งานค้าง) รายคน → บันทึกใน capacity_planning
    //    ดึงงานที่ยังไม่เสร็จในปัจจุบัน sprint ของแต่ละคน
    // ===================================================================
    public List<CapacityPlanningEntity> syncExistingPoints(Long sprintId) throws Exception {
        SprintEntity sprint = sprintService.getSprintById(sprintId)
                .orElseThrow(() -> new RuntimeException("Sprint not found: " + sprintId));

        // ⚠️  TOKEN: ต้องตั้งค่า JIRA_API_TOKEN, JIRA_PROJECT_KEY ใน env ก่อน
        String jql = "project=" + jiraProjectKey + " AND sprint=\"" + sprint.getName() + "\" AND statusCategory != Done";
        String url = jiraDomain + "/rest/api/3/search?jql=" + java.net.URLEncoder.encode(jql, "UTF-8")
                + "&fields=assignee,story_points,customfield_10016&maxResults=200";

        JsonNode root = callJiraApi(url);
        JsonNode issues = root.get("issues");

        List<CapacityPlanningEntity> results = new ArrayList<>();
        BigDecimal pointsPerDay = BigDecimal.valueOf(2);

        if (issues != null && issues.isArray()) {
            // รวม points ต่อ assignee
            java.util.Map<String, BigDecimal> pointsByAccountId = new java.util.HashMap<>();
            for (JsonNode issue : issues) {
                JsonNode assignee = issue.path("fields").path("assignee");
                if (assignee.isNull() || assignee.isMissingNode()) continue;
                String accountId = assignee.path("accountId").asText();
                // story points อยู่ใน customfield_10016 (ค่า default ของ Jira Cloud)
                JsonNode spNode = issue.path("fields").path("customfield_10016");
                BigDecimal pts = spNode.isNull() || spNode.isMissingNode()
                        ? BigDecimal.ZERO : BigDecimal.valueOf(spNode.asDouble());
                pointsByAccountId.merge(accountId, pts, BigDecimal::add);
            }

            // map กลับหา TeamMember แล้ว upsert capacity_planning
            for (java.util.Map.Entry<String, BigDecimal> entry : pointsByAccountId.entrySet()) {
                teamMemberService.getTeamMemberByJiraAccountId(entry.getKey()).ifPresent(member -> {
                    try {
                        CapacityPlanningEntity cp = capacityPlanningService.calculateCapacity(
                                sprintId, member.getId(), 0, BigDecimal.ZERO, entry.getValue(), pointsPerDay);
                        results.add(cp);
                    } catch (Exception ignored) {}
                });
            }
        }
        return results;
    }

    // ===================================================================
    // 3. Sync Sprint Results (งานเสร็จจริง) → บันทึกใน sprint_results
    //    ใช้หลัง Sprint จบแล้ว
    // ===================================================================
    public List<SprintResultEntity> syncSprintResults(Long sprintId) throws Exception {
        SprintEntity sprint = sprintService.getSprintById(sprintId)
                .orElseThrow(() -> new RuntimeException("Sprint not found: " + sprintId));

        // ⚠️  TOKEN: ต้องตั้งค่า JIRA_API_TOKEN, JIRA_PROJECT_KEY ใน env ก่อน
        String jql = "project=" + jiraProjectKey + " AND sprint=\"" + sprint.getName() + "\"";
        String url = jiraDomain + "/rest/api/3/search?jql=" + java.net.URLEncoder.encode(jql, "UTF-8")
                + "&fields=assignee,customfield_10016,status&maxResults=200";

        JsonNode root = callJiraApi(url);
        JsonNode issues = root.get("issues");

        // รวม done/remaining pts ต่อ assignee
        java.util.Map<String, BigDecimal> doneByAccountId = new java.util.HashMap<>();
        java.util.Map<String, BigDecimal> remainingByAccountId = new java.util.HashMap<>();

        if (issues != null && issues.isArray()) {
            for (JsonNode issue : issues) {
                JsonNode assignee = issue.path("fields").path("assignee");
                if (assignee.isNull() || assignee.isMissingNode()) continue;
                String accountId = assignee.path("accountId").asText();
                JsonNode spNode = issue.path("fields").path("customfield_10016");
                BigDecimal pts = spNode.isNull() || spNode.isMissingNode()
                        ? BigDecimal.ZERO : BigDecimal.valueOf(spNode.asDouble());
                String statusCategory = issue.path("fields").path("status").path("statusCategory").path("key").asText();

                if ("done".equalsIgnoreCase(statusCategory)) {
                    doneByAccountId.merge(accountId, pts, BigDecimal::add);
                } else {
                    remainingByAccountId.merge(accountId, pts, BigDecimal::add);
                }
            }
        }

        List<SprintResultEntity> results = new ArrayList<>();
        java.util.Set<String> allAccountIds = new java.util.HashSet<>();
        allAccountIds.addAll(doneByAccountId.keySet());
        allAccountIds.addAll(remainingByAccountId.keySet());

        for (String accountId : allAccountIds) {
            teamMemberService.getTeamMemberByJiraAccountId(accountId).ifPresent(member -> {
                BigDecimal done = doneByAccountId.getOrDefault(accountId, BigDecimal.ZERO);
                BigDecimal remaining = remainingByAccountId.getOrDefault(accountId, BigDecimal.ZERO);
                BigDecimal target = done.add(remaining);

                SprintResultEntity result = sprintResultService.getSprintResultBySprintAndMember(sprintId, member.getId())
                        .map(existing -> sprintResultService.updateSprintResult(existing.getId(), target, done, remaining))
                        .orElseGet(() -> sprintResultService.createSprintResult(sprintId, member.getId(), target, done, remaining));
                results.add(result);
            });
        }
        return results;
    }

    // ===================================================================
    // 4. ตรวจสอบ Jira config ครบหรือยัง
    // ===================================================================
    public boolean isJiraConfigured() {
        return jiraDomain != null && !jiraDomain.isBlank()
                && jiraEmail != null && !jiraEmail.isBlank()
                && jiraApiToken != null && !jiraApiToken.isBlank()
                && jiraBoardId != null && !jiraBoardId.isBlank()
                && jiraProjectKey != null && !jiraProjectKey.isBlank();
    }
}
