package com.krungsri.scrum_poker.repository;

import com.krungsri.scrum_poker.entity.CapacityPlanningEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CapacityPlanningRepository extends JpaRepository<CapacityPlanningEntity, Long> {
    List<CapacityPlanningEntity> findBySprintId(Long sprintId);
    List<CapacityPlanningEntity> findByMemberId(Long memberId);
    Optional<CapacityPlanningEntity> findBySprintIdAndMemberId(Long sprintId, Long memberId);
    void deleteBySprintId(Long sprintId);
}
