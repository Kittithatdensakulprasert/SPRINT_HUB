package com.krungsri.scrum_poker.repository;

import com.krungsri.scrum_poker.entity.SprintResultEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SprintResultRepository extends JpaRepository<SprintResultEntity, Long> {
    List<SprintResultEntity> findBySprintId(Long sprintId);
    List<SprintResultEntity> findByMemberId(Long memberId);
    Optional<SprintResultEntity> findBySprintIdAndMemberId(Long sprintId, Long memberId);
    void deleteBySprintId(Long sprintId);
}
