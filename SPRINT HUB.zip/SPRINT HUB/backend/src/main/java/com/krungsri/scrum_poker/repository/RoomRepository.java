package com.krungsri.scrum_poker.repository;

import com.krungsri.scrum_poker.entity.RoomEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface RoomRepository extends JpaRepository<RoomEntity, String> {
    Optional<RoomEntity> findByRoomId(String roomId);
    void deleteByRoomId(String roomId);
}
