package com.krungsri.scrum_poker.repository;

import com.krungsri.scrum_poker.entity.MemberIssueDistributionEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MemberIssueDistributionRepository extends JpaRepository<MemberIssueDistributionEntity, Long> {

    List<MemberIssueDistributionEntity> findBySprintId(Long sprintId);

    void deleteBySprintId(Long sprintId);
}
