package com.krungsri.scrum_poker.repository;

import com.krungsri.scrum_poker.entity.MemberIssueDistributionEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MemberIssueDistributionRepository extends JpaRepository<MemberIssueDistributionEntity, Long> {

    List<MemberIssueDistributionEntity> findBySprintId(Long sprintId);

    List<MemberIssueDistributionEntity> findBySprintIdAndMemberAccountId(Long sprintId, String memberAccountId);

    void deleteBySprintId(Long sprintId);

    // ดึง sprint ids ทั้งหมดที่มีข้อมูล member distribution
    @Query("SELECT DISTINCT d.sprintId FROM MemberIssueDistributionEntity d ORDER BY d.sprintId")
    List<Long> findDistinctSprintIds();
}
