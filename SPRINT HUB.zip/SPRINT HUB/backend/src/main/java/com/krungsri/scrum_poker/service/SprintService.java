package com.krungsri.scrum_poker.service;

import com.krungsri.scrum_poker.entity.SprintEntity;
import com.krungsri.scrum_poker.repository.SprintRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class SprintService {

    @Autowired
    private SprintRepository sprintRepository;

    public List<SprintEntity> getAllSprints() {
        return sprintRepository.findAllByOrderByStartDateDesc();
    }

    public Optional<SprintEntity> getSprintById(Long id) {
        return sprintRepository.findById(id);
    }

    public Optional<SprintEntity> getSprintByName(String name) {
        return sprintRepository.findByName(name);
    }

    public List<SprintEntity> getSprintsByStatus(String status) {
        return sprintRepository.findByStatus(status);
    }

    public SprintEntity createSprint(String name, LocalDate startDate, LocalDate endDate, String status) {
        SprintEntity sprint = new SprintEntity();
        sprint.setName(name);
        sprint.setStartDate(startDate);
        sprint.setEndDate(endDate);
        sprint.setStatus(status != null ? status : "planning");
        return sprintRepository.save(sprint);
    }

    public SprintEntity updateSprint(Long id, String name, LocalDate startDate, LocalDate endDate, String status) {
        Optional<SprintEntity> sprintOpt = sprintRepository.findById(id);
        if (sprintOpt.isPresent()) {
            SprintEntity sprint = sprintOpt.get();
            if (name != null) sprint.setName(name);
            if (startDate != null) sprint.setStartDate(startDate);
            if (endDate != null) sprint.setEndDate(endDate);
            if (status != null) sprint.setStatus(status);
            return sprintRepository.save(sprint);
        }
        return null;
    }

    public boolean deleteSprint(Long id) {
        if (sprintRepository.existsById(id)) {
            sprintRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
