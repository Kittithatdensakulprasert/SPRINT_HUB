package com.krungsri.scrum_poker.controller;

import com.krungsri.scrum_poker.entity.TeamMemberEntity;
import com.krungsri.scrum_poker.service.TeamMemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/team-members")
@CrossOrigin(origins = "*")
public class TeamMemberController {

    @Autowired
    private TeamMemberService teamMemberService;

    @GetMapping
    public ResponseEntity<List<TeamMemberEntity>> getAllTeamMembers() {
        return ResponseEntity.ok(teamMemberService.getAllTeamMembers());
    }

    @GetMapping("/active")
    public ResponseEntity<List<TeamMemberEntity>> getActiveTeamMembers() {
        return ResponseEntity.ok(teamMemberService.getActiveTeamMembers());
    }

    @GetMapping("/{id}")
    public ResponseEntity<TeamMemberEntity> getTeamMemberById(@PathVariable Long id) {
        return teamMemberService.getTeamMemberById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<TeamMemberEntity> createTeamMember(@RequestBody Map<String, String> request) {
        String name = request.get("name");
        String jiraUsername = request.get("jiraUsername");
        String jiraAccountId = request.get("jiraAccountId");
        String email = request.get("email");
        String role = request.get("role");
        TeamMemberEntity member = teamMemberService.createTeamMember(name, jiraUsername, jiraAccountId, email, role);
        return ResponseEntity.ok(member);
    }

    @PutMapping("/{id}")
    public ResponseEntity<TeamMemberEntity> updateTeamMember(@PathVariable Long id, @RequestBody Map<String, Object> request) {
        String name = (String) request.get("name");
        String jiraUsername = (String) request.get("jiraUsername");
        String jiraAccountId = (String) request.get("jiraAccountId");
        Boolean isActive = request.get("isActive") != null ? (Boolean) request.get("isActive") : null;
        String email = (String) request.get("email");
        String role = (String) request.get("role");
        TeamMemberEntity member = teamMemberService.updateTeamMember(id, name, jiraUsername, jiraAccountId, isActive, email, role);
        if (member == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(member);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTeamMember(@PathVariable Long id) {
        if (!teamMemberService.deleteTeamMember(id)) return ResponseEntity.notFound().build();
        return ResponseEntity.noContent().build();
    }
}
