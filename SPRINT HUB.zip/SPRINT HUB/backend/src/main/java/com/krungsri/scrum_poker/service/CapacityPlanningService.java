package com.krungsri.scrum_poker.service;

import com.krungsri.scrum_poker.entity.CapacityPlanningEntity;
import com.krungsri.scrum_poker.repository.CapacityPlanningRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class CapacityPlanningService {

    @Autowired
    private CapacityPlanningRepository capacityPlanningRepository;

    public List<CapacityPlanningEntity> getAllCapacityPlanning() {
        return capacityPlanningRepository.findAll();
    }

    public List<CapacityPlanningEntity> getCapacityPlanningBySprintId(Long sprintId) {
        return capacityPlanningRepository.findBySprintId(sprintId);
    }

    public List<CapacityPlanningEntity> getCapacityPlanningByMemberId(Long memberId) {
        return capacityPlanningRepository.findByMemberId(memberId);
    }

    public Optional<CapacityPlanningEntity> getCapacityPlanningBySprintAndMember(Long sprintId, Long memberId) {
        return capacityPlanningRepository.findBySprintIdAndMemberId(sprintId, memberId);
    }

    public CapacityPlanningEntity createCapacityPlanning(Long sprintId, Long memberId, Integer leaveDays, BigDecimal reservePercent, BigDecimal existingPts) {
        CapacityPlanningEntity planning = new CapacityPlanningEntity();
        planning.setSprintId(sprintId);
        planning.setMemberId(memberId);
        planning.setLeaveDays(leaveDays != null ? leaveDays : 0);
        planning.setReservePercent(reservePercent != null ? reservePercent : BigDecimal.ZERO);
        planning.setExistingPts(existingPts != null ? existingPts : BigDecimal.ZERO);
        planning.setAvailablePts(BigDecimal.ZERO);
        planning.setAcceptablePts(BigDecimal.ZERO);
        planning.setFinalManDay(BigDecimal.ZERO);
        return capacityPlanningRepository.save(planning);
    }

    public CapacityPlanningEntity updateCapacityPlanning(Long id, Integer leaveDays, BigDecimal reservePercent, BigDecimal existingPts, BigDecimal availablePts, BigDecimal acceptablePts, BigDecimal finalManDay) {
        Optional<CapacityPlanningEntity> planningOpt = capacityPlanningRepository.findById(id);
        if (planningOpt.isPresent()) {
            CapacityPlanningEntity planning = planningOpt.get();
            if (leaveDays != null) planning.setLeaveDays(leaveDays);
            if (reservePercent != null) planning.setReservePercent(reservePercent);
            if (existingPts != null) planning.setExistingPts(existingPts);
            if (availablePts != null) planning.setAvailablePts(availablePts);
            if (acceptablePts != null) planning.setAcceptablePts(acceptablePts);
            if (finalManDay != null) planning.setFinalManDay(finalManDay);
            return capacityPlanningRepository.save(planning);
        }
        return null;
    }

    public boolean deleteCapacityPlanning(Long id) {
        if (capacityPlanningRepository.existsById(id)) {
            capacityPlanningRepository.deleteById(id);
            return true;
        }
        return false;
    }

    public boolean deleteCapacityPlanningBySprintId(Long sprintId) {
        capacityPlanningRepository.deleteBySprintId(sprintId);
        return true;
    }

    public CapacityPlanningEntity calculateCapacity(Long sprintId, Long memberId, Integer leaveDays, BigDecimal reservePercent, BigDecimal existingPts, BigDecimal pointsPerDay) {
        // FinalManDay = (10 - จำนวนวันลารวม) * (1 - (Reserve% / 100))
        BigDecimal finalManDay = BigDecimal.valueOf(10 - (leaveDays != null ? leaveDays : 0))
                .multiply(BigDecimal.ONE.subtract((reservePercent != null ? reservePercent : BigDecimal.ZERO).divide(BigDecimal.valueOf(100))));

        // AVAILABLE PTS = FinalManDay * ตัวคูณจุดต่อวัน
        BigDecimal availablePts = finalManDay.multiply(pointsPerDay != null ? pointsPerDay : BigDecimal.valueOf(2));

        // ACCEPTABLE PTS = AVAILABLE PTS - EXISTING PTS
        BigDecimal acceptablePts = availablePts.subtract(existingPts != null ? existingPts : BigDecimal.ZERO);

        // Update or create capacity planning
        Optional<CapacityPlanningEntity> planningOpt = capacityPlanningRepository.findBySprintIdAndMemberId(sprintId, memberId);
        CapacityPlanningEntity planning;
        if (planningOpt.isPresent()) {
            planning = planningOpt.get();
        } else {
            planning = new CapacityPlanningEntity();
            planning.setSprintId(sprintId);
            planning.setMemberId(memberId);
        }

        planning.setLeaveDays(leaveDays != null ? leaveDays : 0);
        planning.setReservePercent(reservePercent != null ? reservePercent : BigDecimal.ZERO);
        planning.setExistingPts(existingPts != null ? existingPts : BigDecimal.ZERO);
        planning.setFinalManDay(finalManDay);
        planning.setAvailablePts(availablePts);
        planning.setAcceptablePts(acceptablePts);

        return capacityPlanningRepository.save(planning);
    }
}
