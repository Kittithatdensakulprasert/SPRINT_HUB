package com.krungsri.scrum_poker;

import com.krungsri.scrum_poker.service.JiraService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class SprintHubApplication {

    private static final Logger log = LoggerFactory.getLogger(SprintHubApplication.class);

    static {
        System.setProperty("java.net.useSystemProxies", "true");
    }

    @Autowired
    private JiraService jiraService;

    public static void main(String[] args) {
        System.setProperty("java.net.useSystemProxies", "true");
        SpringApplication.run(SprintHubApplication.class, args);
    }

    @Bean
    public ApplicationRunner autoSyncOnStartup() {
        return args -> {
            if (jiraService.isJiraConfigured()) {
                try {
                    jiraService.syncSprints();
                } catch (Exception e) {
                    log.warn("Auto-sync Jira on startup failed (app will continue): {}", e.getMessage());
                }
            }
        };
    }
}
