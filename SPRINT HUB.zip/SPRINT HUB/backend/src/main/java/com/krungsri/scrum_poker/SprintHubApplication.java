package com.krungsri.scrum_poker;

import com.krungsri.scrum_poker.service.JiraService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class SprintHubApplication {

    @Autowired
    private JiraService jiraService;

    public static void main(String[] args) {
        SpringApplication.run(SprintHubApplication.class, args);
    }

    @Bean
    public ApplicationRunner autoSyncOnStartup() {
        return args -> {
            if (jiraService.isJiraConfigured()) {
                jiraService.syncSprints();
            }
        };
    }
}
