package com.krungsri.scrum_poker.repository;

import com.krungsri.scrum_poker.entity.IssueDistributionEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface IssueDistributionRepository extends JpaRepository<IssueDistributionEntity, Long> {

    List<IssueDistributionEntity> findBySprintId(Long sprintId);

    List<IssueDistributionEntity> findBySprintIdIn(List<Long> sprintIds);

    Optional<IssueDistributionEntity> findBySprintIdAndIssueTypeAndSystemName(
        Long sprintId, String issueType, String systemName);

    void deleteBySprintId(Long sprintId);

    // ดึง sprint ids ทั้งหมดที่มีข้อมูล distribution
    @Query("SELECT DISTINCT d.sprintId FROM IssueDistributionEntity d ORDER BY d.sprintId")
    List<Long> findDistinctSprintIds();
}
