package com.krungsri.scrum_poker.repository;

import com.krungsri.scrum_poker.entity.IssueDistributionEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IssueDistributionRepository extends JpaRepository<IssueDistributionEntity, Long> {

    List<IssueDistributionEntity> findBySprintId(Long sprintId);

    List<IssueDistributionEntity> findBySprintIdIn(List<Long> sprintIds);

    void deleteBySprintId(Long sprintId);
}
