package com.krungsri.scrum_poker.service;

import com.krungsri.scrum_poker.entity.TeamMemberEntity;
import com.krungsri.scrum_poker.repository.TeamMemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class TeamMemberService {

    @Autowired
    private TeamMemberRepository teamMemberRepository;

    public List<TeamMemberEntity> getAllTeamMembers() {
        return teamMemberRepository.findAllByOrderByNameAsc().stream()
                .sorted(memberComparator())
                .collect(Collectors.toList());
    }

    public List<TeamMemberEntity> getActiveTeamMembers() {
        return teamMemberRepository.findByIsActiveOrderByNameAsc(true).stream()
                .sorted(memberComparator())
                .collect(Collectors.toList());
    }

    private Comparator<TeamMemberEntity> memberComparator() {
        return Comparator
                .comparing((TeamMemberEntity m) -> !isEnglishName(m.getName()))
                .thenComparing(m -> m.getName(), String.CASE_INSENSITIVE_ORDER);
    }

    private boolean isEnglishName(String name) {
        if (name == null || name.isBlank()) return false;
        char c = name.charAt(0);
        return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z');
    }

    public Optional<TeamMemberEntity> getTeamMemberById(Long id) {
        return teamMemberRepository.findById(id);
    }

    public Optional<TeamMemberEntity> getTeamMemberByJiraUsername(String jiraUsername) {
        return teamMemberRepository.findByJiraUsername(jiraUsername);
    }

    public Optional<TeamMemberEntity> getTeamMemberByJiraAccountId(String jiraAccountId) {
        return teamMemberRepository.findByJiraAccountId(jiraAccountId);
    }

    public TeamMemberEntity createTeamMember(String name, String jiraUsername, String jiraAccountId) {
        TeamMemberEntity member = new TeamMemberEntity();
        member.setName(name);
        member.setJiraUsername(jiraUsername);
        member.setJiraAccountId(jiraAccountId);
        member.setIsActive(true);
        return teamMemberRepository.save(member);
    }

    public TeamMemberEntity updateTeamMember(Long id, String name, String jiraUsername, String jiraAccountId, Boolean isActive) {
        Optional<TeamMemberEntity> memberOpt = teamMemberRepository.findById(id);
        if (memberOpt.isPresent()) {
            TeamMemberEntity member = memberOpt.get();
            if (name != null) member.setName(name);
            if (jiraUsername != null) member.setJiraUsername(jiraUsername);
            if (jiraAccountId != null) member.setJiraAccountId(jiraAccountId);
            if (isActive != null) member.setIsActive(isActive);
            return teamMemberRepository.save(member);
        }
        return null;
    }

    public boolean deleteTeamMember(Long id) {
        if (teamMemberRepository.existsById(id)) {
            teamMemberRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
