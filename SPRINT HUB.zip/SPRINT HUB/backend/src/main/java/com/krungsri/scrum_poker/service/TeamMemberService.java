package com.krungsri.scrum_poker.service;

import com.krungsri.scrum_poker.entity.TeamMemberEntity;
import com.krungsri.scrum_poker.repository.TeamMemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class TeamMemberService {

    @Autowired
    private TeamMemberRepository teamMemberRepository;

    public List<TeamMemberEntity> getAllTeamMembers() {
        return teamMemberRepository.findAllByOrderByNameAsc().stream()
                .sorted(memberComparator())
                .collect(Collectors.toList());
    }

    public List<TeamMemberEntity> getActiveTeamMembers() {
        return teamMemberRepository.findByIsActiveOrderByNameAsc(true).stream()
                .sorted(memberComparator())
                .collect(Collectors.toList());
    }

    private Comparator<TeamMemberEntity> memberComparator() {
        return Comparator
                .comparing((TeamMemberEntity m) -> !isEnglishName(m.getName()))
                .thenComparing(m -> m.getName(), String.CASE_INSENSITIVE_ORDER);
    }

    private boolean isEnglishName(String name) {
        if (name == null || name.isBlank()) return false;
        char c = name.charAt(0);
        return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z');
    }

    public Optional<TeamMemberEntity> getTeamMemberById(Long id) {
        return teamMemberRepository.findById(id);
    }

    public Optional<TeamMemberEntity> getTeamMemberByJiraUsername(String jiraUsername) {
        return teamMemberRepository.findByJiraUsername(jiraUsername);
    }

    public Optional<TeamMemberEntity> getTeamMemberByJiraAccountId(String jiraAccountId) {
        return teamMemberRepository.findByJiraAccountId(jiraAccountId);
    }

    public TeamMemberEntity createTeamMember(String name, String jiraUsername, String jiraAccountId) {
        return createTeamMember(name, jiraUsername, jiraAccountId, null);
    }

    public TeamMemberEntity createTeamMember(String name, String jiraUsername, String jiraAccountId, String email) {
        // ถ้า jiraAccountId ซ้ำ (เคยลบไป) → reactivate แทนสร้างใหม่ เพื่อรักษา id เดิม
        if (jiraAccountId != null && !jiraAccountId.isBlank()) {
            Optional<TeamMemberEntity> existing = teamMemberRepository.findByJiraAccountId(jiraAccountId);
            if (existing.isPresent()) {
                TeamMemberEntity member = existing.get();
                member.setName(name);
                member.setJiraUsername(jiraUsername);
                member.setIsActive(true);
                if (email != null && !email.isBlank()) member.setEmail(email);
                return teamMemberRepository.save(member);
            }
        }
        TeamMemberEntity member = new TeamMemberEntity();
        member.setName(name);
        member.setJiraUsername(jiraUsername);
        member.setJiraAccountId(jiraAccountId);
        if (email != null && !email.isBlank()) member.setEmail(email);
        member.setIsActive(true);
        return teamMemberRepository.save(member);
    }

    public TeamMemberEntity updateTeamMember(Long id, String name, String jiraUsername, String jiraAccountId, Boolean isActive) {
        return updateTeamMember(id, name, jiraUsername, jiraAccountId, isActive, null);
    }

    public TeamMemberEntity updateTeamMember(Long id, String name, String jiraUsername, String jiraAccountId, Boolean isActive, String email) {
        Optional<TeamMemberEntity> memberOpt = teamMemberRepository.findById(id);
        if (memberOpt.isPresent()) {
            TeamMemberEntity member = memberOpt.get();
            if (name != null) member.setName(name);
            if (jiraUsername != null) member.setJiraUsername(jiraUsername);
            if (jiraAccountId != null) member.setJiraAccountId(jiraAccountId);
            if (isActive != null) member.setIsActive(isActive);
            if (email != null && !email.isBlank()) member.setEmail(email);
            return teamMemberRepository.save(member);
        }
        return null;
    }

    public boolean deleteTeamMember(Long id) {
        Optional<TeamMemberEntity> memberOpt = teamMemberRepository.findById(id);
        if (memberOpt.isPresent()) {
            // Soft delete: แค่ซ่อน ไม่ลบจริง เพื่อรักษา id สำหรับ sprint results เก่า
            TeamMemberEntity member = memberOpt.get();
            member.setIsActive(false);
            teamMemberRepository.save(member);
            return true;
        }
        return false;
    }
}
