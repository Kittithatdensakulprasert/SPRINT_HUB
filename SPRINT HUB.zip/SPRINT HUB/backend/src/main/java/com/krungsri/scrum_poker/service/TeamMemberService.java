package com.krungsri.scrum_poker.service;

import com.krungsri.scrum_poker.entity.TeamMemberEntity;
import com.krungsri.scrum_poker.repository.TeamMemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class TeamMemberService {

    @Autowired
    private TeamMemberRepository teamMemberRepository;

    public List<TeamMemberEntity> getAllTeamMembers() {
        return teamMemberRepository.findAllByOrderByCreatedAtDesc();
    }

    public List<TeamMemberEntity> getActiveTeamMembers() {
        return teamMemberRepository.findByIsActive(true);
    }

    public Optional<TeamMemberEntity> getTeamMemberById(Long id) {
        return teamMemberRepository.findById(id);
    }

    public Optional<TeamMemberEntity> getTeamMemberByJiraUsername(String jiraUsername) {
        return teamMemberRepository.findByJiraUsername(jiraUsername);
    }

    public Optional<TeamMemberEntity> getTeamMemberByJiraAccountId(String jiraAccountId) {
        return teamMemberRepository.findByJiraAccountId(jiraAccountId);
    }

    public TeamMemberEntity createTeamMember(String name, String jiraUsername, String jiraAccountId) {
        TeamMemberEntity member = new TeamMemberEntity();
        member.setName(name);
        member.setJiraUsername(jiraUsername);
        member.setJiraAccountId(jiraAccountId);
        member.setIsActive(true);
        return teamMemberRepository.save(member);
    }

    public TeamMemberEntity updateTeamMember(Long id, String name, String jiraUsername, String jiraAccountId, Boolean isActive) {
        Optional<TeamMemberEntity> memberOpt = teamMemberRepository.findById(id);
        if (memberOpt.isPresent()) {
            TeamMemberEntity member = memberOpt.get();
            if (name != null) member.setName(name);
            if (jiraUsername != null) member.setJiraUsername(jiraUsername);
            if (jiraAccountId != null) member.setJiraAccountId(jiraAccountId);
            if (isActive != null) member.setIsActive(isActive);
            return teamMemberRepository.save(member);
        }
        return null;
    }

    public boolean deleteTeamMember(Long id) {
        if (teamMemberRepository.existsById(id)) {
            teamMemberRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
