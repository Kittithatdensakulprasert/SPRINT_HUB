package com.krungsri.scrum_poker.service;

import com.krungsri.scrum_poker.entity.SprintResultEntity;
import com.krungsri.scrum_poker.repository.SprintResultRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class SprintResultService {

    @Autowired
    private SprintResultRepository sprintResultRepository;

    public List<SprintResultEntity> getAllSprintResults() {
        return sprintResultRepository.findAll();
    }

    public List<SprintResultEntity> getSprintResultsBySprintId(Long sprintId) {
        return sprintResultRepository.findBySprintId(sprintId);
    }

    public List<SprintResultEntity> getSprintResultsByMemberId(Long memberId) {
        return sprintResultRepository.findByMemberId(memberId);
    }

    public Optional<SprintResultEntity> getSprintResultBySprintAndMember(Long sprintId, Long memberId) {
        return sprintResultRepository.findBySprintIdAndMemberId(sprintId, memberId);
    }

    public SprintResultEntity createSprintResult(Long sprintId, Long memberId, BigDecimal targetPts, BigDecimal donePts, BigDecimal remainingPts, BigDecimal existingPts, BigDecimal newPts) {
        SprintResultEntity result = new SprintResultEntity();
        result.setSprintId(sprintId);
        result.setMemberId(memberId);
        result.setTargetPts(targetPts != null ? targetPts : BigDecimal.ZERO);
        result.setDonePts(donePts != null ? donePts : BigDecimal.ZERO);
        result.setRemainingPts(remainingPts != null ? remainingPts : BigDecimal.ZERO);
        result.setExistingPts(existingPts != null ? existingPts : BigDecimal.ZERO);
        result.setNewPts(newPts != null ? newPts : BigDecimal.ZERO);
        return sprintResultRepository.save(result);
    }

    public SprintResultEntity createSprintResult(Long sprintId, Long memberId, BigDecimal targetPts, BigDecimal donePts, BigDecimal remainingPts) {
        return createSprintResult(sprintId, memberId, targetPts, donePts, remainingPts, BigDecimal.ZERO, BigDecimal.ZERO);
    }

    public SprintResultEntity updateSprintResult(Long id, BigDecimal targetPts, BigDecimal donePts, BigDecimal remainingPts, BigDecimal existingPts, BigDecimal newPts) {
        Optional<SprintResultEntity> resultOpt = sprintResultRepository.findById(id);
        if (resultOpt.isPresent()) {
            SprintResultEntity result = resultOpt.get();
            if (targetPts != null) result.setTargetPts(targetPts);
            if (donePts != null) result.setDonePts(donePts);
            if (remainingPts != null) result.setRemainingPts(remainingPts);
            if (existingPts != null) result.setExistingPts(existingPts);
            if (newPts != null) result.setNewPts(newPts);
            return sprintResultRepository.save(result);
        }
        return null;
    }

    public SprintResultEntity updateSprintResult(Long id, BigDecimal targetPts, BigDecimal donePts, BigDecimal remainingPts) {
        return updateSprintResult(id, targetPts, donePts, remainingPts, BigDecimal.ZERO, BigDecimal.ZERO);
    }

    public boolean deleteSprintResult(Long id) {
        if (sprintResultRepository.existsById(id)) {
            sprintResultRepository.deleteById(id);
            return true;
        }
        return false;
    }

    public boolean deleteSprintResultBySprintId(Long sprintId) {
        sprintResultRepository.deleteBySprintId(sprintId);
        return true;
    }
}
