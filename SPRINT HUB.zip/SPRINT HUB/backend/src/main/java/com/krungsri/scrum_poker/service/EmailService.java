package com.krungsri.scrum_poker.service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import java.util.Base64;
import java.util.List;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    @Value("${spring.mail.username:}")
    private String fromEmail;

    @Value("${mail.from.name:Sprint Hub}")
    private String fromName;

    public void sendSprintReportEmail(List<String> recipients, String subject, String bodyHtml, String pdfBase64, String pdfFilename) throws MessagingException, java.io.UnsupportedEncodingException {
        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

        helper.setFrom(fromEmail, fromName);
        helper.setTo(recipients.toArray(new String[0]));
        helper.setSubject(subject);
        helper.setText(bodyHtml, true);

        if (pdfBase64 != null && !pdfBase64.isBlank()) {
            byte[] pdfBytes = Base64.getDecoder().decode(
                pdfBase64.contains(",") ? pdfBase64.split(",")[1] : pdfBase64
            );
            helper.addAttachment(pdfFilename, new org.springframework.core.io.ByteArrayResource(pdfBytes), "application/pdf");
        }

        mailSender.send(message);
    }

    public boolean isConfigured() {
        return fromEmail != null && !fromEmail.isBlank();
    }
}
